import { $n as Output, Al as ɵɵinject, Bt as computed, Dc as Injector, Dl as ɵɵdefineInjector, Ec as InjectionToken, Ei as provideAppInitializer, El as ɵɵdefineInjectable, En as ElementRef, Er as ViewContainerRef, Fc as NgZone, Fn as Injectable, In as Input, Io as ɵɵinjectAttribute, Jo as ɵɵlistener, Ll as require_cjs, Mn as IS_HYDRATION_DOM_REUSE_ENABLED, Mr as afterNextRender, Ns as ɵɵsanitizeUrlOrResourceUrl, O as booleanAttribute, Ta as ɵɵcontentQuery, Tc as INTERNAL_APPLICATION_ERROR_HANDLER, Ti as performanceMarkFeature, Uc as RuntimeError, Ui as setClassMetadata, Vc as PendingTasksInternal, Wt as linkedSignal, X as input, Yn as NgModuleFactory$1, Yo as ɵɵloadQuery, Yt as APP_BOOTSTRAP_LISTENER, _i as isNgModule, _l as provideEnvironmentInitializer, _s as ɵɵqueryRefresh, a as ContentChildren, an as ChangeDetectionStrategy, ao as ɵɵdirectiveInject, bc as EventEmitter, ca as ɵɵNgOnChangesFeature, cc as require_operators, cn as Component, dl as isStandalone, dr as Service, eo as ɵɵdefineComponent, et as maybeUnwrapDefaultExport, f as HostAttributeToken, fn as Console, ft as reflectComponentType, gc as ENVIRONMENT_INITIALIZER, hc as DestroyRef, hl as promiseWithResolvers, ho as ɵɵelement, io as ɵɵdefineService, ir as Renderer2, ji as publishNonCoreGlobalUtil, jn as IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, kn as HostListener, ll as isInjectable, mc as DOCUMENT, nl as formatRuntimeError, nn as Attribute, no as ɵɵdefineNgModule, on as Compiler, pl as makeEnvironmentProviders, qc as Version, qn as NgModule, qo as ɵɵinvalidFactory, qr as createEnvironmentInjector, qt as untracked, r as ChangeDetectorRef, sl as inject, tl as effect, tn as ApplicationRef, to as ɵɵdefineDirective, va as ɵɵattribute, vc as EnvironmentInjector, vi as isPromise, wn as Directive, xl as signal, yl as runInInjectionContext } from "./core-CPx2yndP.js";
import { n as LOCATION_INITIALIZED, r as PlatformLocation } from "./_platform_location-chunk-CkimD5vg.js";
import { a as ViewportScroller, d as PathLocationStrategy, l as Location, o as PRECOMMIT_HANDLER_SUPPORTED, s as PlatformNavigation, t as NavigationAdapterForLocation, u as LocationStrategy } from "./common-D09O_tlb.js";
import { P as HashLocationStrategy, s as Title } from "./platform-browser-BQcNWVbv.js";
//#region node_modules/@angular/router/fesm2022/_router-chunk.mjs
/**
* @license Angular v22.1.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var import_cjs = require_cjs();
var import_operators = require_operators();
var PRIMARY_OUTLET = "primary";
var RouteTitleKey = /* @__PURE__ */ Symbol("RouteTitle");
var ParamsAsMap = class {
	params;
	constructor(params) {
		this.params = params || {};
	}
	has(name) {
		return Object.prototype.hasOwnProperty.call(this.params, name);
	}
	get(name) {
		if (this.has(name)) {
			const v = this.params[name];
			return Array.isArray(v) ? v[0] : v;
		}
		return null;
	}
	getAll(name) {
		if (this.has(name)) {
			const v = this.params[name];
			return Array.isArray(v) ? v : [v];
		}
		return [];
	}
	get keys() {
		return Object.keys(this.params);
	}
};
function convertToParamMap(params) {
	return new ParamsAsMap(params);
}
function matchParts(routeParts, urlSegments, posParams) {
	for (let i = 0; i < routeParts.length; i++) {
		const part = routeParts[i];
		const segment = urlSegments[i];
		if (part[0] === ":") posParams[part.substring(1)] = segment;
		else if (part !== segment.path) return false;
	}
	return true;
}
function defaultUrlMatcher(segments, segmentGroup, route) {
	const parts = route.path.split("/");
	const wildcardIndex = parts.indexOf("**");
	if (wildcardIndex === -1) {
		if (parts.length > segments.length) return null;
		if (route.pathMatch === "full" && (segmentGroup.hasChildren() || parts.length < segments.length)) return null;
		const posParams = {};
		const consumed = segments.slice(0, parts.length);
		if (!matchParts(parts, consumed, posParams)) return null;
		return {
			consumed,
			posParams
		};
	}
	if (wildcardIndex !== parts.lastIndexOf("**")) return null;
	const pre = parts.slice(0, wildcardIndex);
	const post = parts.slice(wildcardIndex + 1);
	if (pre.length + post.length > segments.length) return null;
	if (route.pathMatch === "full" && segmentGroup.hasChildren() && route.path !== "**") return null;
	const posParams = {};
	if (!matchParts(pre, segments.slice(0, pre.length), posParams)) return null;
	if (!matchParts(post, segments.slice(segments.length - post.length), posParams)) return null;
	return {
		consumed: segments,
		posParams
	};
}
function firstValueFrom(source) {
	return new Promise((resolve, reject) => {
		source.pipe((0, import_operators.first)()).subscribe({
			next: (value) => resolve(value),
			error: (err) => reject(err)
		});
	});
}
function shallowEqualArrays(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; ++i) if (!shallowEqual(a[i], b[i])) return false;
	return true;
}
function shallowEqual(a, b) {
	const k1 = a ? getDataKeys(a) : void 0;
	const k2 = b ? getDataKeys(b) : void 0;
	if (!k1 || !k2 || k1.length != k2.length) return false;
	let key;
	for (let i = 0; i < k1.length; i++) {
		key = k1[i];
		if (!equalArraysOrString(a[key], b[key])) return false;
	}
	return true;
}
function getDataKeys(obj) {
	return [...Object.keys(obj), ...Object.getOwnPropertySymbols(obj)];
}
function equalArraysOrString(a, b) {
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		const aSorted = [...a].sort();
		const bSorted = [...b].sort();
		return aSorted.every((val, index) => bSorted[index] === val);
	} else return a === b;
}
function last(a) {
	return a.length > 0 ? a[a.length - 1] : null;
}
function wrapIntoObservable(value) {
	if ((0, import_cjs.isObservable)(value)) return value;
	if (isPromise(value)) return (0, import_cjs.from)(Promise.resolve(value));
	return (0, import_cjs.of)(value);
}
function wrapIntoPromise(value) {
	if ((0, import_cjs.isObservable)(value)) return firstValueFrom(value);
	return Promise.resolve(value);
}
var pathCompareMap = {
	"exact": equalSegmentGroups,
	"subset": containsSegmentGroup
};
var paramCompareMap = {
	"exact": equalParams,
	"subset": containsParams,
	"ignored": () => true
};
var exactMatchOptions = {
	paths: "exact",
	fragment: "ignored",
	matrixParams: "ignored",
	queryParams: "exact"
};
var subsetMatchOptions = {
	paths: "subset",
	fragment: "ignored",
	matrixParams: "ignored",
	queryParams: "subset"
};
function isActive(url, router, matchOptions) {
	const urlTree = url instanceof UrlTree ? url : router.parseUrl(url);
	return computed(() => containsTree(router.lastSuccessfulNavigation()?.finalUrl ?? new UrlTree(), urlTree, {
		...subsetMatchOptions,
		...matchOptions
	}));
}
function containsTree(container, containee, options) {
	return pathCompareMap[options.paths](container.root, containee.root, options.matrixParams) && paramCompareMap[options.queryParams](container.queryParams, containee.queryParams) && !(options.fragment === "exact" && container.fragment !== containee.fragment);
}
function equalParams(container, containee) {
	return shallowEqual(container, containee);
}
function equalSegmentGroups(container, containee, matrixParams) {
	if (!equalPath(container.segments, containee.segments)) return false;
	if (!matrixParamsMatch(container.segments, containee.segments, matrixParams)) return false;
	if (container.numberOfChildren !== containee.numberOfChildren) return false;
	for (const c in containee.children) {
		if (!container.children[c]) return false;
		if (!equalSegmentGroups(container.children[c], containee.children[c], matrixParams)) return false;
	}
	return true;
}
function containsParams(container, containee) {
	return Object.keys(containee).length <= Object.keys(container).length && Object.keys(containee).every((key) => equalArraysOrString(container[key], containee[key]));
}
function containsSegmentGroup(container, containee, matrixParams) {
	return containsSegmentGroupHelper(container, containee, containee.segments, matrixParams);
}
function containsSegmentGroupHelper(container, containee, containeePaths, matrixParams) {
	if (container.segments.length > containeePaths.length) {
		const current = container.segments.slice(0, containeePaths.length);
		if (!equalPath(current, containeePaths)) return false;
		if (containee.hasChildren()) return false;
		if (!matrixParamsMatch(current, containeePaths, matrixParams)) return false;
		return true;
	} else if (container.segments.length === containeePaths.length) {
		if (!equalPath(container.segments, containeePaths)) return false;
		if (!matrixParamsMatch(container.segments, containeePaths, matrixParams)) return false;
		for (const c in containee.children) {
			if (!container.children[c]) return false;
			if (!containsSegmentGroup(container.children[c], containee.children[c], matrixParams)) return false;
		}
		return true;
	} else {
		const current = containeePaths.slice(0, container.segments.length);
		const next = containeePaths.slice(container.segments.length);
		if (!equalPath(container.segments, current)) return false;
		if (!matrixParamsMatch(container.segments, current, matrixParams)) return false;
		if (!container.children["primary"]) return false;
		return containsSegmentGroupHelper(container.children[PRIMARY_OUTLET], containee, next, matrixParams);
	}
}
function matrixParamsMatch(containerPaths, containeePaths, options) {
	return containeePaths.every((containeeSegment, i) => {
		return paramCompareMap[options](containerPaths[i].parameters, containeeSegment.parameters);
	});
}
var UrlTree = class {
	root;
	queryParams;
	fragment;
	_queryParamMap;
	constructor(root = new UrlSegmentGroup([], {}), queryParams = {}, fragment = null) {
		this.root = root;
		this.queryParams = queryParams;
		this.fragment = fragment;
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			if (root.segments.length > 0) throw new RuntimeError(4015, "The root `UrlSegmentGroup` should not contain `segments`. Instead, these segments belong in the `children` so they can be associated with a named outlet.");
		}
	}
	get queryParamMap() {
		this._queryParamMap ??= convertToParamMap(this.queryParams);
		return this._queryParamMap;
	}
	toString() {
		return DEFAULT_SERIALIZER.serialize(this);
	}
};
var UrlSegmentGroup = class {
	segments;
	children;
	parent = null;
	constructor(segments, children) {
		this.segments = segments;
		this.children = children;
		Object.values(children).forEach((v) => v.parent = this);
	}
	hasChildren() {
		return this.numberOfChildren > 0;
	}
	get numberOfChildren() {
		return Object.keys(this.children).length;
	}
	toString() {
		return serializePaths(this);
	}
};
var UrlSegment = class {
	path;
	parameters;
	_parameterMap;
	constructor(path, parameters) {
		this.path = path;
		this.parameters = parameters;
	}
	get parameterMap() {
		this._parameterMap ??= convertToParamMap(this.parameters);
		return this._parameterMap;
	}
	toString() {
		return serializePath(this);
	}
};
function equalSegments(as, bs) {
	return equalPath(as, bs) && as.every((a, i) => shallowEqual(a.parameters, bs[i].parameters));
}
function equalPath(as, bs) {
	if (as.length !== bs.length) return false;
	return as.every((a, i) => a.path === bs[i].path);
}
function mapChildrenIntoArray(segment, fn) {
	let res = [];
	Object.entries(segment.children).forEach(([childOutlet, child]) => {
		if (childOutlet === "primary") res = res.concat(fn(child, childOutlet));
	});
	Object.entries(segment.children).forEach(([childOutlet, child]) => {
		if (childOutlet !== "primary") res = res.concat(fn(child, childOutlet));
	});
	return res;
}
var UrlSerializer = class UrlSerializer {
	static ɵfac = function UrlSerializer_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || UrlSerializer)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: UrlSerializer,
		factory: () => (() => new DefaultUrlSerializer())()
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UrlSerializer, [{
		type: Service,
		args: [{ factory: () => new DefaultUrlSerializer() }]
	}], null, null);
})();
var DefaultUrlSerializer = class {
	parse(url) {
		const p = new UrlParser(url);
		return new UrlTree(p.parseRootSegment(), p.parseQueryParams(), p.parseFragment());
	}
	serialize(tree) {
		return `${`/${serializeSegment(tree.root, true)}`}${serializeQueryParams(tree.queryParams)}${typeof tree.fragment === `string` ? `#${encodeUriFragment(tree.fragment)}` : ""}`;
	}
};
var DEFAULT_SERIALIZER = new DefaultUrlSerializer();
function serializePaths(segment) {
	return segment.segments.map((p) => serializePath(p)).join("/");
}
function serializeSegment(segment, root) {
	if (!segment.hasChildren()) return serializePaths(segment);
	if (root) {
		const primary = segment.children["primary"] ? serializeSegment(segment.children[PRIMARY_OUTLET], false) : "";
		const children = [];
		Object.entries(segment.children).forEach(([k, v]) => {
			if (k !== "primary") children.push(`${k}:${serializeSegment(v, false)}`);
		});
		return children.length > 0 ? `${primary}(${children.join("//")})` : primary;
	} else {
		const children = mapChildrenIntoArray(segment, (v, k) => {
			if (k === "primary") return [serializeSegment(segment.children[PRIMARY_OUTLET], false)];
			return [`${k}:${serializeSegment(v, false)}`];
		});
		if (Object.keys(segment.children).length === 1 && segment.children["primary"] != null) return `${serializePaths(segment)}/${children[0]}`;
		return `${serializePaths(segment)}/(${children.join("//")})`;
	}
}
function encodeUriString(s) {
	return encodeURIComponent(s).replace(/%40/g, "@").replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",");
}
function encodeUriQuery(s) {
	return encodeUriString(s).replace(/%3B/gi, ";");
}
function encodeUriFragment(s) {
	return encodeURI(s);
}
function encodeUriSegment(s) {
	return encodeUriString(s).replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/%26/gi, "&");
}
function decode(s) {
	return decodeURIComponent(s);
}
function decodeQuery(s) {
	return decode(s.replace(/\+/g, "%20"));
}
function serializePath(path) {
	return `${encodeUriSegment(path.path)}${serializeMatrixParams(path.parameters)}`;
}
function serializeMatrixParams(params) {
	return Object.entries(params).map(([key, value]) => `;${encodeUriSegment(key)}=${encodeUriSegment(value)}`).join("");
}
function serializeQueryParams(params) {
	const strParams = Object.entries(params).map(([name, value]) => {
		return Array.isArray(value) ? value.map((v) => `${encodeUriQuery(name)}=${encodeUriQuery(v)}`).join("&") : `${encodeUriQuery(name)}=${encodeUriQuery(value)}`;
	}).filter((s) => s);
	return strParams.length ? `?${strParams.join("&")}` : "";
}
var SEGMENT_RE = /^[^\/()?;#]+/;
function matchSegments(str) {
	const match = str.match(SEGMENT_RE);
	return match ? match[0] : "";
}
var MATRIX_PARAM_SEGMENT_RE = /^[^\/()?;=#]+/;
function matchMatrixKeySegments(str) {
	const match = str.match(MATRIX_PARAM_SEGMENT_RE);
	return match ? match[0] : "";
}
var QUERY_PARAM_RE = /^[^=?&#]+/;
function matchQueryParams(str) {
	const match = str.match(QUERY_PARAM_RE);
	return match ? match[0] : "";
}
var QUERY_PARAM_VALUE_RE = /^[^&#]+/;
function matchUrlQueryParamValue(str) {
	const match = str.match(QUERY_PARAM_VALUE_RE);
	return match ? match[0] : "";
}
var UrlParser = class {
	url;
	remaining;
	constructor(url) {
		this.url = url;
		this.remaining = url;
	}
	parseRootSegment() {
		while (this.consumeOptional("/"));
		if (this.remaining === "" || this.peekStartsWith("?") || this.peekStartsWith("#")) return new UrlSegmentGroup([], {});
		return new UrlSegmentGroup([], this.parseChildren());
	}
	parseQueryParams() {
		const params = {};
		if (this.consumeOptional("?")) do
			this.parseQueryParam(params);
		while (this.consumeOptional("&"));
		return params;
	}
	parseFragment() {
		return this.consumeOptional("#") ? decodeURIComponent(this.remaining) : null;
	}
	parseChildren(depth = 0) {
		if (depth > 50) throw new RuntimeError(4010, (typeof ngDevMode === "undefined" || ngDevMode) && "URL is too deep");
		if (this.remaining === "") return {};
		this.consumeOptional("/");
		const segments = [];
		if (!this.peekStartsWith("(")) segments.push(this.parseSegment());
		while (this.peekStartsWith("/") && !this.peekStartsWith("//") && !this.peekStartsWith("/(")) {
			this.capture("/");
			segments.push(this.parseSegment());
		}
		let children = {};
		if (this.peekStartsWith("/(")) {
			this.capture("/");
			children = this.parseParens(true, depth);
		}
		let res = {};
		if (this.peekStartsWith("(")) res = this.parseParens(false, depth);
		if (segments.length > 0 || Object.keys(children).length > 0) res[PRIMARY_OUTLET] = new UrlSegmentGroup(segments, children);
		return res;
	}
	parseSegment() {
		const path = matchSegments(this.remaining);
		if (path === "" && this.peekStartsWith(";")) throw new RuntimeError(4009, (typeof ngDevMode === "undefined" || ngDevMode) && `Empty path url segment cannot have parameters: '${this.remaining}'.`);
		this.capture(path);
		return new UrlSegment(decode(path), this.parseMatrixParams());
	}
	parseMatrixParams() {
		const params = {};
		while (this.consumeOptional(";")) this.parseParam(params);
		return params;
	}
	parseParam(params) {
		const key = matchMatrixKeySegments(this.remaining);
		if (!key) return;
		this.capture(key);
		let value = "";
		if (this.consumeOptional("=")) {
			const valueMatch = matchSegments(this.remaining);
			if (valueMatch) {
				value = valueMatch;
				this.capture(value);
			}
		}
		params[decode(key)] = decode(value);
	}
	parseQueryParam(params) {
		const key = matchQueryParams(this.remaining);
		if (!key) return;
		this.capture(key);
		let value = "";
		if (this.consumeOptional("=")) {
			const valueMatch = matchUrlQueryParamValue(this.remaining);
			if (valueMatch) {
				value = valueMatch;
				this.capture(value);
			}
		}
		const decodedKey = decodeQuery(key);
		const decodedVal = decodeQuery(value);
		if (Object.hasOwn(params, decodedKey)) {
			let currentVal = params[decodedKey];
			if (!Array.isArray(currentVal)) {
				currentVal = [currentVal];
				params[decodedKey] = currentVal;
			}
			currentVal.push(decodedVal);
		} else params[decodedKey] = decodedVal;
	}
	parseParens(allowPrimary, depth) {
		const segments = Object.create(null);
		this.capture("(");
		while (!this.consumeOptional(")") && this.remaining.length > 0) {
			const path = matchSegments(this.remaining);
			const next = this.remaining[path.length];
			if (next !== "/" && next !== ")" && next !== ";") throw new RuntimeError(4010, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot parse url '${this.url}'`);
			let outletName;
			if (path.indexOf(":") > -1) {
				outletName = path.slice(0, path.indexOf(":"));
				this.capture(outletName);
				this.capture(":");
			} else if (allowPrimary) outletName = PRIMARY_OUTLET;
			const children = this.parseChildren(depth + 1);
			segments[outletName ?? "primary"] = Object.keys(children).length === 1 && children["primary"] ? children[PRIMARY_OUTLET] : new UrlSegmentGroup([], children);
			this.consumeOptional("//");
		}
		return segments;
	}
	peekStartsWith(str) {
		return this.remaining.startsWith(str);
	}
	consumeOptional(str) {
		if (this.peekStartsWith(str)) {
			this.remaining = this.remaining.substring(str.length);
			return true;
		}
		return false;
	}
	capture(str) {
		if (!this.consumeOptional(str)) throw new RuntimeError(4011, (typeof ngDevMode === "undefined" || ngDevMode) && `Expected "${str}".`);
	}
};
function createRoot(rootCandidate) {
	return rootCandidate.segments.length > 0 ? new UrlSegmentGroup([], { [PRIMARY_OUTLET]: rootCandidate }) : rootCandidate;
}
function squashSegmentGroup(segmentGroup) {
	const newChildren = Object.create(null);
	for (const [childOutlet, child] of Object.entries(segmentGroup.children)) {
		const childCandidate = squashSegmentGroup(child);
		if (childOutlet === "primary" && childCandidate.segments.length === 0 && childCandidate.hasChildren()) for (const [grandChildOutlet, grandChild] of Object.entries(childCandidate.children)) newChildren[grandChildOutlet] = grandChild;
		else if (childCandidate.segments.length > 0 || childCandidate.hasChildren()) newChildren[childOutlet] = childCandidate;
	}
	return mergeTrivialChildren(new UrlSegmentGroup(segmentGroup.segments, newChildren));
}
function mergeTrivialChildren(s) {
	if (s.numberOfChildren === 1 && s.children["primary"]) {
		const c = s.children[PRIMARY_OUTLET];
		return new UrlSegmentGroup(s.segments.concat(c.segments), c.children);
	}
	return s;
}
function isUrlTree(v) {
	return v instanceof UrlTree;
}
function createUrlTreeFromSnapshot(relativeTo, commands, queryParams = null, fragment = null, urlSerializer = new DefaultUrlSerializer()) {
	return createUrlTreeFromSegmentGroup(createSegmentGroupFromRoute(relativeTo), commands, queryParams, fragment, urlSerializer);
}
function createSegmentGroupFromRoute(route) {
	let targetGroup;
	function createSegmentGroupFromRouteRecursive(currentRoute) {
		const childOutlets = {};
		for (const childSnapshot of currentRoute.children) {
			const root = createSegmentGroupFromRouteRecursive(childSnapshot);
			childOutlets[childSnapshot.outlet] = root;
		}
		const segmentGroup = new UrlSegmentGroup(currentRoute.url, childOutlets);
		if (currentRoute === route) targetGroup = segmentGroup;
		return segmentGroup;
	}
	const rootSegmentGroup = createRoot(createSegmentGroupFromRouteRecursive(route.root));
	return targetGroup ?? rootSegmentGroup;
}
function createUrlTreeFromSegmentGroup(relativeTo, commands, queryParams, fragment, urlSerializer) {
	let root = relativeTo;
	while (root.parent) root = root.parent;
	if (commands.length === 0) return tree(root, root, root, queryParams, fragment, urlSerializer);
	const nav = computeNavigation(commands);
	if (nav.toRoot()) return tree(root, root, new UrlSegmentGroup([], {}), queryParams, fragment, urlSerializer);
	const position = findStartingPositionForTargetGroup(nav, root, relativeTo);
	const newSegmentGroup = position.processChildren ? updateSegmentGroupChildren(position.segmentGroup, position.index, nav.commands) : updateSegmentGroup(position.segmentGroup, position.index, nav.commands);
	return tree(root, position.segmentGroup, newSegmentGroup, queryParams, fragment, urlSerializer);
}
function isMatrixParams(command) {
	return typeof command === "object" && command != null && !command.outlets && !command.segmentPath;
}
function isCommandWithOutlets(command) {
	return typeof command === "object" && command != null && command.outlets;
}
function normalizeQueryParams(k, v, urlSerializer) {
	k ||= "ɵ";
	const tree = new UrlTree();
	tree.queryParams = { [k]: v };
	return urlSerializer.parse(urlSerializer.serialize(tree)).queryParams[k];
}
function tree(oldRoot, oldSegmentGroup, newSegmentGroup, queryParams, fragment, urlSerializer) {
	const qp = {};
	for (const [key, value] of Object.entries(queryParams ?? {})) qp[key] = Array.isArray(value) ? value.map((v) => normalizeQueryParams(key, v, urlSerializer)) : normalizeQueryParams(key, value, urlSerializer);
	let rootCandidate;
	if (oldRoot === oldSegmentGroup) rootCandidate = newSegmentGroup;
	else rootCandidate = replaceSegment(oldRoot, oldSegmentGroup, newSegmentGroup);
	return new UrlTree(createRoot(squashSegmentGroup(rootCandidate)), qp, fragment);
}
function replaceSegment(current, oldSegment, newSegment) {
	const children = Object.create(null);
	Object.entries(current.children).forEach(([outletName, c]) => {
		if (c === oldSegment) children[outletName] = newSegment;
		else children[outletName] = replaceSegment(c, oldSegment, newSegment);
	});
	return new UrlSegmentGroup(current.segments, children);
}
var Navigation = class {
	isAbsolute;
	numberOfDoubleDots;
	commands;
	constructor(isAbsolute, numberOfDoubleDots, commands) {
		this.isAbsolute = isAbsolute;
		this.numberOfDoubleDots = numberOfDoubleDots;
		this.commands = commands;
		if (isAbsolute && commands.length > 0 && isMatrixParams(commands[0])) throw new RuntimeError(4003, (typeof ngDevMode === "undefined" || ngDevMode) && "Root segment cannot have matrix parameters");
		const cmdWithOutlet = commands.find(isCommandWithOutlets);
		if (cmdWithOutlet && cmdWithOutlet !== last(commands)) throw new RuntimeError(4004, (typeof ngDevMode === "undefined" || ngDevMode) && "{outlets:{}} has to be the last command");
	}
	toRoot() {
		return this.isAbsolute && this.commands.length === 1 && this.commands[0] == "/";
	}
};
function computeNavigation(commands) {
	if (typeof commands[0] === "string" && commands.length === 1 && commands[0] === "/") return new Navigation(true, 0, commands);
	let numberOfDoubleDots = 0;
	let isAbsolute = false;
	const res = commands.reduce((res, cmd, cmdIdx) => {
		if (typeof cmd === "object" && cmd != null) {
			if (cmd.outlets) {
				const outlets = {};
				Object.entries(cmd.outlets).forEach(([name, commands]) => {
					outlets[name] = typeof commands === "string" ? commands.split("/") : commands;
				});
				return [...res, { outlets }];
			}
			if (cmd.segmentPath) return [...res, cmd.segmentPath];
		}
		if (!(typeof cmd === "string")) return [...res, cmd];
		if (cmdIdx === 0) {
			cmd.split("/").forEach((urlPart, partIndex) => {
				if (partIndex == 0 && urlPart === ".");
				else if (partIndex == 0 && urlPart === "") isAbsolute = true;
				else if (urlPart === "..") numberOfDoubleDots++;
				else if (urlPart != "") res.push(urlPart);
			});
			return res;
		}
		return [...res, cmd];
	}, []);
	return new Navigation(isAbsolute, numberOfDoubleDots, res);
}
var Position = class {
	segmentGroup;
	processChildren;
	index;
	constructor(segmentGroup, processChildren, index) {
		this.segmentGroup = segmentGroup;
		this.processChildren = processChildren;
		this.index = index;
	}
};
function findStartingPositionForTargetGroup(nav, root, target) {
	if (nav.isAbsolute) return new Position(root, true, 0);
	if (!target) return new Position(root, false, NaN);
	if (target.parent === null) return new Position(target, true, 0);
	const modifier = isMatrixParams(nav.commands[0]) ? 0 : 1;
	return createPositionApplyingDoubleDots(target, target.segments.length - 1 + modifier, nav.numberOfDoubleDots);
}
function createPositionApplyingDoubleDots(group, index, numberOfDoubleDots) {
	let g = group;
	let ci = index;
	let dd = numberOfDoubleDots;
	while (dd > ci) {
		dd -= ci;
		g = g.parent;
		if (!g) throw new RuntimeError(4005, (typeof ngDevMode === "undefined" || ngDevMode) && "Invalid number of '../'");
		ci = g.segments.length;
	}
	return new Position(g, false, ci - dd);
}
function getOutlets(commands) {
	if (isCommandWithOutlets(commands[0])) return commands[0].outlets;
	return { [PRIMARY_OUTLET]: commands };
}
function updateSegmentGroup(segmentGroup, startIndex, commands) {
	segmentGroup ??= new UrlSegmentGroup([], {});
	if (segmentGroup.segments.length === 0 && segmentGroup.hasChildren()) return updateSegmentGroupChildren(segmentGroup, startIndex, commands);
	const m = prefixedWith(segmentGroup, startIndex, commands);
	const slicedCommands = commands.slice(m.commandIndex);
	if (m.match && m.pathIndex < segmentGroup.segments.length) {
		const g = new UrlSegmentGroup(segmentGroup.segments.slice(0, m.pathIndex), {});
		g.children[PRIMARY_OUTLET] = new UrlSegmentGroup(segmentGroup.segments.slice(m.pathIndex), segmentGroup.children);
		return updateSegmentGroupChildren(g, 0, slicedCommands);
	} else if (m.match && slicedCommands.length === 0) return new UrlSegmentGroup(segmentGroup.segments, {});
	else if (m.match && !segmentGroup.hasChildren()) return createNewSegmentGroup(segmentGroup, startIndex, commands);
	else if (m.match) return updateSegmentGroupChildren(segmentGroup, 0, slicedCommands);
	else return createNewSegmentGroup(segmentGroup, startIndex, commands);
}
function updateSegmentGroupChildren(segmentGroup, startIndex, commands) {
	if (commands.length === 0) return new UrlSegmentGroup(segmentGroup.segments, {});
	else {
		const outlets = getOutlets(commands);
		const children = Object.create(null);
		if (Object.keys(outlets).some((o) => o !== "primary") && segmentGroup.children["primary"] && segmentGroup.numberOfChildren === 1 && segmentGroup.children["primary"].segments.length === 0) {
			const childrenOfEmptyChild = updateSegmentGroupChildren(segmentGroup.children[PRIMARY_OUTLET], startIndex, commands);
			return new UrlSegmentGroup(segmentGroup.segments, childrenOfEmptyChild.children);
		}
		Object.entries(outlets).forEach(([outlet, commands]) => {
			if (typeof commands === "string") commands = [commands];
			if (commands !== null) children[outlet] = updateSegmentGroup(segmentGroup.children[outlet], startIndex, commands);
		});
		Object.entries(segmentGroup.children).forEach(([childOutlet, child]) => {
			if (outlets[childOutlet] === void 0) children[childOutlet] = child;
		});
		return new UrlSegmentGroup(segmentGroup.segments, children);
	}
}
function prefixedWith(segmentGroup, startIndex, commands) {
	let currentCommandIndex = 0;
	let currentPathIndex = startIndex;
	const noMatch = {
		match: false,
		pathIndex: 0,
		commandIndex: 0
	};
	while (currentPathIndex < segmentGroup.segments.length) {
		if (currentCommandIndex >= commands.length) return noMatch;
		const path = segmentGroup.segments[currentPathIndex];
		const command = commands[currentCommandIndex];
		if (isCommandWithOutlets(command)) break;
		const curr = `${command}`;
		const next = currentCommandIndex < commands.length - 1 ? commands[currentCommandIndex + 1] : null;
		if (currentPathIndex > 0 && curr === void 0) break;
		if (curr && next && typeof next === "object" && next.outlets === void 0) {
			if (!compare(curr, next, path)) return noMatch;
			currentCommandIndex += 2;
		} else {
			if (!compare(curr, {}, path)) return noMatch;
			currentCommandIndex++;
		}
		currentPathIndex++;
	}
	return {
		match: true,
		pathIndex: currentPathIndex,
		commandIndex: currentCommandIndex
	};
}
function createNewSegmentGroup(segmentGroup, startIndex, commands) {
	const paths = segmentGroup.segments.slice(0, startIndex);
	let i = 0;
	while (i < commands.length) {
		const command = commands[i];
		if (isCommandWithOutlets(command)) return new UrlSegmentGroup(paths, createNewSegmentChildren(command.outlets));
		if (i === 0 && isMatrixParams(commands[0])) {
			const p = segmentGroup.segments[startIndex];
			paths.push(new UrlSegment(p.path, stringify(commands[0])));
			i++;
			continue;
		}
		const curr = isCommandWithOutlets(command) ? command.outlets[PRIMARY_OUTLET] : `${command}`;
		const next = i < commands.length - 1 ? commands[i + 1] : null;
		if (curr && next && isMatrixParams(next)) {
			paths.push(new UrlSegment(curr, stringify(next)));
			i += 2;
		} else {
			paths.push(new UrlSegment(curr, {}));
			i++;
		}
	}
	return new UrlSegmentGroup(paths, {});
}
function createNewSegmentChildren(outlets) {
	const children = {};
	Object.entries(outlets).forEach(([outlet, commands]) => {
		if (typeof commands === "string") commands = [commands];
		if (commands !== null) children[outlet] = createNewSegmentGroup(new UrlSegmentGroup([], {}), 0, commands);
	});
	return children;
}
function stringify(params) {
	const res = {};
	Object.entries(params).forEach(([k, v]) => res[k] = `${v}`);
	return res;
}
function compare(path, params, segment) {
	return path == segment.path && shallowEqual(params, segment.parameters);
}
var IMPERATIVE_NAVIGATION = "imperative";
var EventType;
(function(EventType) {
	EventType[EventType["NavigationStart"] = 0] = "NavigationStart";
	EventType[EventType["NavigationEnd"] = 1] = "NavigationEnd";
	EventType[EventType["NavigationCancel"] = 2] = "NavigationCancel";
	EventType[EventType["NavigationError"] = 3] = "NavigationError";
	EventType[EventType["RoutesRecognized"] = 4] = "RoutesRecognized";
	EventType[EventType["ResolveStart"] = 5] = "ResolveStart";
	EventType[EventType["ResolveEnd"] = 6] = "ResolveEnd";
	EventType[EventType["GuardsCheckStart"] = 7] = "GuardsCheckStart";
	EventType[EventType["GuardsCheckEnd"] = 8] = "GuardsCheckEnd";
	EventType[EventType["RouteConfigLoadStart"] = 9] = "RouteConfigLoadStart";
	EventType[EventType["RouteConfigLoadEnd"] = 10] = "RouteConfigLoadEnd";
	EventType[EventType["ChildActivationStart"] = 11] = "ChildActivationStart";
	EventType[EventType["ChildActivationEnd"] = 12] = "ChildActivationEnd";
	EventType[EventType["ActivationStart"] = 13] = "ActivationStart";
	EventType[EventType["ActivationEnd"] = 14] = "ActivationEnd";
	EventType[EventType["Scroll"] = 15] = "Scroll";
	EventType[EventType["NavigationSkipped"] = 16] = "NavigationSkipped";
})(EventType || (EventType = {}));
var RouterEvent = class {
	id;
	url;
	constructor(id, url) {
		this.id = id;
		this.url = url;
	}
};
var NavigationStart = class extends RouterEvent {
	type = EventType.NavigationStart;
	navigationTrigger;
	restoredState;
	constructor(id, url, navigationTrigger = "imperative", restoredState = null) {
		super(id, url);
		this.navigationTrigger = navigationTrigger;
		this.restoredState = restoredState;
	}
	toString() {
		return `NavigationStart(id: ${this.id}, url: '${this.url}')`;
	}
};
var NavigationEnd = class extends RouterEvent {
	urlAfterRedirects;
	type = EventType.NavigationEnd;
	constructor(id, url, urlAfterRedirects) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
	}
	toString() {
		return `NavigationEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}')`;
	}
};
var NavigationCancellationCode;
(function(NavigationCancellationCode) {
	NavigationCancellationCode[NavigationCancellationCode["Redirect"] = 0] = "Redirect";
	NavigationCancellationCode[NavigationCancellationCode["SupersededByNewNavigation"] = 1] = "SupersededByNewNavigation";
	NavigationCancellationCode[NavigationCancellationCode["NoDataFromResolver"] = 2] = "NoDataFromResolver";
	NavigationCancellationCode[NavigationCancellationCode["GuardRejected"] = 3] = "GuardRejected";
	NavigationCancellationCode[NavigationCancellationCode["Aborted"] = 4] = "Aborted";
})(NavigationCancellationCode || (NavigationCancellationCode = {}));
var NavigationSkippedCode;
(function(NavigationSkippedCode) {
	NavigationSkippedCode[NavigationSkippedCode["IgnoredSameUrlNavigation"] = 0] = "IgnoredSameUrlNavigation";
	NavigationSkippedCode[NavigationSkippedCode["IgnoredByUrlHandlingStrategy"] = 1] = "IgnoredByUrlHandlingStrategy";
})(NavigationSkippedCode || (NavigationSkippedCode = {}));
var NavigationCancel = class extends RouterEvent {
	reason;
	code;
	type = EventType.NavigationCancel;
	constructor(id, url, reason, code) {
		super(id, url);
		this.reason = reason;
		this.code = code;
	}
	toString() {
		return `NavigationCancel(id: ${this.id}, url: '${this.url}')`;
	}
};
function isRedirectingEvent(event) {
	return event instanceof NavigationCancel && (event.code === NavigationCancellationCode.Redirect || event.code === NavigationCancellationCode.SupersededByNewNavigation);
}
var NavigationSkipped = class extends RouterEvent {
	reason;
	code;
	type = EventType.NavigationSkipped;
	constructor(id, url, reason, code) {
		super(id, url);
		this.reason = reason;
		this.code = code;
	}
};
var NavigationError = class extends RouterEvent {
	error;
	target;
	type = EventType.NavigationError;
	constructor(id, url, error, target) {
		super(id, url);
		this.error = error;
		this.target = target;
	}
	toString() {
		return `NavigationError(id: ${this.id}, url: '${this.url}', error: ${this.error})`;
	}
};
var RoutesRecognized = class extends RouterEvent {
	urlAfterRedirects;
	state;
	type = EventType.RoutesRecognized;
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `RoutesRecognized(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var GuardsCheckStart = class extends RouterEvent {
	urlAfterRedirects;
	state;
	type = EventType.GuardsCheckStart;
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `GuardsCheckStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var GuardsCheckEnd = class extends RouterEvent {
	urlAfterRedirects;
	state;
	shouldActivate;
	type = EventType.GuardsCheckEnd;
	constructor(id, url, urlAfterRedirects, state, shouldActivate) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
		this.shouldActivate = shouldActivate;
	}
	toString() {
		return `GuardsCheckEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state}, shouldActivate: ${this.shouldActivate})`;
	}
};
var ResolveStart = class extends RouterEvent {
	urlAfterRedirects;
	state;
	type = EventType.ResolveStart;
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `ResolveStart(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var ResolveEnd = class extends RouterEvent {
	urlAfterRedirects;
	state;
	type = EventType.ResolveEnd;
	constructor(id, url, urlAfterRedirects, state) {
		super(id, url);
		this.urlAfterRedirects = urlAfterRedirects;
		this.state = state;
	}
	toString() {
		return `ResolveEnd(id: ${this.id}, url: '${this.url}', urlAfterRedirects: '${this.urlAfterRedirects}', state: ${this.state})`;
	}
};
var RouteConfigLoadStart = class {
	route;
	type = EventType.RouteConfigLoadStart;
	constructor(route) {
		this.route = route;
	}
	toString() {
		return `RouteConfigLoadStart(path: ${this.route.path})`;
	}
};
var RouteConfigLoadEnd = class {
	route;
	type = EventType.RouteConfigLoadEnd;
	constructor(route) {
		this.route = route;
	}
	toString() {
		return `RouteConfigLoadEnd(path: ${this.route.path})`;
	}
};
var ChildActivationStart = class {
	snapshot;
	type = EventType.ChildActivationStart;
	constructor(snapshot) {
		this.snapshot = snapshot;
	}
	toString() {
		return `ChildActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ChildActivationEnd = class {
	snapshot;
	type = EventType.ChildActivationEnd;
	constructor(snapshot) {
		this.snapshot = snapshot;
	}
	toString() {
		return `ChildActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ActivationStart = class {
	snapshot;
	type = EventType.ActivationStart;
	constructor(snapshot) {
		this.snapshot = snapshot;
	}
	toString() {
		return `ActivationStart(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var ActivationEnd = class {
	snapshot;
	type = EventType.ActivationEnd;
	constructor(snapshot) {
		this.snapshot = snapshot;
	}
	toString() {
		return `ActivationEnd(path: '${this.snapshot.routeConfig && this.snapshot.routeConfig.path || ""}')`;
	}
};
var Scroll = class {
	routerEvent;
	position;
	anchor;
	scrollBehavior;
	type = EventType.Scroll;
	constructor(routerEvent, position, anchor, scrollBehavior) {
		this.routerEvent = routerEvent;
		this.position = position;
		this.anchor = anchor;
		this.scrollBehavior = scrollBehavior;
	}
	toString() {
		const pos = this.position ? `${this.position[0]}, ${this.position[1]}` : null;
		return `Scroll(anchor: '${this.anchor}', position: '${pos}')`;
	}
};
var BeforeActivateRoutes = class {};
var BeforeRoutesRecognized = class {};
var RedirectRequest = class {
	url;
	navigationBehaviorOptions;
	constructor(url, navigationBehaviorOptions) {
		this.url = url;
		this.navigationBehaviorOptions = navigationBehaviorOptions;
	}
};
function isPublicRouterEvent(e) {
	return !(e instanceof BeforeActivateRoutes) && !(e instanceof RedirectRequest) && !(e instanceof BeforeRoutesRecognized);
}
function stringifyEvent(routerEvent) {
	switch (routerEvent.type) {
		case EventType.ActivationEnd: return `ActivationEnd(path: '${routerEvent.snapshot.routeConfig?.path || ""}')`;
		case EventType.ActivationStart: return `ActivationStart(path: '${routerEvent.snapshot.routeConfig?.path || ""}')`;
		case EventType.ChildActivationEnd: return `ChildActivationEnd(path: '${routerEvent.snapshot.routeConfig?.path || ""}')`;
		case EventType.ChildActivationStart: return `ChildActivationStart(path: '${routerEvent.snapshot.routeConfig?.path || ""}')`;
		case EventType.GuardsCheckEnd: return `GuardsCheckEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state}, shouldActivate: ${routerEvent.shouldActivate})`;
		case EventType.GuardsCheckStart: return `GuardsCheckStart(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.NavigationCancel: return `NavigationCancel(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.NavigationSkipped: return `NavigationSkipped(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.NavigationEnd: return `NavigationEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}')`;
		case EventType.NavigationError: return `NavigationError(id: ${routerEvent.id}, url: '${routerEvent.url}', error: ${routerEvent.error})`;
		case EventType.NavigationStart: return `NavigationStart(id: ${routerEvent.id}, url: '${routerEvent.url}')`;
		case EventType.ResolveEnd: return `ResolveEnd(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.ResolveStart: return `ResolveStart(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.RouteConfigLoadEnd: return `RouteConfigLoadEnd(path: ${routerEvent.route.path})`;
		case EventType.RouteConfigLoadStart: return `RouteConfigLoadStart(path: ${routerEvent.route.path})`;
		case EventType.RoutesRecognized: return `RoutesRecognized(id: ${routerEvent.id}, url: '${routerEvent.url}', urlAfterRedirects: '${routerEvent.urlAfterRedirects}', state: ${routerEvent.state})`;
		case EventType.Scroll:
			const pos = routerEvent.position ? `${routerEvent.position[0]}, ${routerEvent.position[1]}` : null;
			return `Scroll(anchor: '${routerEvent.anchor}', position: '${pos}')`;
	}
}
var OutletContext = class {
	rootInjector;
	outlet = null;
	route = null;
	children;
	attachRef = null;
	get injector() {
		return this.route?.snapshot._environmentInjector ?? this.rootInjector;
	}
	constructor(rootInjector) {
		this.rootInjector = rootInjector;
		this.children = new ChildrenOutletContexts(this.rootInjector);
	}
};
var ChildrenOutletContexts = class ChildrenOutletContexts {
	rootInjector;
	contexts = /* @__PURE__ */ new Map();
	constructor(rootInjector) {
		this.rootInjector = rootInjector;
	}
	onChildOutletCreated(childName, outlet) {
		const context = this.getOrCreateContext(childName);
		context.outlet = outlet;
		this.contexts.set(childName, context);
	}
	onChildOutletDestroyed(childName) {
		const context = this.getContext(childName);
		if (context) {
			context.outlet = null;
			context.attachRef = null;
		}
	}
	onOutletDeactivated() {
		const contexts = this.contexts;
		this.contexts = /* @__PURE__ */ new Map();
		return contexts;
	}
	onOutletReAttached(contexts) {
		this.contexts = contexts;
	}
	getOrCreateContext(childName) {
		let context = this.getContext(childName);
		if (!context) {
			context = new OutletContext(this.rootInjector);
			this.contexts.set(childName, context);
		}
		return context;
	}
	getContext(childName) {
		return this.contexts.get(childName) || null;
	}
	static ɵfac = function ChildrenOutletContexts_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ChildrenOutletContexts)(ɵɵinject(EnvironmentInjector));
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: ChildrenOutletContexts,
		factory: ChildrenOutletContexts.ɵfac,
		providedIn: "root"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChildrenOutletContexts, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: EnvironmentInjector }], null);
})();
var Tree = class {
	_root;
	constructor(root) {
		this._root = root;
	}
	get root() {
		return this._root.value;
	}
	parent(t) {
		const p = this.pathFromRoot(t);
		return p.length > 1 ? p[p.length - 2] : null;
	}
	children(t) {
		const n = findNode(t, this._root);
		return n ? n.children.map((t) => t.value) : [];
	}
	firstChild(t) {
		const n = findNode(t, this._root);
		return n && n.children.length > 0 ? n.children[0].value : null;
	}
	siblings(t) {
		const p = findPath(t, this._root);
		if (p.length < 2) return [];
		return p[p.length - 2].children.map((c) => c.value).filter((cc) => cc !== t);
	}
	pathFromRoot(t) {
		return findPath(t, this._root).map((s) => s.value);
	}
};
function findNode(value, node) {
	if (value === node.value) return node;
	for (const child of node.children) {
		const node = findNode(value, child);
		if (node) return node;
	}
	return null;
}
function findPath(value, node) {
	if (value === node.value) return [node];
	for (const child of node.children) {
		const path = findPath(value, child);
		if (path.length) {
			path.unshift(node);
			return path;
		}
	}
	return [];
}
var TreeNode = class {
	value;
	children;
	constructor(value, children) {
		this.value = value;
		this.children = children;
	}
	toString() {
		return `TreeNode(${this.value})`;
	}
};
function nodeChildrenAsMap(node) {
	const map = {};
	if (node) node.children.forEach((child) => map[child.value.outlet] = child);
	return map;
}
var RouterState = class extends Tree {
	snapshot;
	constructor(root, snapshot) {
		super(root);
		this.snapshot = snapshot;
		setRouterState(this, root);
	}
	toString() {
		return this.snapshot.toString();
	}
};
function createEmptyState(rootComponent, injector) {
	const snapshot = createEmptyStateSnapshot(rootComponent, injector);
	const emptyUrl = new import_cjs.BehaviorSubject([new UrlSegment("", {})]);
	const emptyParams = new import_cjs.BehaviorSubject({});
	const emptyData = new import_cjs.BehaviorSubject({});
	const activated = new ActivatedRoute(emptyUrl, emptyParams, new import_cjs.BehaviorSubject({}), new import_cjs.BehaviorSubject(""), emptyData, PRIMARY_OUTLET, rootComponent, snapshot.root);
	activated.snapshot = snapshot.root;
	return new RouterState(new TreeNode(activated, []), snapshot);
}
function createEmptyStateSnapshot(rootComponent, injector) {
	return new RouterStateSnapshot("", new TreeNode(new ActivatedRouteSnapshot([], {}, {}, "", {}, PRIMARY_OUTLET, rootComponent, null, {}, injector), []));
}
var ActivatedRoute = class {
	urlSubject;
	paramsSubject;
	queryParamsSubject;
	fragmentSubject;
	dataSubject;
	outlet;
	component;
	snapshot;
	_futureSnapshot;
	_routerState;
	_paramMap;
	_queryParamMap;
	title;
	url;
	params;
	queryParams;
	fragment;
	data;
	_localInjector;
	constructor(urlSubject, paramsSubject, queryParamsSubject, fragmentSubject, dataSubject, outlet, component, futureSnapshot) {
		this.urlSubject = urlSubject;
		this.paramsSubject = paramsSubject;
		this.queryParamsSubject = queryParamsSubject;
		this.fragmentSubject = fragmentSubject;
		this.dataSubject = dataSubject;
		this.outlet = outlet;
		this.component = component;
		this._futureSnapshot = futureSnapshot;
		this.title = this.dataSubject?.pipe((0, import_operators.map)((d) => d[RouteTitleKey])) ?? (0, import_cjs.of)(void 0);
		this.url = urlSubject;
		this.params = paramsSubject;
		this.queryParams = queryParamsSubject;
		this.fragment = fragmentSubject;
		this.data = dataSubject;
	}
	get routeConfig() {
		return this._futureSnapshot.routeConfig;
	}
	get root() {
		return this._routerState.root;
	}
	get parent() {
		return this._routerState.parent(this);
	}
	get firstChild() {
		return this._routerState.firstChild(this);
	}
	get children() {
		return this._routerState.children(this);
	}
	get pathFromRoot() {
		return this._routerState.pathFromRoot(this);
	}
	get paramMap() {
		this._paramMap ??= this.params.pipe((0, import_operators.map)((p) => convertToParamMap(p)));
		return this._paramMap;
	}
	get queryParamMap() {
		this._queryParamMap ??= this.queryParams.pipe((0, import_operators.map)((p) => convertToParamMap(p)));
		return this._queryParamMap;
	}
	toString() {
		return this.snapshot ? this.snapshot.toString() : `Future(${this._futureSnapshot})`;
	}
};
var DEFAULT_PARAMS_INHERITANCE_STRATEGY = "always";
function getInherited(route, parent, paramsInheritanceStrategy) {
	let inherited;
	const { routeConfig } = route;
	if (parent !== null && (paramsInheritanceStrategy === "always" || routeConfig?.path === "" || !parent.component && !parent.routeConfig?.loadComponent)) inherited = {
		params: {
			...parent.params,
			...route.params
		},
		data: {
			...parent.data,
			...route.data
		},
		resolve: {
			...route.data,
			...parent.data,
			...routeConfig?.data,
			...route._resolvedData
		}
	};
	else inherited = {
		params: { ...route.params },
		data: { ...route.data },
		resolve: {
			...route.data,
			...route._resolvedData ?? {}
		}
	};
	if (routeConfig && hasStaticTitle(routeConfig)) inherited.resolve[RouteTitleKey] = routeConfig.title;
	return inherited;
}
var ActivatedRouteSnapshot = class {
	url;
	params;
	queryParams;
	fragment;
	data;
	outlet;
	component;
	routeConfig;
	_resolve;
	_resolvedData;
	_routerState;
	_paramMap;
	_queryParamMap;
	_environmentInjector;
	get title() {
		return this.data?.[RouteTitleKey];
	}
	constructor(url, params, queryParams, fragment, data, outlet, component, routeConfig, resolve, environmentInjector) {
		this.url = url;
		this.params = params;
		this.queryParams = queryParams;
		this.fragment = fragment;
		this.data = data;
		this.outlet = outlet;
		this.component = component;
		this.routeConfig = routeConfig;
		this._resolve = resolve;
		this._environmentInjector = environmentInjector;
	}
	get root() {
		return this._routerState.root;
	}
	get parent() {
		return this._routerState.parent(this);
	}
	get firstChild() {
		return this._routerState.firstChild(this);
	}
	get children() {
		return this._routerState.children(this);
	}
	get pathFromRoot() {
		return this._routerState.pathFromRoot(this);
	}
	get paramMap() {
		this._paramMap ??= convertToParamMap(this.params);
		return this._paramMap;
	}
	get queryParamMap() {
		this._queryParamMap ??= convertToParamMap(this.queryParams);
		return this._queryParamMap;
	}
	toString() {
		return `Route(url:'${this.url.map((segment) => segment.toString()).join("/")}', path:'${this.routeConfig ? this.routeConfig.path : ""}')`;
	}
};
var RouterStateSnapshot = class extends Tree {
	url;
	constructor(url, root) {
		super(root);
		this.url = url;
		setRouterState(this, root);
	}
	toString() {
		return serializeNode(this._root);
	}
};
function setRouterState(state, node) {
	node.value._routerState = state;
	node.children.forEach((c) => setRouterState(state, c));
}
function serializeNode(node) {
	const c = node.children.length > 0 ? ` { ${node.children.map(serializeNode).join(", ")} } ` : "";
	return `${node.value}${c}`;
}
function advanceActivatedRoute(route) {
	if (route.snapshot) {
		const currentSnapshot = route.snapshot;
		const nextSnapshot = route._futureSnapshot;
		route.snapshot = nextSnapshot;
		if (!shallowEqual(currentSnapshot.queryParams, nextSnapshot.queryParams)) route.queryParamsSubject.next(nextSnapshot.queryParams);
		if (currentSnapshot.fragment !== nextSnapshot.fragment) route.fragmentSubject.next(nextSnapshot.fragment);
		if (!shallowEqual(currentSnapshot.params, nextSnapshot.params)) route.paramsSubject.next(nextSnapshot.params);
		if (!shallowEqualArrays(currentSnapshot.url, nextSnapshot.url)) route.urlSubject.next(nextSnapshot.url);
		if (!shallowEqual(currentSnapshot.data, nextSnapshot.data)) route.dataSubject.next(nextSnapshot.data);
	} else {
		route.snapshot = route._futureSnapshot;
		route.dataSubject.next(route._futureSnapshot.data);
	}
}
function equalParamsAndUrlSegments(a, b) {
	const equalUrlParams = shallowEqual(a.params, b.params) && equalSegments(a.url, b.url);
	const parentsMismatch = !a.parent !== !b.parent;
	return equalUrlParams && !parentsMismatch && (!a.parent || equalParamsAndUrlSegments(a.parent, b.parent));
}
function hasStaticTitle(config) {
	return typeof config.title === "string" || config.title === null;
}
var ROUTER_OUTLET_DATA = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "RouterOutlet data" : "");
var RouterOutlet = class RouterOutlet {
	activated = null;
	get activatedComponentRef() {
		return this.activated;
	}
	_activatedRoute = null;
	name = PRIMARY_OUTLET;
	activateEvents = new EventEmitter();
	deactivateEvents = new EventEmitter();
	attachEvents = new EventEmitter();
	detachEvents = new EventEmitter();
	routerOutletData = input(...ngDevMode ? [void 0, { debugName: "routerOutletData" }] : []);
	parentContexts = inject(ChildrenOutletContexts);
	location = inject(ViewContainerRef);
	changeDetector = inject(ChangeDetectorRef);
	inputBinder = inject(INPUT_BINDER, { optional: true });
	supportsBindingToComponentInputs = true;
	ngOnChanges(changes) {
		if (changes["name"]) {
			const { firstChange, previousValue } = changes["name"];
			if (firstChange) return;
			if (this.isTrackedInParentContexts(previousValue)) {
				this.deactivate();
				this.parentContexts.onChildOutletDestroyed(previousValue);
			}
			this.initializeOutletWithName();
		}
	}
	ngOnDestroy() {
		if (this.isTrackedInParentContexts(this.name)) this.parentContexts.onChildOutletDestroyed(this.name);
		this.inputBinder?.unsubscribeFromRouteData(this);
	}
	isTrackedInParentContexts(outletName) {
		return this.parentContexts.getContext(outletName)?.outlet === this;
	}
	ngOnInit() {
		this.initializeOutletWithName();
	}
	initializeOutletWithName() {
		this.parentContexts.onChildOutletCreated(this.name, this);
		if (this.activated) return;
		const context = this.parentContexts.getContext(this.name);
		if (context?.route) if (context.attachRef) this.attach(context.attachRef, context.route);
		else this.activateWith(context.route, context.injector);
	}
	get isActivated() {
		return !!this.activated;
	}
	get component() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		return this.activated.instance;
	}
	get activatedRoute() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		return this._activatedRoute;
	}
	get activatedRouteData() {
		if (this._activatedRoute) return this._activatedRoute.snapshot.data;
		return {};
	}
	detach() {
		if (!this.activated) throw new RuntimeError(4012, (typeof ngDevMode === "undefined" || ngDevMode) && "Outlet is not activated");
		this.location.detach();
		const cmp = this.activated;
		this.activated = null;
		this._activatedRoute = null;
		this.detachEvents.emit(cmp.instance);
		return cmp;
	}
	attach(ref, activatedRoute) {
		this.activated = ref;
		this._activatedRoute = activatedRoute;
		this.location.insert(ref.hostView);
		this.inputBinder?.bindActivatedRouteToOutletComponent(this);
		this.attachEvents.emit(ref.instance);
	}
	deactivate() {
		if (this.activated) {
			const c = this.component;
			this.activated.destroy();
			this.activated = null;
			this._activatedRoute = null;
			this.deactivateEvents.emit(c);
		}
	}
	activateWith(activatedRoute, environmentInjector) {
		if (this.isActivated) throw new RuntimeError(4013, (typeof ngDevMode === "undefined" || ngDevMode) && "Cannot activate an already activated outlet");
		this._activatedRoute = activatedRoute;
		const location = this.location;
		const component = activatedRoute.snapshot.component;
		const childContexts = this.parentContexts.getOrCreateContext(this.name).children;
		const injector = new OutletInjector(activatedRoute, childContexts, location.injector, this.routerOutletData);
		this.activated = location.createComponent(component, {
			index: location.length,
			injector,
			environmentInjector
		});
		this.changeDetector.markForCheck();
		this.inputBinder?.bindActivatedRouteToOutletComponent(this);
		this.activateEvents.emit(this.activated.instance);
	}
	static ɵfac = function RouterOutlet_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterOutlet)();
	};
	static ɵdir = /* @__PURE__ */ ɵɵdefineDirective({
		type: RouterOutlet,
		selectors: [["router-outlet"]],
		inputs: {
			name: "name",
			routerOutletData: [1, "routerOutletData"]
		},
		outputs: {
			activateEvents: "activate",
			deactivateEvents: "deactivate",
			attachEvents: "attach",
			detachEvents: "detach"
		},
		exportAs: ["outlet"],
		features: [ɵɵNgOnChangesFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterOutlet, [{
		type: Directive,
		args: [{
			selector: "router-outlet",
			exportAs: "outlet"
		}]
	}], null, {
		name: [{ type: Input }],
		activateEvents: [{
			type: Output,
			args: ["activate"]
		}],
		deactivateEvents: [{
			type: Output,
			args: ["deactivate"]
		}],
		attachEvents: [{
			type: Output,
			args: ["attach"]
		}],
		detachEvents: [{
			type: Output,
			args: ["detach"]
		}],
		routerOutletData: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "routerOutletData",
				required: false
			}]
		}]
	});
})();
var OutletInjector = class {
	route;
	childContexts;
	parent;
	outletData;
	constructor(route, childContexts, parent, outletData) {
		this.route = route;
		this.childContexts = childContexts;
		this.parent = parent;
		this.outletData = outletData;
	}
	get(token, notFoundValue) {
		if (token === ActivatedRoute) return this.route;
		if (token === ChildrenOutletContexts) return this.childContexts;
		if (token === ROUTER_OUTLET_DATA) return this.outletData;
		return this.parent.get(token, notFoundValue);
	}
};
var INPUT_BINDER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Router Input Binder" : "");
var RoutedComponentInputBinder = class RoutedComponentInputBinder {
	options;
	outletDataSubscriptions = /* @__PURE__ */ new Map();
	outletSeenKeys = /* @__PURE__ */ new Map();
	constructor(options) {
		this.options = options;
		this.options.queryParams ??= true;
	}
	bindActivatedRouteToOutletComponent(outlet) {
		this.unsubscribeFromRouteData(outlet);
		this.subscribeToRouteData(outlet);
	}
	unsubscribeFromRouteData(outlet) {
		this.outletDataSubscriptions.get(outlet)?.unsubscribe();
		this.outletDataSubscriptions.delete(outlet);
		this.outletSeenKeys.delete(outlet);
	}
	subscribeToRouteData(outlet) {
		const { activatedRoute } = outlet;
		const dataSubscription = (0, import_cjs.combineLatest)([
			this.options.queryParams ? activatedRoute.queryParams : (0, import_cjs.of)({}),
			activatedRoute.params,
			activatedRoute.data
		]).pipe((0, import_operators.switchMap)(([queryParams, params, data], index) => {
			data = {
				...queryParams,
				...params,
				...data
			};
			if (index === 0) return (0, import_cjs.of)(data);
			return Promise.resolve(data);
		})).subscribe((data) => {
			if (!outlet.isActivated || !outlet.activatedComponentRef || outlet.activatedRoute !== activatedRoute || activatedRoute.component === null) {
				this.unsubscribeFromRouteData(outlet);
				return;
			}
			const mirror = reflectComponentType(activatedRoute.component);
			if (!mirror) {
				this.unsubscribeFromRouteData(outlet);
				return;
			}
			let seenKeys = this.outletSeenKeys.get(outlet);
			if (!seenKeys) {
				seenKeys = /* @__PURE__ */ new Set();
				this.outletSeenKeys.set(outlet, seenKeys);
			}
			for (const key of Object.keys(data)) seenKeys.add(key);
			const behavior = this.options.unmatchedInputBehavior ?? "alwaysUndefined";
			for (const { templateName } of mirror.inputs) {
				const value = data[templateName];
				if (value !== void 0 || behavior === "alwaysUndefined" || seenKeys.has(templateName)) outlet.activatedComponentRef.setInput(templateName, value);
			}
		});
		this.outletDataSubscriptions.set(outlet, dataSubscription);
	}
	static ɵfac = function RoutedComponentInputBinder_Factory(__ngFactoryType__) {
		ɵɵinvalidFactory();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: RoutedComponentInputBinder,
		factory: RoutedComponentInputBinder.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RoutedComponentInputBinder, [{ type: Injectable }], () => [{ type: void 0 }], null);
})();
var ɵEmptyOutletComponent = class ɵEmptyOutletComponent {
	static ɵfac = function ɵEmptyOutletComponent_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ɵEmptyOutletComponent)();
	};
	static ɵcmp = /* @__PURE__ */ ɵɵdefineComponent({
		type: ɵEmptyOutletComponent,
		selectors: [["ng-component"]],
		exportAs: ["emptyRouterOutlet"],
		decls: 1,
		vars: 0,
		template: function _EmptyOutletComponent_Template(rf, ctx) {
			if (rf & 1) ɵɵelement(0, "router-outlet");
		},
		dependencies: [RouterOutlet],
		encapsulation: 2,
		changeDetection: 1
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ɵEmptyOutletComponent, [{
		type: Component,
		args: [{
			template: `<router-outlet />`,
			imports: [RouterOutlet],
			exportAs: "emptyRouterOutlet",
			changeDetection: ChangeDetectionStrategy.Eager
		}]
	}], null, null);
})();
function standardizeConfig(r) {
	const children = r.children && r.children.map(standardizeConfig);
	const c = children ? {
		...r,
		children
	} : { ...r };
	if (!c.component && !c.loadComponent && (children || c.loadChildren) && c.outlet && c.outlet !== "primary") c.component = ɵEmptyOutletComponent;
	return c;
}
function createRouterState(routeReuseStrategy, curr, prevState) {
	const newlyCreatedRoutes = /* @__PURE__ */ new Set();
	return {
		newlyCreatedRoutes,
		state: new RouterState(createNode(routeReuseStrategy, curr._root, prevState ? prevState._root : void 0, newlyCreatedRoutes), curr)
	};
}
function createNode(routeReuseStrategy, curr, prevState, newlyCreatedRoutes) {
	if (prevState && routeReuseStrategy.shouldReuseRoute(curr.value, prevState.value.snapshot)) {
		const value = prevState.value;
		value._futureSnapshot = curr.value;
		return new TreeNode(value, createOrReuseChildren(routeReuseStrategy, curr, prevState, newlyCreatedRoutes));
	} else {
		if (routeReuseStrategy.shouldAttach(curr.value)) {
			const detachedRouteHandle = routeReuseStrategy.retrieve(curr.value);
			if (detachedRouteHandle !== null) {
				const tree = detachedRouteHandle.route;
				tree.value._futureSnapshot = curr.value;
				tree.children = curr.children.map((c) => createNode(routeReuseStrategy, c, void 0, newlyCreatedRoutes));
				return tree;
			}
		}
		const value = createActivatedRoute(curr.value);
		newlyCreatedRoutes.add(value);
		return new TreeNode(value, curr.children.map((c) => createNode(routeReuseStrategy, c, void 0, newlyCreatedRoutes)));
	}
}
function createOrReuseChildren(routeReuseStrategy, curr, prevState, newlyCreatedRoutes) {
	return curr.children.map((child) => {
		for (const p of prevState.children) if (routeReuseStrategy.shouldReuseRoute(child.value, p.value.snapshot)) return createNode(routeReuseStrategy, child, p, newlyCreatedRoutes);
		return createNode(routeReuseStrategy, child, void 0, newlyCreatedRoutes);
	});
}
function createActivatedRoute(c) {
	return new ActivatedRoute(new import_cjs.BehaviorSubject(c.url), new import_cjs.BehaviorSubject(c.params), new import_cjs.BehaviorSubject(c.queryParams), new import_cjs.BehaviorSubject(c.fragment), new import_cjs.BehaviorSubject(c.data), c.outlet, c.component, c);
}
var RedirectCommand = class {
	redirectTo;
	navigationBehaviorOptions;
	constructor(redirectTo, navigationBehaviorOptions) {
		this.redirectTo = redirectTo;
		this.navigationBehaviorOptions = navigationBehaviorOptions;
	}
};
var NAVIGATION_CANCELING_ERROR = "ngNavigationCancelingError";
function redirectingNavigationError(urlSerializer, redirect) {
	const { redirectTo, navigationBehaviorOptions } = isUrlTree(redirect) ? {
		redirectTo: redirect,
		navigationBehaviorOptions: void 0
	} : redirect;
	const error = navigationCancelingError(ngDevMode && `Redirecting to "${urlSerializer.serialize(redirectTo)}"`, NavigationCancellationCode.Redirect);
	error.url = redirectTo;
	error.navigationBehaviorOptions = navigationBehaviorOptions;
	return error;
}
function navigationCancelingError(message, code) {
	const error = /* @__PURE__ */ new Error(`NavigationCancelingError: ${message || ""}`);
	error[NAVIGATION_CANCELING_ERROR] = true;
	error.cancellationCode = code;
	return error;
}
function isRedirectingNavigationCancelingError(error) {
	return isNavigationCancelingError(error) && isUrlTree(error.url);
}
function isNavigationCancelingError(error) {
	return !!error && error[NAVIGATION_CANCELING_ERROR];
}
var warnedAboutUnsupportedInputBinding = false;
var ActivateRoutes = class {
	routeReuseStrategy;
	futureState;
	currState;
	forwardEvent;
	inputBindingEnabled;
	constructor(routeReuseStrategy, futureState, currState, forwardEvent, inputBindingEnabled) {
		this.routeReuseStrategy = routeReuseStrategy;
		this.futureState = futureState;
		this.currState = currState;
		this.forwardEvent = forwardEvent;
		this.inputBindingEnabled = inputBindingEnabled;
	}
	activate(parentContexts) {
		const futureRoot = this.futureState._root;
		const currRoot = this.currState ? this.currState._root : null;
		this.deactivateChildRoutes(futureRoot, currRoot, parentContexts);
		advanceActivatedRoute(this.futureState.root);
		this.activateChildRoutes(futureRoot, currRoot, parentContexts);
	}
	deactivateChildRoutes(futureNode, currNode, contexts) {
		const children = nodeChildrenAsMap(currNode);
		futureNode.children.forEach((futureChild) => {
			const childOutletName = futureChild.value.outlet;
			this.deactivateRoutes(futureChild, children[childOutletName], contexts);
			delete children[childOutletName];
		});
		Object.values(children).forEach((v) => {
			this.deactivateRouteAndItsChildren(v, contexts);
		});
	}
	deactivateRoutes(futureNode, currNode, parentContext) {
		const future = futureNode.value;
		const curr = currNode ? currNode.value : null;
		if (future === curr) if (future.component) {
			const context = parentContext.getContext(future.outlet);
			if (context) this.deactivateChildRoutes(futureNode, currNode, context.children);
		} else this.deactivateChildRoutes(futureNode, currNode, parentContext);
		else if (curr) this.deactivateRouteAndItsChildren(currNode, parentContext);
	}
	deactivateRouteAndItsChildren(route, parentContexts) {
		if (route.value.component && this.routeReuseStrategy.shouldDetach(route.value.snapshot)) this.detachAndStoreRouteSubtree(route, parentContexts);
		else this.deactivateRouteAndOutlet(route, parentContexts);
	}
	detachAndStoreRouteSubtree(route, parentContexts) {
		const context = parentContexts.getContext(route.value.outlet);
		const contexts = context && route.value.component ? context.children : parentContexts;
		const children = nodeChildrenAsMap(route);
		for (const treeNode of Object.values(children)) this.deactivateRouteAndItsChildren(treeNode, contexts);
		if (context && context.outlet) {
			const componentRef = context.outlet.detach();
			const contexts = context.children.onOutletDeactivated();
			this.routeReuseStrategy.store(route.value.snapshot, {
				componentRef,
				route,
				contexts
			});
		}
	}
	deactivateRouteAndOutlet(route, parentContexts) {
		const context = parentContexts.getContext(route.value.outlet);
		const contexts = context && route.value.component ? context.children : parentContexts;
		const children = nodeChildrenAsMap(route);
		for (const treeNode of Object.values(children)) this.deactivateRouteAndItsChildren(treeNode, contexts);
		if (context) {
			if (context.outlet) {
				context.outlet.deactivate();
				context.children.onOutletDeactivated();
			}
			context.attachRef = null;
			context.route = null;
		}
		route.value._localInjector?.destroy();
	}
	activateChildRoutes(futureNode, currNode, contexts) {
		const children = nodeChildrenAsMap(currNode);
		futureNode.children.forEach((c) => {
			this.activateRoutes(c, children[c.value.outlet], contexts);
			this.forwardEvent(new ActivationEnd(c.value.snapshot));
		});
		if (futureNode.children.length) this.forwardEvent(new ChildActivationEnd(futureNode.value.snapshot));
	}
	activateRoutes(futureNode, currNode, parentContexts) {
		const future = futureNode.value;
		const curr = currNode ? currNode.value : null;
		advanceActivatedRoute(future);
		if (future === curr) if (future.component) {
			const context = parentContexts.getOrCreateContext(future.outlet);
			this.activateChildRoutes(futureNode, currNode, context.children);
		} else this.activateChildRoutes(futureNode, currNode, parentContexts);
		else if (future.component) {
			const context = parentContexts.getOrCreateContext(future.outlet);
			if (this.routeReuseStrategy.shouldAttach(future.snapshot)) {
				const stored = this.routeReuseStrategy.retrieve(future.snapshot);
				this.routeReuseStrategy.store(future.snapshot, null);
				context.children.onOutletReAttached(stored.contexts);
				context.attachRef = stored.componentRef;
				context.route = stored.route.value;
				if (context.outlet) context.outlet.attach(stored.componentRef, stored.route.value);
				advanceActivatedRoute(stored.route.value);
				this.activateChildRoutes(futureNode, null, context.children);
			} else {
				context.attachRef = null;
				context.route = future;
				if (context.outlet) context.outlet.activateWith(future, context.injector);
				this.activateChildRoutes(futureNode, null, context.children);
			}
		} else this.activateChildRoutes(futureNode, null, parentContexts);
		if (typeof ngDevMode === "undefined" || ngDevMode) {
			const outlet = parentContexts.getOrCreateContext(future.outlet).outlet;
			if (outlet && this.inputBindingEnabled && !outlet.supportsBindingToComponentInputs && !warnedAboutUnsupportedInputBinding) {
				console.warn("'withComponentInputBinding' feature is enabled but this application is using an outlet that may not support binding to component inputs.");
				warnedAboutUnsupportedInputBinding = true;
			}
		}
	}
};
var CanActivate = class {
	path;
	route;
	constructor(path) {
		this.path = path;
		this.route = this.path[this.path.length - 1];
	}
};
var CanDeactivate = class {
	component;
	route;
	constructor(component, route) {
		this.component = component;
		this.route = route;
	}
};
function getAllRouteGuards(future, curr, parentContexts) {
	const futureRoot = future._root;
	return getChildRouteGuards(futureRoot, curr ? curr._root : null, parentContexts, [futureRoot.value]);
}
function getCanActivateChild(p) {
	const canActivateChild = p.routeConfig ? p.routeConfig.canActivateChild : null;
	if (!canActivateChild || canActivateChild.length === 0) return null;
	return {
		node: p,
		guards: canActivateChild
	};
}
function getTokenOrFunctionIdentity(tokenOrFunction, injector) {
	const NOT_FOUND = Symbol();
	const result = injector.get(tokenOrFunction, NOT_FOUND);
	if (result === NOT_FOUND) if (typeof tokenOrFunction === "function" && !isInjectable(tokenOrFunction)) return tokenOrFunction;
	else return injector.get(tokenOrFunction);
	return result;
}
function getChildRouteGuards(futureNode, currNode, contexts, futurePath, checks = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	const prevChildren = nodeChildrenAsMap(currNode);
	futureNode.children.forEach((c) => {
		getRouteGuards(c, prevChildren[c.value.outlet], contexts, futurePath.concat([c.value]), checks);
		delete prevChildren[c.value.outlet];
	});
	Object.entries(prevChildren).forEach(([k, v]) => deactivateRouteAndItsChildren(v, contexts.getContext(k), checks));
	return checks;
}
function getRouteGuards(futureNode, currNode, parentContexts, futurePath, checks = {
	canDeactivateChecks: [],
	canActivateChecks: []
}) {
	const future = futureNode.value;
	const curr = currNode ? currNode.value : null;
	const context = parentContexts ? parentContexts.getContext(futureNode.value.outlet) : null;
	if (curr && future.routeConfig === curr.routeConfig) {
		const shouldRun = shouldRunGuardsAndResolvers(curr, future, future.routeConfig.runGuardsAndResolvers);
		if (shouldRun) checks.canActivateChecks.push(new CanActivate(futurePath));
		else {
			future.data = curr.data;
			future._resolvedData = curr._resolvedData;
		}
		if (future.component) getChildRouteGuards(futureNode, currNode, context ? context.children : null, futurePath, checks);
		else getChildRouteGuards(futureNode, currNode, parentContexts, futurePath, checks);
		if (shouldRun && context && context.outlet && context.outlet.isActivated) checks.canDeactivateChecks.push(new CanDeactivate(context.outlet.component, curr));
	} else {
		if (curr) deactivateRouteAndItsChildren(currNode, context, checks);
		checks.canActivateChecks.push(new CanActivate(futurePath));
		if (future.component) getChildRouteGuards(futureNode, null, context ? context.children : null, futurePath, checks);
		else getChildRouteGuards(futureNode, null, parentContexts, futurePath, checks);
	}
	return checks;
}
function shouldRunGuardsAndResolvers(curr, future, mode) {
	if (typeof mode === "function") return runInInjectionContext(future._environmentInjector, () => mode(curr, future));
	switch (mode) {
		case "pathParamsChange": return !equalPath(curr.url, future.url);
		case "pathParamsOrQueryParamsChange": return !equalPath(curr.url, future.url) || !shallowEqual(curr.queryParams, future.queryParams);
		case "always": return true;
		case "paramsOrQueryParamsChange": return !equalParamsAndUrlSegments(curr, future) || !shallowEqual(curr.queryParams, future.queryParams);
		default: return !equalParamsAndUrlSegments(curr, future);
	}
}
function deactivateRouteAndItsChildren(route, context, checks) {
	const children = nodeChildrenAsMap(route);
	const r = route.value;
	Object.entries(children).forEach(([childName, node]) => {
		if (!r.component) deactivateRouteAndItsChildren(node, context, checks);
		else if (context) deactivateRouteAndItsChildren(node, context.children.getContext(childName), checks);
		else deactivateRouteAndItsChildren(node, null, checks);
	});
	if (!r.component) checks.canDeactivateChecks.push(new CanDeactivate(null, r));
	else if (context && context.outlet && context.outlet.isActivated) checks.canDeactivateChecks.push(new CanDeactivate(context.outlet.component, r));
	else checks.canDeactivateChecks.push(new CanDeactivate(null, r));
}
function isFunction(v) {
	return typeof v === "function";
}
function isBoolean(v) {
	return typeof v === "boolean";
}
function isCanLoad(guard) {
	return guard && isFunction(guard.canLoad);
}
function isCanActivate(guard) {
	return guard && isFunction(guard.canActivate);
}
function isCanActivateChild(guard) {
	return guard && isFunction(guard.canActivateChild);
}
function isCanDeactivate(guard) {
	return guard && isFunction(guard.canDeactivate);
}
function isCanMatch(guard) {
	return guard && isFunction(guard.canMatch);
}
function isEmptyError(e) {
	return e instanceof import_cjs.EmptyError || e?.name === "EmptyError";
}
var INITIAL_VALUE = /* @__PURE__ */ Symbol("INITIAL_VALUE");
function prioritizedGuardValue() {
	return (0, import_operators.switchMap)((obs) => {
		return (0, import_cjs.combineLatest)(obs.map((o) => o.pipe((0, import_operators.take)(1), (0, import_operators.startWith)(INITIAL_VALUE)))).pipe((0, import_operators.map)((results) => {
			for (const result of results) if (result === true) continue;
			else if (result === INITIAL_VALUE) return INITIAL_VALUE;
			else if (result === false || isRedirect(result)) return result;
			return true;
		}), (0, import_operators.filter)((item) => item !== INITIAL_VALUE), (0, import_operators.take)(1));
	});
}
function isRedirect(val) {
	return isUrlTree(val) || val instanceof RedirectCommand;
}
function abortSignalToObservable(signal) {
	if (signal.aborted) return (0, import_cjs.of)(void 0).pipe((0, import_operators.take)(1));
	return new import_cjs.Observable((subscriber) => {
		const handler = () => {
			subscriber.next();
			subscriber.complete();
		};
		signal.addEventListener("abort", handler);
		return () => signal.removeEventListener("abort", handler);
	});
}
function takeUntilAbort(signal) {
	return (0, import_operators.takeUntil)(abortSignalToObservable(signal));
}
function checkGuards(forwardEvent) {
	return (0, import_operators.mergeMap)((t) => {
		const { targetSnapshot, currentSnapshot, guards: { canActivateChecks, canDeactivateChecks } } = t;
		if (canDeactivateChecks.length === 0 && canActivateChecks.length === 0) return (0, import_cjs.of)({
			...t,
			guardsResult: true
		});
		return runCanDeactivateChecks(canDeactivateChecks, targetSnapshot, currentSnapshot).pipe((0, import_operators.mergeMap)((canDeactivate) => {
			return canDeactivate && isBoolean(canDeactivate) ? runCanActivateChecks(targetSnapshot, canActivateChecks, forwardEvent) : (0, import_cjs.of)(canDeactivate);
		}), (0, import_operators.map)((guardsResult) => ({
			...t,
			guardsResult
		})));
	});
}
function runCanDeactivateChecks(checks, futureRSS, currRSS) {
	return (0, import_cjs.from)(checks).pipe((0, import_operators.mergeMap)((check) => runCanDeactivate(check.component, check.route, currRSS, futureRSS)), (0, import_operators.first)((result) => {
		return result !== true;
	}, true));
}
function runCanActivateChecks(futureSnapshot, checks, forwardEvent) {
	return (0, import_cjs.from)(checks).pipe((0, import_operators.concatMap)((check) => {
		return (0, import_cjs.concat)(fireChildActivationStart(check.route.parent, forwardEvent), fireActivationStart(check.route, forwardEvent), runCanActivateChild(futureSnapshot, check.path), runCanActivate(futureSnapshot, check.route));
	}), (0, import_operators.first)((result) => {
		return result !== true;
	}, true));
}
function fireActivationStart(snapshot, forwardEvent) {
	if (snapshot !== null && forwardEvent) forwardEvent(new ActivationStart(snapshot));
	return (0, import_cjs.of)(true);
}
function fireChildActivationStart(snapshot, forwardEvent) {
	if (snapshot !== null && forwardEvent) forwardEvent(new ChildActivationStart(snapshot));
	return (0, import_cjs.of)(true);
}
function runCanActivate(futureRSS, futureARS) {
	const canActivate = futureARS.routeConfig ? futureARS.routeConfig.canActivate : null;
	if (!canActivate || canActivate.length === 0) return (0, import_cjs.of)(true);
	return (0, import_cjs.of)(canActivate.map((canActivate) => {
		return (0, import_cjs.defer)(() => {
			const closestInjector = futureARS._environmentInjector;
			const guard = getTokenOrFunctionIdentity(canActivate, closestInjector);
			return wrapIntoObservable(isCanActivate(guard) ? guard.canActivate(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => guard(futureARS, futureRSS))).pipe((0, import_operators.first)());
		});
	})).pipe(prioritizedGuardValue());
}
function runCanActivateChild(futureRSS, path) {
	const futureARS = path[path.length - 1];
	return (0, import_cjs.of)(path.slice(0, path.length - 1).reverse().map((p) => getCanActivateChild(p)).filter((_) => _ !== null).map((d) => {
		return (0, import_cjs.defer)(() => {
			return (0, import_cjs.of)(d.guards.map((canActivateChild) => {
				const closestInjector = d.node._environmentInjector;
				const guard = getTokenOrFunctionIdentity(canActivateChild, closestInjector);
				return wrapIntoObservable(isCanActivateChild(guard) ? guard.canActivateChild(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => guard(futureARS, futureRSS))).pipe((0, import_operators.first)());
			})).pipe(prioritizedGuardValue());
		});
	})).pipe(prioritizedGuardValue());
}
function runCanDeactivate(component, currARS, currRSS, futureRSS) {
	const canDeactivate = currARS && currARS.routeConfig ? currARS.routeConfig.canDeactivate : null;
	if (!canDeactivate || canDeactivate.length === 0) return (0, import_cjs.of)(true);
	return (0, import_cjs.of)(canDeactivate.map((c) => {
		const closestInjector = currARS._environmentInjector;
		const guard = getTokenOrFunctionIdentity(c, closestInjector);
		return wrapIntoObservable(isCanDeactivate(guard) ? guard.canDeactivate(component, currARS, currRSS, futureRSS) : runInInjectionContext(closestInjector, () => guard(component, currARS, currRSS, futureRSS))).pipe((0, import_operators.first)());
	})).pipe(prioritizedGuardValue());
}
function runCanLoadGuards(injector, route, segments, urlSerializer, abortSignal) {
	const canLoad = route.canLoad;
	if (canLoad === void 0 || canLoad.length === 0) return (0, import_cjs.of)(true);
	return (0, import_cjs.of)(canLoad.map((injectionToken) => {
		const guard = getTokenOrFunctionIdentity(injectionToken, injector);
		const obs$ = wrapIntoObservable(isCanLoad(guard) ? guard.canLoad(route, segments) : runInInjectionContext(injector, () => guard(route, segments)));
		return abortSignal ? obs$.pipe(takeUntilAbort(abortSignal)) : obs$;
	})).pipe(prioritizedGuardValue(), redirectIfUrlTree(urlSerializer));
}
function redirectIfUrlTree(urlSerializer) {
	return (0, import_cjs.pipe)((0, import_operators.tap)((result) => {
		if (typeof result === "boolean") return;
		throw redirectingNavigationError(urlSerializer, result);
	}), (0, import_operators.map)((result) => result === true));
}
function runCanMatchGuards(injector, route, segments, urlSerializer, currentSnapshot, abortSignal) {
	const canMatch = route.canMatch;
	if (!canMatch || canMatch.length === 0) return (0, import_cjs.of)(true);
	return (0, import_cjs.of)(canMatch.map((injectionToken) => {
		const guard = getTokenOrFunctionIdentity(injectionToken, injector);
		return wrapIntoObservable(isCanMatch(guard) ? guard.canMatch(route, segments, currentSnapshot) : runInInjectionContext(injector, () => guard(route, segments, currentSnapshot))).pipe(takeUntilAbort(abortSignal));
	})).pipe(prioritizedGuardValue(), redirectIfUrlTree(urlSerializer));
}
var NoMatch = class NoMatch extends Error {
	segmentGroup;
	constructor(segmentGroup) {
		super();
		this.segmentGroup = segmentGroup || null;
		Object.setPrototypeOf(this, NoMatch.prototype);
	}
};
var AbsoluteRedirect = class AbsoluteRedirect extends Error {
	urlTree;
	constructor(urlTree) {
		super();
		this.urlTree = urlTree;
		Object.setPrototypeOf(this, AbsoluteRedirect.prototype);
	}
};
function namedOutletsRedirect(redirectTo) {
	throw new RuntimeError(4e3, (typeof ngDevMode === "undefined" || ngDevMode) && `Only absolute redirects can have named outlets. redirectTo: '${redirectTo}'`);
}
function canLoadFails(route) {
	throw navigationCancelingError((typeof ngDevMode === "undefined" || ngDevMode) && `Cannot load children because the guard of the route "path: '${route.path}'" returned false`, NavigationCancellationCode.GuardRejected);
}
var ApplyRedirects = class {
	urlSerializer;
	urlTree;
	constructor(urlSerializer, urlTree) {
		this.urlSerializer = urlSerializer;
		this.urlTree = urlTree;
	}
	async lineralizeSegments(route, urlTree) {
		let res = [];
		let c = urlTree.root;
		while (true) {
			res = res.concat(c.segments);
			if (c.numberOfChildren === 0) return res;
			if (c.numberOfChildren > 1 || !c.children["primary"]) throw namedOutletsRedirect(`${route.redirectTo}`);
			c = c.children[PRIMARY_OUTLET];
		}
	}
	async applyRedirectCommands(segments, redirectTo, posParams, currentSnapshot, injector) {
		const redirect = await getRedirectResult(redirectTo, currentSnapshot, injector);
		if (redirect instanceof UrlTree) throw new AbsoluteRedirect(redirect);
		const newTree = this.applyRedirectCreateUrlTree(redirect, this.urlSerializer.parse(redirect), segments, posParams);
		if (redirect[0] === "/") throw new AbsoluteRedirect(newTree);
		return newTree;
	}
	applyRedirectCreateUrlTree(redirectTo, urlTree, segments, posParams) {
		return new UrlTree(this.createSegmentGroup(redirectTo, urlTree.root, segments, posParams), this.createQueryParams(urlTree.queryParams, this.urlTree.queryParams), urlTree.fragment);
	}
	createQueryParams(redirectToParams, actualParams) {
		const res = {};
		Object.entries(redirectToParams).forEach(([k, v]) => {
			if (typeof v === "string" && v[0] === ":") {
				const sourceName = v.substring(1);
				res[k] = actualParams[sourceName];
			} else res[k] = v;
		});
		return res;
	}
	createSegmentGroup(redirectTo, group, segments, posParams) {
		const updatedSegments = this.createSegments(redirectTo, group.segments, segments, posParams);
		let children = Object.create(null);
		Object.entries(group.children).forEach(([name, child]) => {
			children[name] = this.createSegmentGroup(redirectTo, child, segments, posParams);
		});
		return new UrlSegmentGroup(updatedSegments, children);
	}
	createSegments(redirectTo, redirectToSegments, actualSegments, posParams) {
		return redirectToSegments.map((s) => s.path[0] === ":" ? this.findPosParam(redirectTo, s, posParams) : this.findOrReturn(s, actualSegments));
	}
	findPosParam(redirectTo, redirectToUrlSegment, posParams) {
		const pos = posParams[redirectToUrlSegment.path.substring(1)];
		if (!pos) throw new RuntimeError(4001, (typeof ngDevMode === "undefined" || ngDevMode) && `Cannot redirect to '${redirectTo}'. Cannot find '${redirectToUrlSegment.path}'.`);
		return pos;
	}
	findOrReturn(redirectToUrlSegment, actualSegments) {
		let idx = 0;
		for (const s of actualSegments) {
			if (s.path === redirectToUrlSegment.path) {
				actualSegments.splice(idx);
				return s;
			}
			idx++;
		}
		return redirectToUrlSegment;
	}
};
function getRedirectResult(redirectTo, currentSnapshot, injector) {
	if (typeof redirectTo === "string") return Promise.resolve(redirectTo);
	const redirectToFn = redirectTo;
	return firstValueFrom(wrapIntoObservable(runInInjectionContext(injector, () => redirectToFn(currentSnapshot))));
}
function getOrCreateRouteInjectorIfNeeded(route, currentInjector) {
	if (route.providers && !route._injector) route._injector = createEnvironmentInjector(route.providers, currentInjector, `Route: ${route.path}`);
	return route._injector ?? currentInjector;
}
function validateConfig(config, parentPath = "", requireStandaloneComponents = false) {
	for (let i = 0; i < config.length; i++) {
		const route = config[i];
		validateNode(route, getFullPath(parentPath, route), requireStandaloneComponents);
	}
}
function assertStandalone(fullPath, component) {
	if (component && isNgModule(component)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. You are using 'loadComponent' with a module, but it must be used with standalone components. Use 'loadChildren' instead.`);
	else if (component && !isStandalone(component)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. The component must be standalone.`);
}
function validateNode(route, fullPath, requireStandaloneComponents) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		if (!route) throw new RuntimeError(4014, `
      Invalid configuration of route '${fullPath}': Encountered undefined route.
      The reason might be an extra comma.

      Example:
      const routes: Routes = [
        { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
        { path: 'dashboard',  component: DashboardComponent },, << two commas
        { path: 'detail/:id', component: HeroDetailComponent }
      ];
    `);
		if (Array.isArray(route)) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': Array cannot be specified`);
		if (!route.redirectTo && !route.component && !route.loadComponent && !route.children && !route.loadChildren && route.outlet && route.outlet !== "primary") throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': a componentless route without children or loadChildren cannot have a named outlet set`);
		if (route.redirectTo && route.children) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and children cannot be used together`);
		if (route.redirectTo && route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and loadChildren cannot be used together`);
		if (route.children && route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': children and loadChildren cannot be used together`);
		if (route.component && route.loadComponent) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': component and loadComponent cannot be used together`);
		if (route.redirectTo) {
			if (route.component || route.loadComponent) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and component/loadComponent cannot be used together`);
			if (route.canMatch || route.canActivate) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': redirectTo and ${route.canMatch ? "canMatch" : "canActivate"} cannot be used together.Redirects happen before guards are executed.`);
		}
		if (route.path && route.matcher) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': path and matcher cannot be used together`);
		if (route.redirectTo === void 0 && !route.component && !route.loadComponent && !route.children && !route.loadChildren) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}'. One of the following must be provided: component, loadComponent, redirectTo, children or loadChildren`);
		if (route.path === void 0 && route.matcher === void 0) throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': routes must have either a path or a matcher specified`);
		if (typeof route.path === "string" && route.path.charAt(0) === "/") throw new RuntimeError(4014, `Invalid configuration of route '${fullPath}': path cannot start with a slash`);
		if (route.path === "" && route.redirectTo !== void 0 && route.pathMatch === void 0) throw new RuntimeError(4014, `Invalid configuration of route '{path: "${fullPath}", redirectTo: "${route.redirectTo}"}': please provide 'pathMatch'. The default value of 'pathMatch' is 'prefix', but often the intent is to use 'full'.`);
		if (requireStandaloneComponents) assertStandalone(fullPath, route.component);
	}
	if (route.children) validateConfig(route.children, fullPath, requireStandaloneComponents);
}
function getFullPath(parentPath, currentRoute) {
	if (!currentRoute) return parentPath;
	if (!parentPath && !currentRoute.path) return "";
	else if (parentPath && !currentRoute.path) return `${parentPath}/`;
	else if (!parentPath && currentRoute.path) return currentRoute.path;
	else return `${parentPath}/${currentRoute.path}`;
}
function getOutlet(route) {
	return route.outlet || "primary";
}
function sortByMatchingOutlets(routes, outletName) {
	const sortedConfig = routes.filter((r) => getOutlet(r) === outletName);
	sortedConfig.push(...routes.filter((r) => getOutlet(r) !== outletName));
	return sortedConfig;
}
var noMatch = {
	matched: false,
	consumedSegments: [],
	remainingSegments: [],
	parameters: {},
	positionalParamSegments: {}
};
function createPreMatchRouteSnapshot(snapshot) {
	return {
		routeConfig: snapshot.routeConfig,
		url: snapshot.url,
		params: snapshot.params,
		queryParams: snapshot.queryParams,
		fragment: snapshot.fragment,
		data: snapshot.data,
		outlet: snapshot.outlet,
		title: snapshot.title,
		paramMap: snapshot.paramMap,
		queryParamMap: snapshot.queryParamMap
	};
}
function matchWithChecks(segmentGroup, route, segments, injector, urlSerializer, createSnapshot, abortSignal) {
	const result = match(segmentGroup, route, segments);
	if (!result.matched) return (0, import_cjs.of)(result);
	const currentSnapshot = createPreMatchRouteSnapshot(createSnapshot(result));
	injector = getOrCreateRouteInjectorIfNeeded(route, injector);
	return runCanMatchGuards(injector, route, segments, urlSerializer, currentSnapshot, abortSignal).pipe((0, import_operators.map)((v) => v === true ? result : { ...noMatch }));
}
function match(segmentGroup, route, segments) {
	if (route.path === "") {
		if (route.pathMatch === "full" && (segmentGroup.hasChildren() || segments.length > 0)) return { ...noMatch };
		return {
			matched: true,
			consumedSegments: [],
			remainingSegments: segments,
			parameters: {},
			positionalParamSegments: {}
		};
	}
	const res = (route.matcher || defaultUrlMatcher)(segments, segmentGroup, route);
	if (!res) return { ...noMatch };
	const posParams = {};
	Object.entries(res.posParams ?? {}).forEach(([k, v]) => {
		posParams[k] = v.path;
	});
	const parameters = res.consumed.length > 0 ? {
		...posParams,
		...res.consumed[res.consumed.length - 1].parameters
	} : posParams;
	return {
		matched: true,
		consumedSegments: res.consumed,
		remainingSegments: segments.slice(res.consumed.length),
		parameters,
		positionalParamSegments: res.posParams ?? {}
	};
}
function split(segmentGroup, consumedSegments, slicedSegments, config, outlet) {
	if (slicedSegments.length > 0 && containsEmptyPathMatchesWithNamedOutlets(segmentGroup, slicedSegments, config, outlet)) return {
		segmentGroup: new UrlSegmentGroup(consumedSegments, createChildrenForEmptyPaths(config, new UrlSegmentGroup(slicedSegments, segmentGroup.children))),
		slicedSegments: []
	};
	if (slicedSegments.length === 0 && containsEmptyPathMatches(segmentGroup, slicedSegments, config)) return {
		segmentGroup: new UrlSegmentGroup(segmentGroup.segments, addEmptyPathsToChildrenIfNeeded(segmentGroup, slicedSegments, config, segmentGroup.children)),
		slicedSegments
	};
	return {
		segmentGroup: new UrlSegmentGroup(segmentGroup.segments, segmentGroup.children),
		slicedSegments
	};
}
function addEmptyPathsToChildrenIfNeeded(segmentGroup, slicedSegments, routes, children) {
	const res = {};
	for (const r of routes) if (emptyPathMatch(segmentGroup, slicedSegments, r) && !children[getOutlet(r)]) {
		const s = new UrlSegmentGroup([], {});
		res[getOutlet(r)] = s;
	}
	return {
		...children,
		...res
	};
}
function createChildrenForEmptyPaths(routes, primarySegment) {
	const res = {};
	res[PRIMARY_OUTLET] = primarySegment;
	for (const r of routes) if (r.path === "" && getOutlet(r) !== "primary") {
		const s = new UrlSegmentGroup([], {});
		res[getOutlet(r)] = s;
	}
	return res;
}
function containsEmptyPathMatchesWithNamedOutlets(segmentGroup, slicedSegments, routes, outlet) {
	return routes.some((r) => {
		if (!emptyPathMatch(segmentGroup, slicedSegments, r)) return false;
		if (!(getOutlet(r) !== "primary")) return false;
		return !(outlet !== void 0 && getOutlet(r) === outlet);
	});
}
function containsEmptyPathMatches(segmentGroup, slicedSegments, routes) {
	return routes.some((r) => emptyPathMatch(segmentGroup, slicedSegments, r));
}
function emptyPathMatch(segmentGroup, slicedSegments, r) {
	if ((segmentGroup.hasChildren() || slicedSegments.length > 0) && r.pathMatch === "full") return false;
	return r.path === "";
}
function noLeftoversInUrl(segmentGroup, segments, outlet) {
	return segments.length === 0 && !segmentGroup.children[outlet];
}
var NoLeftoversInUrl = class {};
async function recognize$1(injector, configLoader, rootComponentType, config, urlTree, urlSerializer, paramsInheritanceStrategy, abortSignal) {
	return new Recognizer(injector, configLoader, rootComponentType, config, urlTree, paramsInheritanceStrategy, urlSerializer, abortSignal).recognize();
}
var MAX_ALLOWED_REDIRECTS = 31;
var Recognizer = class {
	injector;
	configLoader;
	rootComponentType;
	config;
	urlTree;
	paramsInheritanceStrategy;
	urlSerializer;
	abortSignal;
	applyRedirects;
	absoluteRedirectCount = 0;
	allowRedirects = true;
	constructor(injector, configLoader, rootComponentType, config, urlTree, paramsInheritanceStrategy, urlSerializer, abortSignal) {
		this.injector = injector;
		this.configLoader = configLoader;
		this.rootComponentType = rootComponentType;
		this.config = config;
		this.urlTree = urlTree;
		this.paramsInheritanceStrategy = paramsInheritanceStrategy;
		this.urlSerializer = urlSerializer;
		this.abortSignal = abortSignal;
		this.applyRedirects = new ApplyRedirects(this.urlSerializer, this.urlTree);
	}
	noMatchError(e) {
		return new RuntimeError(4002, typeof ngDevMode === "undefined" || ngDevMode ? `Cannot match any routes. URL Segment: '${e.segmentGroup}'` : `'${e.segmentGroup}'`);
	}
	async recognize() {
		const rootSegmentGroup = split(this.urlTree.root, [], [], this.config).segmentGroup;
		const { children, rootSnapshot } = await this.match(rootSegmentGroup);
		const routeState = new RouterStateSnapshot("", new TreeNode(rootSnapshot, children));
		const tree = createUrlTreeFromSnapshot(rootSnapshot, [], this.urlTree.queryParams, this.urlTree.fragment);
		tree.queryParams = this.urlTree.queryParams;
		routeState.url = this.urlSerializer.serialize(tree);
		return {
			state: routeState,
			tree
		};
	}
	async match(rootSegmentGroup) {
		const rootSnapshot = new ActivatedRouteSnapshot([], Object.freeze({}), Object.freeze({ ...this.urlTree.queryParams }), this.urlTree.fragment, Object.freeze({}), PRIMARY_OUTLET, this.rootComponentType, null, {}, this.injector);
		try {
			return {
				children: await this.processSegmentGroup(this.injector, this.config, rootSegmentGroup, PRIMARY_OUTLET, rootSnapshot),
				rootSnapshot
			};
		} catch (e) {
			if (e instanceof AbsoluteRedirect) {
				this.urlTree = e.urlTree;
				return this.match(e.urlTree.root);
			}
			if (e instanceof NoMatch) throw this.noMatchError(e);
			throw e;
		}
	}
	async processSegmentGroup(injector, config, segmentGroup, outlet, parentRoute) {
		if (segmentGroup.segments.length === 0 && segmentGroup.hasChildren()) return this.processChildren(injector, config, segmentGroup, parentRoute);
		const child = await this.processSegment(injector, config, segmentGroup, segmentGroup.segments, outlet, true, parentRoute);
		return child instanceof TreeNode ? [child] : [];
	}
	async processChildren(injector, config, segmentGroup, parentRoute) {
		const childOutlets = [];
		for (const child of Object.keys(segmentGroup.children)) if (child === "primary") childOutlets.unshift(child);
		else childOutlets.push(child);
		let children = [];
		for (const childOutlet of childOutlets) {
			const child = segmentGroup.children[childOutlet];
			const sortedConfig = sortByMatchingOutlets(config, childOutlet);
			const outletChildren = await this.processSegmentGroup(injector, sortedConfig, child, childOutlet, parentRoute);
			children.push(...outletChildren);
		}
		const mergedChildren = mergeEmptyPathMatches(children);
		if (typeof ngDevMode === "undefined" || ngDevMode) checkOutletNameUniqueness(mergedChildren);
		sortActivatedRouteSnapshots(mergedChildren);
		return mergedChildren;
	}
	async processSegment(injector, routes, segmentGroup, segments, outlet, allowRedirects, parentRoute) {
		for (const r of routes) try {
			return await this.processSegmentAgainstRoute(r._injector ?? injector, routes, r, segmentGroup, segments, outlet, allowRedirects, parentRoute);
		} catch (e) {
			if (e instanceof NoMatch || isEmptyError(e)) continue;
			throw e;
		}
		if (noLeftoversInUrl(segmentGroup, segments, outlet)) return new NoLeftoversInUrl();
		throw new NoMatch(segmentGroup);
	}
	async processSegmentAgainstRoute(injector, routes, route, rawSegment, segments, outlet, allowRedirects, parentRoute) {
		if (getOutlet(route) !== outlet && (outlet === "primary" || !emptyPathMatch(rawSegment, segments, route))) throw new NoMatch(rawSegment);
		if (route.redirectTo === void 0) return this.matchSegmentAgainstRoute(injector, rawSegment, route, segments, outlet, parentRoute);
		if (this.allowRedirects && allowRedirects) return this.expandSegmentAgainstRouteUsingRedirect(injector, rawSegment, routes, route, segments, outlet, parentRoute);
		throw new NoMatch(rawSegment);
	}
	async expandSegmentAgainstRouteUsingRedirect(injector, segmentGroup, routes, route, segments, outlet, parentRoute) {
		const { matched, parameters, consumedSegments, positionalParamSegments, remainingSegments } = match(segmentGroup, route, segments);
		if (!matched) throw new NoMatch(segmentGroup);
		if (typeof route.redirectTo === "string" && route.redirectTo[0] === "/") {
			this.absoluteRedirectCount++;
			if (this.absoluteRedirectCount > MAX_ALLOWED_REDIRECTS) {
				if (ngDevMode) throw new RuntimeError(4016, `Detected possible infinite redirect when redirecting from '${this.urlTree}' to '${route.redirectTo}'.\nThis is currently a dev mode only error but will become a call stack size exceeded error in production in a future major version.`);
				this.allowRedirects = false;
			}
		}
		const currentSnapshot = this.createSnapshot(injector, route, segments, parameters, parentRoute);
		if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
		const newTree = await this.applyRedirects.applyRedirectCommands(consumedSegments, route.redirectTo, positionalParamSegments, createPreMatchRouteSnapshot(currentSnapshot), injector);
		const newSegments = await this.applyRedirects.lineralizeSegments(route, newTree);
		return this.processSegment(injector, routes, segmentGroup, newSegments.concat(remainingSegments), outlet, false, parentRoute);
	}
	createSnapshot(injector, route, segments, parameters, parentRoute) {
		const snapshot = new ActivatedRouteSnapshot(segments, parameters, Object.freeze({ ...this.urlTree.queryParams }), this.urlTree.fragment, getData(route), getOutlet(route), route.component ?? route._loadedComponent ?? null, route, getResolve(route), injector);
		const inherited = getInherited(snapshot, parentRoute, this.paramsInheritanceStrategy);
		snapshot.params = Object.freeze(inherited.params);
		snapshot.data = Object.freeze(inherited.data);
		return snapshot;
	}
	async matchSegmentAgainstRoute(injector, rawSegment, route, segments, outlet, parentRoute) {
		if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
		const createSnapshot = (result) => this.createSnapshot(injector, route, result.consumedSegments, result.parameters, parentRoute);
		const result = await firstValueFrom(matchWithChecks(rawSegment, route, segments, injector, this.urlSerializer, createSnapshot, this.abortSignal));
		if (route.path === "**") rawSegment.children = {};
		if (!result?.matched) throw new NoMatch(rawSegment);
		injector = route._injector ?? injector;
		const { routes: childConfig } = await this.getChildConfig(injector, route, segments);
		const childInjector = route._loadedInjector ?? injector;
		const { parameters, consumedSegments, remainingSegments } = result;
		const snapshot = this.createSnapshot(injector, route, consumedSegments, parameters, parentRoute);
		const { segmentGroup, slicedSegments } = split(rawSegment, consumedSegments, remainingSegments, childConfig, outlet);
		if (slicedSegments.length === 0 && segmentGroup.hasChildren()) return new TreeNode(snapshot, await this.processChildren(childInjector, childConfig, segmentGroup, snapshot));
		if (childConfig.length === 0 && slicedSegments.length === 0) return new TreeNode(snapshot, []);
		const matchedOnOutlet = getOutlet(route) === outlet;
		const child = await this.processSegment(childInjector, childConfig, segmentGroup, slicedSegments, matchedOnOutlet ? PRIMARY_OUTLET : outlet, true, snapshot);
		return new TreeNode(snapshot, child instanceof TreeNode ? [child] : []);
	}
	async getChildConfig(injector, route, segments) {
		if (route.children) return {
			routes: route.children,
			injector
		};
		if (route.loadChildren) {
			if (route._loadedRoutes !== void 0) {
				const ngModuleFactory = route._loadedNgModuleFactory;
				if (ngModuleFactory && !route._loadedInjector) route._loadedInjector = ngModuleFactory.create(injector).injector;
				return {
					routes: route._loadedRoutes,
					injector: route._loadedInjector
				};
			}
			if (this.abortSignal.aborted) throw new Error(this.abortSignal.reason);
			if (await firstValueFrom(runCanLoadGuards(injector, route, segments, this.urlSerializer, this.abortSignal))) {
				const cfg = await this.configLoader.loadChildren(injector, route);
				route._loadedRoutes = cfg.routes;
				route._loadedInjector = cfg.injector;
				route._loadedNgModuleFactory = cfg.factory;
				return cfg;
			}
			throw canLoadFails(route);
		}
		return {
			routes: [],
			injector
		};
	}
};
function sortActivatedRouteSnapshots(nodes) {
	nodes.sort((a, b) => {
		if (a.value.outlet === "primary") return -1;
		if (b.value.outlet === "primary") return 1;
		return a.value.outlet.localeCompare(b.value.outlet);
	});
}
function hasEmptyPathConfig(node) {
	const config = node.value.routeConfig;
	return config && config.path === "";
}
function mergeEmptyPathMatches(nodes) {
	const result = [];
	const mergedNodes = /* @__PURE__ */ new Set();
	for (const node of nodes) {
		if (!hasEmptyPathConfig(node)) {
			result.push(node);
			continue;
		}
		const duplicateEmptyPathNode = result.find((resultNode) => node.value.routeConfig === resultNode.value.routeConfig);
		if (duplicateEmptyPathNode !== void 0) {
			duplicateEmptyPathNode.children.push(...node.children);
			mergedNodes.add(duplicateEmptyPathNode);
		} else result.push(node);
	}
	for (const mergedNode of mergedNodes) {
		const mergedChildren = mergeEmptyPathMatches(mergedNode.children);
		result.push(new TreeNode(mergedNode.value, mergedChildren));
	}
	return result.filter((n) => !mergedNodes.has(n));
}
function checkOutletNameUniqueness(nodes) {
	const names = {};
	nodes.forEach((n) => {
		const routeWithSameOutletName = names[n.value.outlet];
		if (routeWithSameOutletName) {
			const p = routeWithSameOutletName.url.map((s) => s.toString()).join("/");
			const c = n.value.url.map((s) => s.toString()).join("/");
			throw new RuntimeError(4006, (typeof ngDevMode === "undefined" || ngDevMode) && `Two segments cannot have the same outlet name: '${p}' and '${c}'.`);
		}
		names[n.value.outlet] = n.value;
	});
}
function getData(route) {
	return route.data || {};
}
function getResolve(route) {
	return route.resolve || {};
}
function recognize(injector, configLoader, rootComponentType, config, serializer, paramsInheritanceStrategy, abortSignal) {
	return (0, import_operators.mergeMap)(async (t) => {
		const { state: targetSnapshot, tree: urlAfterRedirects } = await recognize$1(injector, configLoader, rootComponentType, config, t.extractedUrl, serializer, paramsInheritanceStrategy, abortSignal);
		return {
			...t,
			targetSnapshot,
			urlAfterRedirects
		};
	});
}
function resolveData(paramsInheritanceStrategy) {
	return (0, import_operators.mergeMap)((t) => {
		const { targetSnapshot, guards: { canActivateChecks } } = t;
		if (!canActivateChecks.length) return (0, import_cjs.of)(t);
		const routesWithResolversToRun = new Set(canActivateChecks.map((check) => check.route));
		const routesNeedingDataUpdates = /* @__PURE__ */ new Set();
		for (const route of routesWithResolversToRun) {
			if (routesNeedingDataUpdates.has(route)) continue;
			for (const newRoute of flattenRouteTree(route)) routesNeedingDataUpdates.add(newRoute);
		}
		let routesProcessed = 0;
		return (0, import_cjs.from)(routesNeedingDataUpdates).pipe((0, import_operators.concatMap)((route) => {
			if (routesWithResolversToRun.has(route)) return runResolve(route, targetSnapshot, paramsInheritanceStrategy);
			else {
				route.data = getInherited(route, route.parent, paramsInheritanceStrategy).resolve;
				return (0, import_cjs.of)(void 0);
			}
		}), (0, import_operators.tap)(() => routesProcessed++), (0, import_operators.takeLast)(1), (0, import_operators.mergeMap)((_) => routesProcessed === routesNeedingDataUpdates.size ? (0, import_cjs.of)(t) : import_cjs.EMPTY));
	});
}
function flattenRouteTree(route) {
	return [route, ...route.children.map((child) => flattenRouteTree(child)).flat()];
}
function runResolve(futureARS, futureRSS, paramsInheritanceStrategy) {
	const config = futureARS.routeConfig;
	const resolve = futureARS._resolve;
	if (config?.title !== void 0 && !hasStaticTitle(config)) resolve[RouteTitleKey] = config.title;
	return (0, import_cjs.defer)(() => {
		futureARS.data = getInherited(futureARS, futureARS.parent, paramsInheritanceStrategy).resolve;
		return resolveNode(resolve, futureARS, futureRSS).pipe((0, import_operators.map)((resolvedData) => {
			futureARS._resolvedData = resolvedData;
			futureARS.data = {
				...futureARS.data,
				...resolvedData
			};
			return null;
		}));
	});
}
function resolveNode(resolve, futureARS, futureRSS) {
	const keys = getDataKeys(resolve);
	if (keys.length === 0) return (0, import_cjs.of)({});
	const data = {};
	return (0, import_cjs.from)(keys).pipe((0, import_operators.mergeMap)((key) => getResolver(resolve[key], futureARS, futureRSS).pipe((0, import_operators.first)(), (0, import_operators.tap)((value) => {
		if (value instanceof RedirectCommand) throw redirectingNavigationError(new DefaultUrlSerializer(), value);
		data[key] = value;
	}))), (0, import_operators.takeLast)(1), (0, import_operators.map)(() => data), (0, import_operators.catchError)((e) => isEmptyError(e) ? import_cjs.EMPTY : (0, import_cjs.throwError)(e)));
}
function getResolver(injectionToken, futureARS, futureRSS) {
	const closestInjector = futureARS._environmentInjector;
	const resolver = getTokenOrFunctionIdentity(injectionToken, closestInjector);
	return wrapIntoObservable(resolver.resolve ? resolver.resolve(futureARS, futureRSS) : runInInjectionContext(closestInjector, () => resolver(futureARS, futureRSS)));
}
function switchTap(next) {
	return (0, import_operators.switchMap)((v) => {
		const nextResult = next(v);
		if (nextResult) return (0, import_cjs.from)(nextResult).pipe((0, import_operators.map)(() => v));
		return (0, import_cjs.of)(v);
	});
}
var TitleStrategy = class TitleStrategy {
	buildTitle(snapshot) {
		let pageTitle;
		let route = snapshot.root;
		while (route !== void 0) {
			pageTitle = this.getResolvedTitleForRoute(route) ?? pageTitle;
			route = route.children.find((child) => child.outlet === PRIMARY_OUTLET);
		}
		return pageTitle;
	}
	getResolvedTitleForRoute(snapshot) {
		return snapshot.data[RouteTitleKey];
	}
	static ɵfac = function TitleStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || TitleStrategy)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: TitleStrategy,
		factory: () => (() => inject(DefaultTitleStrategy))()
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TitleStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultTitleStrategy) }]
	}], null, null);
})();
var DefaultTitleStrategy = class DefaultTitleStrategy extends TitleStrategy {
	title;
	constructor(title) {
		super();
		this.title = title;
	}
	updateTitle(snapshot) {
		const title = this.buildTitle(snapshot);
		if (title !== void 0) this.title.setTitle(title);
	}
	static ɵfac = function DefaultTitleStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || DefaultTitleStrategy)(ɵɵinject(Title));
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: DefaultTitleStrategy,
		factory: DefaultTitleStrategy.ɵfac,
		providedIn: "root"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultTitleStrategy, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [{ type: Title }], null);
})();
var ROUTER_CONFIGURATION = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router config" : "", { factory: () => ({}) });
var ROUTES = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "ROUTES" : "");
var RouterConfigLoader = class RouterConfigLoader {
	componentLoaders = /* @__PURE__ */ new WeakMap();
	childrenLoaders = /* @__PURE__ */ new WeakMap();
	onLoadStartListener;
	onLoadEndListener;
	compiler = inject(Compiler);
	async loadComponent(injector, route) {
		if (this.componentLoaders.get(route)) return this.componentLoaders.get(route);
		else if (route._loadedComponent) return Promise.resolve(route._loadedComponent);
		if (this.onLoadStartListener) this.onLoadStartListener(route);
		const loader = (async () => {
			try {
				const component = await maybeResolveResources(maybeUnwrapDefaultExport(await wrapIntoPromise(runInInjectionContext(injector, () => route.loadComponent()))));
				if (this.onLoadEndListener) this.onLoadEndListener(route);
				(typeof ngDevMode === "undefined" || ngDevMode) && assertStandalone(route.path ?? "", component);
				route._loadedComponent = component;
				return component;
			} finally {
				this.componentLoaders.delete(route);
			}
		})();
		this.componentLoaders.set(route, loader);
		return loader;
	}
	loadChildren(parentInjector, route) {
		if (this.childrenLoaders.get(route)) return this.childrenLoaders.get(route);
		else if (route._loadedRoutes) return Promise.resolve({
			routes: route._loadedRoutes,
			injector: route._loadedInjector
		});
		if (this.onLoadStartListener) this.onLoadStartListener(route);
		const loader = (async () => {
			try {
				const result = await loadChildren(route, this.compiler, parentInjector, this.onLoadEndListener);
				route._loadedRoutes = result.routes;
				route._loadedInjector = result.injector;
				route._loadedNgModuleFactory = result.factory;
				return result;
			} finally {
				this.childrenLoaders.delete(route);
			}
		})();
		this.childrenLoaders.set(route, loader);
		return loader;
	}
	static ɵfac = function RouterConfigLoader_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterConfigLoader)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: RouterConfigLoader,
		factory: RouterConfigLoader.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterConfigLoader, [{ type: Service }], null, null);
})();
async function loadChildren(route, compiler, parentInjector, onLoadEndListener) {
	const t = await maybeResolveResources(maybeUnwrapDefaultExport(await wrapIntoPromise(runInInjectionContext(parentInjector, () => route.loadChildren()))));
	let factoryOrRoutes;
	if (t instanceof NgModuleFactory$1 || Array.isArray(t)) factoryOrRoutes = t;
	else factoryOrRoutes = await compiler.compileModuleAsync(t);
	if (onLoadEndListener) onLoadEndListener(route);
	let injector;
	let rawRoutes;
	let requireStandaloneComponents = false;
	let factory = void 0;
	if (Array.isArray(factoryOrRoutes)) {
		rawRoutes = factoryOrRoutes;
		requireStandaloneComponents = true;
	} else {
		injector = factoryOrRoutes.create(parentInjector).injector;
		factory = factoryOrRoutes;
		rawRoutes = injector.get(ROUTES, [], {
			optional: true,
			self: true
		}).flat();
	}
	const routes = rawRoutes.map(standardizeConfig);
	(typeof ngDevMode === "undefined" || ngDevMode) && validateConfig(routes, route.path, requireStandaloneComponents);
	return {
		routes,
		injector,
		factory
	};
}
async function maybeResolveResources(value) {
	return value;
}
var UrlHandlingStrategy = class UrlHandlingStrategy {
	static ɵfac = function UrlHandlingStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || UrlHandlingStrategy)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: UrlHandlingStrategy,
		factory: () => (() => inject(DefaultUrlHandlingStrategy))()
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UrlHandlingStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultUrlHandlingStrategy) }]
	}], null, null);
})();
var DefaultUrlHandlingStrategy = class DefaultUrlHandlingStrategy {
	shouldProcessUrl(url) {
		return true;
	}
	extract(url) {
		return url;
	}
	merge(newUrlPart, wholeUrl) {
		return newUrlPart;
	}
	static ɵfac = function DefaultUrlHandlingStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || DefaultUrlHandlingStrategy)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: DefaultUrlHandlingStrategy,
		factory: DefaultUrlHandlingStrategy.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultUrlHandlingStrategy, [{ type: Service }], null, null);
})();
var CREATE_VIEW_TRANSITION = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "view transition helper" : "");
var VIEW_TRANSITION_OPTIONS = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "view transition options" : "");
function createViewTransition(injector, from, to) {
	const transitionOptions = injector.get(VIEW_TRANSITION_OPTIONS);
	const document = injector.get(DOCUMENT);
	if (!document.startViewTransition || transitionOptions.skipNextTransition) {
		transitionOptions.skipNextTransition = false;
		return new Promise((resolve) => setTimeout(resolve));
	}
	let resolveViewTransitionStarted;
	const viewTransitionStarted = new Promise((resolve) => {
		resolveViewTransitionStarted = resolve;
	});
	const transition = document.startViewTransition(() => {
		resolveViewTransitionStarted();
		return createRenderPromise(injector);
	});
	transition.updateCallbackDone.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	transition.ready.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	transition.finished.catch((error) => {
		if (typeof ngDevMode === "undefined" || ngDevMode) console.error(error);
	});
	const { onViewTransitionCreated } = transitionOptions;
	if (onViewTransitionCreated) runInInjectionContext(injector, () => onViewTransitionCreated({
		transition,
		from,
		to
	}));
	return viewTransitionStarted;
}
function createRenderPromise(injector) {
	return new Promise((resolve) => {
		afterNextRender({ read: () => setTimeout(resolve) }, { injector });
	});
}
var ACTIVATED_ROUTE_INJECTOR_FEATURE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "ActivatedRoute injector feature" : "");
var noop = () => {};
var NAVIGATION_ERROR_HANDLER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "navigation error handler" : "");
var NavigationTransitions = class NavigationTransitions {
	currentNavigation = signal(null, {
		...ngDevMode ? { debugName: "currentNavigation" } : {},
		equal: () => false
	});
	currentTransition = null;
	lastSuccessfulNavigation = signal(null, ...ngDevMode ? [{ debugName: "lastSuccessfulNavigation" }] : []);
	events = new import_cjs.Subject();
	transitionAbortWithErrorSubject = new import_cjs.Subject();
	configLoader = inject(RouterConfigLoader);
	environmentInjector = inject(EnvironmentInjector);
	destroyRef = inject(DestroyRef);
	urlSerializer = inject(UrlSerializer);
	rootContexts = inject(ChildrenOutletContexts);
	location = inject(Location);
	inputBindingEnabled = inject(INPUT_BINDER, { optional: true }) !== null;
	titleStrategy = inject(TitleStrategy);
	options = inject(ROUTER_CONFIGURATION, { optional: true }) || {};
	paramsInheritanceStrategy = this.options.paramsInheritanceStrategy || DEFAULT_PARAMS_INHERITANCE_STRATEGY;
	urlHandlingStrategy = inject(UrlHandlingStrategy);
	createViewTransition = inject(CREATE_VIEW_TRANSITION, { optional: true });
	navigationErrorHandler = inject(NAVIGATION_ERROR_HANDLER, { optional: true });
	activatedRouteInjectorFeature = inject(ACTIVATED_ROUTE_INJECTOR_FEATURE, { optional: true });
	navigationId = 0;
	get hasRequestedNavigation() {
		return this.navigationId !== 0;
	}
	transitions;
	afterPreactivation = () => (0, import_cjs.of)(void 0);
	rootComponentType = null;
	destroyed = false;
	constructor() {
		const onLoadStart = (r) => this.events.next(new RouteConfigLoadStart(r));
		const onLoadEnd = (r) => this.events.next(new RouteConfigLoadEnd(r));
		this.configLoader.onLoadEndListener = onLoadEnd;
		this.configLoader.onLoadStartListener = onLoadStart;
		this.destroyRef.onDestroy(() => {
			this.destroyed = true;
		});
	}
	complete() {
		this.transitions?.complete();
	}
	handleNavigationRequest(request) {
		const id = ++this.navigationId;
		untracked(() => {
			this.transitions?.next({
				...request,
				extractedUrl: this.urlHandlingStrategy.extract(request.rawUrl),
				targetSnapshot: null,
				targetRouterState: null,
				guards: {
					canActivateChecks: [],
					canDeactivateChecks: []
				},
				guardsResult: null,
				id,
				routesRecognizeHandler: {},
				beforeActivateHandler: {}
			});
		});
	}
	setupNavigations(router) {
		this.transitions = new import_cjs.BehaviorSubject(null);
		return this.transitions.pipe((0, import_operators.filter)((t) => t !== null), (0, import_operators.switchMap)((overallTransitionState) => {
			let abortable = true;
			let completedOrAborted = false;
			const abortController = new AbortController();
			const shouldContinueNavigation = () => {
				return !completedOrAborted && this.currentTransition?.id === overallTransitionState.id;
			};
			return (0, import_cjs.of)(overallTransitionState).pipe((0, import_operators.switchMap)((t) => {
				if (this.navigationId > overallTransitionState.id) {
					const cancellationReason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation ID ${overallTransitionState.id} is not equal to the current navigation id ${this.navigationId}` : "";
					this.cancelNavigationTransition(overallTransitionState, cancellationReason, NavigationCancellationCode.SupersededByNewNavigation);
					return import_cjs.EMPTY;
				}
				this.currentTransition = overallTransitionState;
				const lastSuccessfulNavigation = this.lastSuccessfulNavigation();
				this.currentNavigation.set({
					id: t.id,
					initialUrl: t.rawUrl,
					extractedUrl: t.extractedUrl,
					targetBrowserUrl: typeof t.extras.browserUrl === "string" ? this.urlSerializer.parse(t.extras.browserUrl) : t.extras.browserUrl,
					trigger: t.source,
					extras: t.extras,
					previousNavigation: !lastSuccessfulNavigation ? null : {
						...lastSuccessfulNavigation,
						previousNavigation: null
					},
					abort: () => abortController.abort(),
					routesRecognizeHandler: t.routesRecognizeHandler,
					beforeActivateHandler: t.beforeActivateHandler
				});
				const urlTransition = !router.navigated || this.isUpdatingInternalState() || this.isUpdatedBrowserUrl();
				const onSameUrlNavigation = t.extras.onSameUrlNavigation ?? router.onSameUrlNavigation;
				if (!urlTransition && onSameUrlNavigation !== "reload") {
					const reason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation to ${t.rawUrl} was ignored because it is the same as the current Router URL.` : "";
					this.events.next(new NavigationSkipped(t.id, this.urlSerializer.serialize(t.rawUrl), reason, NavigationSkippedCode.IgnoredSameUrlNavigation));
					t.resolve(false);
					return import_cjs.EMPTY;
				}
				if (this.urlHandlingStrategy.shouldProcessUrl(t.rawUrl)) return (0, import_cjs.of)(t).pipe((0, import_operators.switchMap)((t) => {
					this.events.next(new NavigationStart(t.id, this.urlSerializer.serialize(t.extractedUrl), t.source, t.restoredState));
					if (t.id !== this.navigationId) return import_cjs.EMPTY;
					return Promise.resolve(t);
				}), recognize(this.environmentInjector, this.configLoader, this.rootComponentType, router.config, this.urlSerializer, this.paramsInheritanceStrategy, abortController.signal), (0, import_operators.tap)((t) => {
					overallTransitionState.targetSnapshot = t.targetSnapshot;
					overallTransitionState.urlAfterRedirects = t.urlAfterRedirects;
					this.currentNavigation.update((nav) => {
						nav.finalUrl = t.urlAfterRedirects;
						return nav;
					});
					this.events.next(new BeforeRoutesRecognized());
				}), (0, import_operators.switchMap)((value) => (0, import_cjs.from)(overallTransitionState.routesRecognizeHandler.deferredHandle ?? (0, import_cjs.of)(void 0)).pipe((0, import_operators.map)(() => value))), (0, import_operators.tap)(() => {
					const routesRecognized = new RoutesRecognized(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
					this.events.next(routesRecognized);
				}));
				else if (urlTransition && this.urlHandlingStrategy.shouldProcessUrl(t.currentRawUrl)) {
					const { id, extractedUrl, source, restoredState, extras } = t;
					const navStart = new NavigationStart(id, this.urlSerializer.serialize(extractedUrl), source, restoredState);
					this.events.next(navStart);
					const targetSnapshot = createEmptyState(this.rootComponentType, this.environmentInjector).snapshot;
					this.currentTransition = overallTransitionState = {
						...t,
						targetSnapshot,
						urlAfterRedirects: extractedUrl,
						extras: {
							...extras,
							skipLocationChange: false,
							replaceUrl: false
						}
					};
					this.currentNavigation.update((nav) => {
						nav.finalUrl = extractedUrl;
						return nav;
					});
					return (0, import_cjs.of)(overallTransitionState);
				} else {
					const reason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation was ignored because the UrlHandlingStrategy indicated neither the current URL ${t.currentRawUrl} nor target URL ${t.rawUrl} should be processed.` : "";
					this.events.next(new NavigationSkipped(t.id, this.urlSerializer.serialize(t.extractedUrl), reason, NavigationSkippedCode.IgnoredByUrlHandlingStrategy));
					t.resolve(false);
					return import_cjs.EMPTY;
				}
			}), (0, import_operators.map)((t) => {
				const guardsStart = new GuardsCheckStart(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
				this.events.next(guardsStart);
				this.currentTransition = overallTransitionState = {
					...t,
					guards: getAllRouteGuards(t.targetSnapshot, t.currentSnapshot, this.rootContexts)
				};
				return overallTransitionState;
			}), checkGuards((evt) => this.events.next(evt)), (0, import_operators.switchMap)((t) => {
				overallTransitionState.guardsResult = t.guardsResult;
				if (t.guardsResult && typeof t.guardsResult !== "boolean") throw redirectingNavigationError(this.urlSerializer, t.guardsResult);
				const guardsEnd = new GuardsCheckEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot, !!t.guardsResult);
				this.events.next(guardsEnd);
				if (!shouldContinueNavigation()) return import_cjs.EMPTY;
				if (!t.guardsResult) {
					this.cancelNavigationTransition(t, "", NavigationCancellationCode.GuardRejected);
					return import_cjs.EMPTY;
				}
				if (t.guards.canActivateChecks.length === 0) return (0, import_cjs.of)(t);
				const resolveStart = new ResolveStart(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
				this.events.next(resolveStart);
				if (!shouldContinueNavigation()) return import_cjs.EMPTY;
				let dataResolved = false;
				return (0, import_cjs.of)(t).pipe(resolveData(this.paramsInheritanceStrategy), (0, import_operators.tap)({
					next: () => {
						dataResolved = true;
						const resolveEnd = new ResolveEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects), t.targetSnapshot);
						this.events.next(resolveEnd);
					},
					complete: () => {
						if (!dataResolved) this.cancelNavigationTransition(t, typeof ngDevMode === "undefined" || ngDevMode ? `At least one route resolver didn't emit any value.` : "", NavigationCancellationCode.NoDataFromResolver);
					}
				}));
			}), switchTap((t) => {
				const loadComponents = (route) => {
					const loaders = [];
					if (route.routeConfig?._loadedComponent) route.component = route.routeConfig?._loadedComponent;
					else if (route.routeConfig?.loadComponent) {
						const injector = route._environmentInjector;
						loaders.push(this.configLoader.loadComponent(injector, route.routeConfig).then((loadedComponent) => {
							route.component = loadedComponent;
						}));
					}
					for (const child of route.children) loaders.push(...loadComponents(child));
					return loaders;
				};
				const loaders = loadComponents(t.targetSnapshot.root);
				return loaders.length === 0 ? (0, import_cjs.of)(t) : (0, import_cjs.from)(Promise.all(loaders).then(() => t));
			}), (0, import_operators.switchMap)((t) => {
				const { newlyCreatedRoutes, state } = createRouterState(router.routeReuseStrategy, t.targetSnapshot, t.currentRouterState);
				this.currentTransition = overallTransitionState = t = {
					...t,
					targetRouterState: state,
					newlyCreatedRoutes
				};
				this.currentNavigation.update((nav) => {
					nav.targetRouterState = state;
					return nav;
				});
				return (0, import_cjs.of)(t);
			}), this.activatedRouteInjectorFeature?.operator() ?? ((t) => t), switchTap(() => this.afterPreactivation()), (0, import_operators.switchMap)(() => {
				const { currentSnapshot, targetSnapshot } = overallTransitionState;
				const viewTransitionStarted = this.createViewTransition?.(this.environmentInjector, currentSnapshot.root, targetSnapshot.root);
				return viewTransitionStarted ? (0, import_cjs.from)(viewTransitionStarted).pipe((0, import_operators.map)(() => overallTransitionState)) : (0, import_cjs.of)(overallTransitionState);
			}), (0, import_operators.take)(1), (0, import_operators.switchMap)((t) => {
				abortable = false;
				this.events.next(new BeforeActivateRoutes());
				const deferred = overallTransitionState.beforeActivateHandler.deferredHandle;
				return deferred ? (0, import_cjs.from)(deferred.then(() => t)) : (0, import_cjs.of)(t);
			}), (0, import_operators.tap)((t) => {
				new ActivateRoutes(router.routeReuseStrategy, overallTransitionState.targetRouterState, overallTransitionState.currentRouterState, (evt) => this.events.next(evt), this.inputBindingEnabled).activate(this.rootContexts);
				t.newlyCreatedRoutes?.clear();
				if (!shouldContinueNavigation()) return;
				completedOrAborted = true;
				this.currentNavigation.update((nav) => {
					nav.abort = noop;
					return nav;
				});
				this.lastSuccessfulNavigation.set(untracked(this.currentNavigation));
				this.events.next(new NavigationEnd(t.id, this.urlSerializer.serialize(t.extractedUrl), this.urlSerializer.serialize(t.urlAfterRedirects)));
				this.titleStrategy?.updateTitle(t.targetRouterState.snapshot);
				t.resolve(true);
			}), (0, import_operators.takeUntil)(abortSignalToObservable(abortController.signal).pipe((0, import_operators.filter)(() => !completedOrAborted && abortable), (0, import_operators.tap)(() => {
				this.cancelNavigationTransition(overallTransitionState, abortController.signal.reason + "", NavigationCancellationCode.Aborted);
			}))), (0, import_operators.tap)({ complete: () => {
				completedOrAborted = true;
			} }), (0, import_operators.takeUntil)(this.transitionAbortWithErrorSubject.pipe((0, import_operators.tap)((err) => {
				throw err;
			}))), (0, import_operators.finalize)(() => {
				abortController.abort();
				if (!completedOrAborted) {
					const cancelationReason = typeof ngDevMode === "undefined" || ngDevMode ? `Navigation ID ${overallTransitionState.id} is not equal to the current navigation id ${this.navigationId}` : "";
					this.cancelNavigationTransition(overallTransitionState, cancelationReason, NavigationCancellationCode.SupersededByNewNavigation);
				}
				if (this.currentTransition?.id === overallTransitionState.id) {
					this.currentNavigation.set(null);
					this.currentTransition = null;
				}
			}), (0, import_operators.catchError)((e) => {
				completedOrAborted = true;
				discardNewActivatedRoutes(overallTransitionState);
				if (this.destroyed) {
					overallTransitionState.resolve(false);
					return import_cjs.EMPTY;
				}
				if (isNavigationCancelingError(e)) {
					this.events.next(new NavigationCancel(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), e.message, e.cancellationCode));
					if (!isRedirectingNavigationCancelingError(e)) overallTransitionState.resolve(false);
					else this.events.next(new RedirectRequest(e.url, e.navigationBehaviorOptions));
				} else {
					const navigationError = new NavigationError(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), e, overallTransitionState.targetSnapshot ?? void 0);
					try {
						const navigationErrorHandlerResult = runInInjectionContext(this.environmentInjector, () => this.navigationErrorHandler?.(navigationError));
						if (navigationErrorHandlerResult instanceof RedirectCommand) {
							const { message, cancellationCode } = redirectingNavigationError(this.urlSerializer, navigationErrorHandlerResult);
							this.events.next(new NavigationCancel(overallTransitionState.id, this.urlSerializer.serialize(overallTransitionState.extractedUrl), message, cancellationCode));
							this.events.next(new RedirectRequest(navigationErrorHandlerResult.redirectTo, navigationErrorHandlerResult.navigationBehaviorOptions));
						} else {
							this.events.next(navigationError);
							throw e;
						}
					} catch (ee) {
						if (this.options.resolveNavigationPromiseOnError) overallTransitionState.resolve(false);
						else overallTransitionState.reject(ee);
					}
				}
				return import_cjs.EMPTY;
			}));
		}));
	}
	cancelNavigationTransition(t, reason, code) {
		discardNewActivatedRoutes(t);
		const navCancel = new NavigationCancel(t.id, this.urlSerializer.serialize(t.extractedUrl), reason, code);
		this.events.next(navCancel);
		t.resolve(false);
	}
	isUpdatingInternalState() {
		return this.currentTransition?.extractedUrl.toString() !== this.currentTransition?.currentUrlTree.toString();
	}
	isUpdatedBrowserUrl() {
		const currentBrowserUrl = this.urlHandlingStrategy.extract(this.urlSerializer.parse(this.location.path(true)));
		const currentNavigation = untracked(this.currentNavigation);
		const targetBrowserUrl = currentNavigation?.targetBrowserUrl ?? currentNavigation?.extractedUrl;
		return currentBrowserUrl.toString() !== targetBrowserUrl?.toString() && !currentNavigation?.extras.skipLocationChange;
	}
	static ɵfac = function NavigationTransitions_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || NavigationTransitions)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: NavigationTransitions,
		factory: NavigationTransitions.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NavigationTransitions, [{ type: Service }], () => [], null);
})();
function isBrowserTriggeredNavigation(source) {
	return source !== IMPERATIVE_NAVIGATION;
}
function discardNewActivatedRoutes(t) {
	if (!t.newlyCreatedRoutes) return;
	for (const r of t.newlyCreatedRoutes) r._localInjector?.destroy();
}
var ROUTE_INJECTOR_CLEANUP = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "RouteInjectorCleanup" : "");
function routeInjectorCleanup(routeReuseStrategy, routerState, config) {
	const activeRoutes = /* @__PURE__ */ new Set();
	if (routerState.snapshot.root) collectDescendants(routerState.snapshot.root, activeRoutes);
	const storedHandles = routeReuseStrategy.retrieveStoredRouteHandles?.() || [];
	for (const handle of storedHandles) {
		const internalHandle = handle;
		if (internalHandle?.route?.value?.snapshot) {
			for (const snapshot of internalHandle.route.value.snapshot.pathFromRoot) if (snapshot.routeConfig) activeRoutes.add(snapshot.routeConfig);
		}
	}
	destroyUnusedInjectors(config, activeRoutes, routeReuseStrategy, false);
}
function collectDescendants(snapshot, activeRoutes) {
	if (snapshot.routeConfig) activeRoutes.add(snapshot.routeConfig);
	for (const child of snapshot.children) collectDescendants(child, activeRoutes);
}
function destroyUnusedInjectors(routes, activeRoutes, strategy, inheritedForceDestroy) {
	for (const route of routes) {
		const shouldDestroyCurrentRoute = inheritedForceDestroy || !!((route._injector || route._loadedInjector) && !activeRoutes.has(route) && (strategy.shouldDestroyInjector?.(route) ?? false));
		if (route.children) destroyUnusedInjectors(route.children, activeRoutes, strategy, shouldDestroyCurrentRoute);
		if (route.loadChildren && route._loadedRoutes) destroyUnusedInjectors(route._loadedRoutes, activeRoutes, strategy, shouldDestroyCurrentRoute);
		if (shouldDestroyCurrentRoute) {
			if (route._injector) {
				route._injector.destroy();
				route._injector = void 0;
			}
			if (route._loadedInjector) {
				route._loadedInjector.destroy();
				route._loadedInjector = void 0;
			}
		}
	}
}
function destroyDetachedRouteHandle(handle) {
	const internalHandle = handle;
	if (internalHandle && internalHandle.componentRef) {
		internalHandle.componentRef.destroy();
		internalHandle.route.value._localInjector?.destroy();
	}
}
var RouteReuseStrategy = class RouteReuseStrategy {
	static ɵfac = function RouteReuseStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouteReuseStrategy)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: RouteReuseStrategy,
		factory: () => (() => inject(DefaultRouteReuseStrategy))()
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouteReuseStrategy, [{
		type: Service,
		args: [{ factory: () => inject(DefaultRouteReuseStrategy) }]
	}], null, null);
})();
var BaseRouteReuseStrategy = class {
	shouldDetach(route) {
		return false;
	}
	store(route, detachedTree) {}
	shouldAttach(route) {
		return false;
	}
	retrieve(route) {
		return null;
	}
	shouldReuseRoute(future, curr) {
		return future.routeConfig === curr.routeConfig;
	}
	shouldDestroyInjector(route) {
		return true;
	}
};
var DefaultRouteReuseStrategy = class DefaultRouteReuseStrategy extends BaseRouteReuseStrategy {
	static ɵfac = function DefaultRouteReuseStrategy_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || DefaultRouteReuseStrategy)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: DefaultRouteReuseStrategy,
		factory: DefaultRouteReuseStrategy.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultRouteReuseStrategy, [{ type: Service }], null, null);
})();
var StateManager = class StateManager {
	urlSerializer = inject(UrlSerializer);
	options = inject(ROUTER_CONFIGURATION, { optional: true }) || {};
	canceledNavigationResolution = this.options.canceledNavigationResolution || "replace";
	location = inject(Location);
	urlHandlingStrategy = inject(UrlHandlingStrategy);
	urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred";
	currentUrlTree = new UrlTree();
	getCurrentUrlTree() {
		return this.currentUrlTree;
	}
	rawUrlTree = this.currentUrlTree;
	getRawUrlTree() {
		return this.rawUrlTree;
	}
	createBrowserPath({ finalUrl, initialUrl, targetBrowserUrl }) {
		const rawUrl = finalUrl !== void 0 ? this.urlHandlingStrategy.merge(finalUrl, initialUrl) : initialUrl;
		const url = targetBrowserUrl ?? rawUrl;
		return url instanceof UrlTree ? this.urlSerializer.serialize(url) : url;
	}
	routerUrlState(navigation) {
		if (navigation?.targetBrowserUrl === void 0 || navigation?.finalUrl === void 0) return {};
		return { ɵrouterUrl: this.urlSerializer.serialize(navigation.finalUrl) };
	}
	commitTransition({ targetRouterState, finalUrl, initialUrl }) {
		if (finalUrl && targetRouterState) {
			this.currentUrlTree = finalUrl;
			this.rawUrlTree = this.urlHandlingStrategy.merge(finalUrl, initialUrl);
			this.routerState = targetRouterState;
		} else this.rawUrlTree = initialUrl;
	}
	routerState = createEmptyState(null, inject(EnvironmentInjector));
	getRouterState() {
		return this.routerState;
	}
	_stateMemento = this.createStateMemento();
	get stateMemento() {
		return this._stateMemento;
	}
	updateStateMemento() {
		this._stateMemento = this.createStateMemento();
	}
	createStateMemento() {
		return {
			rawUrlTree: this.rawUrlTree,
			currentUrlTree: this.currentUrlTree,
			routerState: this.routerState
		};
	}
	restoredState() {
		return this.location.getState();
	}
	static ɵfac = function StateManager_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || StateManager)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: StateManager,
		factory: () => (() => inject(HistoryStateManager))()
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(StateManager, [{
		type: Service,
		args: [{ factory: () => inject(HistoryStateManager) }]
	}], null, null);
})();
var HistoryStateManager = class HistoryStateManager extends StateManager {
	currentPageId = 0;
	lastSuccessfulId = -1;
	get browserPageId() {
		if (this.canceledNavigationResolution !== "computed") return this.currentPageId;
		return this.restoredState()?.ɵrouterPageId ?? this.currentPageId;
	}
	registerNonRouterCurrentEntryChangeListener(listener) {
		return this.location.subscribe((event) => {
			if (event["type"] === "popstate") setTimeout(() => {
				listener(event["url"], event.state, "popstate", { replaceUrl: true });
			});
		});
	}
	handleRouterEvent(e, currentTransition) {
		if (e instanceof NavigationStart) this.updateStateMemento();
		else if (e instanceof NavigationSkipped) this.commitTransition(currentTransition);
		else if (e instanceof RoutesRecognized) {
			if (this.urlUpdateStrategy === "eager") {
				if (!currentTransition.extras.skipLocationChange) this.setBrowserUrl(this.createBrowserPath(currentTransition), currentTransition);
			}
		} else if (e instanceof BeforeActivateRoutes) {
			this.commitTransition(currentTransition);
			if (this.urlUpdateStrategy === "deferred" && !currentTransition.extras.skipLocationChange) this.setBrowserUrl(this.createBrowserPath(currentTransition), currentTransition);
		} else if (e instanceof NavigationCancel && !isRedirectingEvent(e)) this.restoreHistory(currentTransition);
		else if (e instanceof NavigationError) this.restoreHistory(currentTransition, true);
		else if (e instanceof NavigationEnd) {
			this.lastSuccessfulId = e.id;
			this.currentPageId = this.browserPageId;
		}
	}
	setBrowserUrl(path, navigation) {
		const { extras, id } = navigation;
		const { replaceUrl, state } = extras;
		if (this.location.isCurrentPathEqualTo(path) || !!replaceUrl) {
			const currentBrowserPageId = this.browserPageId;
			const newState = {
				...state,
				...this.generateNgRouterState(id, currentBrowserPageId, navigation)
			};
			this.location.replaceState(path, "", newState);
		} else {
			const newState = {
				...state,
				...this.generateNgRouterState(id, this.browserPageId + 1, navigation)
			};
			this.location.go(path, "", newState);
		}
	}
	restoreHistory(navigation, restoringFromCaughtError = false) {
		if (this.canceledNavigationResolution === "computed") {
			const currentBrowserPageId = this.browserPageId;
			const targetPagePosition = this.currentPageId - currentBrowserPageId;
			if (targetPagePosition !== 0) this.location.historyGo(targetPagePosition);
			else if (this.getCurrentUrlTree() === navigation.finalUrl && targetPagePosition === 0) {
				this.resetInternalState(navigation);
				this.resetUrlToCurrentUrlTree();
			}
		} else if (this.canceledNavigationResolution === "replace") {
			if (restoringFromCaughtError) this.resetInternalState(navigation);
			this.resetUrlToCurrentUrlTree();
		}
	}
	resetInternalState({ finalUrl }) {
		this.routerState = this.stateMemento.routerState;
		this.currentUrlTree = this.stateMemento.currentUrlTree;
		this.rawUrlTree = this.urlHandlingStrategy.merge(this.currentUrlTree, finalUrl ?? this.rawUrlTree);
	}
	resetUrlToCurrentUrlTree() {
		this.location.replaceState(this.urlSerializer.serialize(this.getRawUrlTree()), "", this.generateNgRouterState(this.lastSuccessfulId, this.currentPageId));
	}
	generateNgRouterState(navigationId, routerPageId, navigation) {
		if (this.canceledNavigationResolution === "computed") return {
			navigationId,
			ɵrouterPageId: routerPageId,
			...this.routerUrlState(navigation)
		};
		return {
			navigationId,
			...this.routerUrlState(navigation)
		};
	}
	static ɵfac = function HistoryStateManager_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || HistoryStateManager)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: HistoryStateManager,
		factory: HistoryStateManager.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HistoryStateManager, [{ type: Service }], null, null);
})();
function afterNextNavigation(router, action) {
	router.events.pipe((0, import_operators.filter)((e) => e instanceof NavigationEnd || e instanceof NavigationCancel || e instanceof NavigationError || e instanceof NavigationSkipped), (0, import_operators.map)((e) => {
		if (e instanceof NavigationEnd || e instanceof NavigationSkipped) return 0;
		return (e instanceof NavigationCancel ? e.code === NavigationCancellationCode.Redirect || e.code === NavigationCancellationCode.SupersededByNewNavigation : false) ? 2 : 1;
	}), (0, import_operators.filter)((result) => result !== 2), (0, import_operators.take)(1)).subscribe(() => {
		action();
	});
}
var Router = class Router {
	get currentUrlTree() {
		return this.stateManager.getCurrentUrlTree();
	}
	get rawUrlTree() {
		return this.stateManager.getRawUrlTree();
	}
	disposed = false;
	nonRouterCurrentEntryChangeSubscription;
	console = inject(Console);
	stateManager = inject(StateManager);
	options = inject(ROUTER_CONFIGURATION, { optional: true }) || {};
	pendingTasks = inject(PendingTasksInternal);
	urlUpdateStrategy = this.options.urlUpdateStrategy || "deferred";
	navigationTransitions = inject(NavigationTransitions);
	urlSerializer = inject(UrlSerializer);
	location = inject(Location);
	urlHandlingStrategy = inject(UrlHandlingStrategy);
	injector = inject(EnvironmentInjector);
	_events = new import_cjs.Subject();
	get events() {
		return this._events;
	}
	get routerState() {
		return this.stateManager.getRouterState();
	}
	navigated = false;
	routeReuseStrategy = inject(RouteReuseStrategy);
	injectorCleanup = inject(ROUTE_INJECTOR_CLEANUP, { optional: true });
	onSameUrlNavigation = this.options.onSameUrlNavigation || "ignore";
	config = inject(ROUTES, { optional: true })?.flat() ?? [];
	componentInputBindingEnabled = !!inject(INPUT_BINDER, { optional: true });
	currentNavigation = this.navigationTransitions.currentNavigation.asReadonly();
	constructor() {
		this.resetConfig(this.config);
		this.navigationTransitions.setupNavigations(this).subscribe({ error: (e) => {} });
		this.subscribeToNavigationEvents();
	}
	eventsSubscription = new import_cjs.Subscription();
	subscribeToNavigationEvents() {
		const subscription = this.navigationTransitions.events.subscribe((e) => {
			try {
				const currentTransition = this.navigationTransitions.currentTransition;
				const currentNavigation = untracked(this.navigationTransitions.currentNavigation);
				if (currentTransition !== null && currentNavigation !== null) {
					this.stateManager.handleRouterEvent(e, currentNavigation);
					if (e instanceof NavigationCancel && e.code !== NavigationCancellationCode.Redirect && e.code !== NavigationCancellationCode.SupersededByNewNavigation) this.navigated = true;
					else if (e instanceof NavigationEnd) {
						this.navigated = true;
						this.injectorCleanup?.(this.routeReuseStrategy, this.routerState, this.config);
					} else if (e instanceof RedirectRequest) {
						const opts = e.navigationBehaviorOptions;
						const mergedTree = this.urlHandlingStrategy.merge(e.url, currentTransition.currentRawUrl);
						const extras = {
							scroll: currentTransition.extras.scroll,
							browserUrl: currentTransition.extras.browserUrl,
							info: currentTransition.extras.info,
							skipLocationChange: currentTransition.extras.skipLocationChange,
							replaceUrl: currentTransition.extras.replaceUrl || this.urlUpdateStrategy === "eager" || isBrowserTriggeredNavigation(currentTransition.source),
							...opts
						};
						this.scheduleNavigation(mergedTree, IMPERATIVE_NAVIGATION, null, extras, {
							resolve: currentTransition.resolve,
							reject: currentTransition.reject,
							promise: currentTransition.promise
						});
					}
				}
				if (isPublicRouterEvent(e)) this._events.next(e);
			} catch (e) {
				this.navigationTransitions.transitionAbortWithErrorSubject.next(e);
			}
		});
		this.eventsSubscription.add(subscription);
	}
	resetRootComponentType(rootComponentType) {
		this.routerState.root.component = rootComponentType;
		this.navigationTransitions.rootComponentType = rootComponentType;
	}
	initialNavigation() {
		this.setUpLocationChangeListener();
		if (!this.navigationTransitions.hasRequestedNavigation) this.navigateToSyncWithBrowser(this.location.path(true), IMPERATIVE_NAVIGATION, this.stateManager.restoredState(), { replaceUrl: true });
	}
	setUpLocationChangeListener() {
		this.nonRouterCurrentEntryChangeSubscription ??= this.stateManager.registerNonRouterCurrentEntryChangeListener((url, state, source, extras) => {
			this.navigateToSyncWithBrowser(url, source, state, extras);
		});
	}
	navigateToSyncWithBrowser(url, source, state, extras) {
		const restoredState = state?.navigationId ? state : null;
		const routerUrl = state?.ɵrouterUrl ?? url;
		if (state?.ɵrouterUrl) extras = {
			...extras,
			browserUrl: url
		};
		if (state) {
			const stateCopy = { ...state };
			delete stateCopy.navigationId;
			delete stateCopy.ɵrouterPageId;
			delete stateCopy.ɵrouterUrl;
			if (Object.keys(stateCopy).length !== 0) extras.state = stateCopy;
		}
		const urlTree = this.parseUrl(routerUrl);
		this.scheduleNavigation(urlTree, source, restoredState, extras).catch((e) => {
			if (this.disposed) return;
			this.injector.get(INTERNAL_APPLICATION_ERROR_HANDLER)(e);
		});
	}
	get url() {
		return this.serializeUrl(this.currentUrlTree);
	}
	getCurrentNavigation() {
		return untracked(this.navigationTransitions.currentNavigation);
	}
	get lastSuccessfulNavigation() {
		return this.navigationTransitions.lastSuccessfulNavigation;
	}
	resetConfig(config) {
		(typeof ngDevMode === "undefined" || ngDevMode) && validateConfig(config);
		this.config = config.map(standardizeConfig);
		this.navigated = false;
	}
	ngOnDestroy() {
		this.dispose();
	}
	dispose() {
		this._events.unsubscribe();
		this.navigationTransitions.complete();
		this.nonRouterCurrentEntryChangeSubscription?.unsubscribe();
		this.nonRouterCurrentEntryChangeSubscription = void 0;
		this.disposed = true;
		this.eventsSubscription.unsubscribe();
	}
	createUrlTree(commands, navigationExtras = {}) {
		const { relativeTo, queryParams, fragment, queryParamsHandling, preserveFragment } = navigationExtras;
		const f = preserveFragment ? this.currentUrlTree.fragment : fragment;
		let q = null;
		switch (queryParamsHandling ?? this.options.defaultQueryParamsHandling) {
			case "merge":
				q = {
					...this.currentUrlTree.queryParams,
					...queryParams
				};
				break;
			case "preserve":
				q = this.currentUrlTree.queryParams;
				break;
			default: q = queryParams || null;
		}
		if (q !== null) q = this.removeEmptyProps(q);
		let relativeToUrlSegmentGroup;
		try {
			relativeToUrlSegmentGroup = createSegmentGroupFromRoute(relativeTo ? relativeTo.snapshot : this.routerState.snapshot.root);
		} catch (e) {
			if (typeof commands[0] !== "string" || commands[0][0] !== "/") commands = [];
			relativeToUrlSegmentGroup = this.currentUrlTree.root;
		}
		return createUrlTreeFromSegmentGroup(relativeToUrlSegmentGroup, commands, q, f ?? null, this.urlSerializer);
	}
	navigateByUrl(url, extras = { skipLocationChange: false }) {
		const urlTree = isUrlTree(url) ? url : this.parseUrl(url);
		const mergedTree = this.urlHandlingStrategy.merge(urlTree, this.rawUrlTree);
		return this.scheduleNavigation(mergedTree, IMPERATIVE_NAVIGATION, null, extras);
	}
	navigate(commands, extras = { skipLocationChange: false }) {
		validateCommands(commands);
		return this.navigateByUrl(this.createUrlTree(commands, extras), extras);
	}
	serializeUrl(url) {
		return this.urlSerializer.serialize(url);
	}
	parseUrl(url) {
		try {
			return this.urlSerializer.parse(url);
		} catch (e) {
			this.console.warn(formatRuntimeError(4018, ngDevMode && `Error parsing URL ${url}. Falling back to '/' instead. \n` + e));
			return this.urlSerializer.parse("/");
		}
	}
	isActive(url, matchOptions) {
		let options;
		if (matchOptions === true) options = { ...exactMatchOptions };
		else if (matchOptions === false) options = { ...subsetMatchOptions };
		else options = {
			...subsetMatchOptions,
			...matchOptions
		};
		if (isUrlTree(url)) return containsTree(this.currentUrlTree, url, options);
		const urlTree = this.parseUrl(url);
		return containsTree(this.currentUrlTree, urlTree, options);
	}
	removeEmptyProps(params) {
		return Object.entries(params).reduce((result, [key, value]) => {
			if (value !== null && value !== void 0) result[key] = value;
			return result;
		}, {});
	}
	scheduleNavigation(rawUrl, source, restoredState, extras, priorPromise) {
		if (this.disposed) return Promise.resolve(false);
		let resolve;
		let reject;
		let promise;
		if (priorPromise) {
			resolve = priorPromise.resolve;
			reject = priorPromise.reject;
			promise = priorPromise.promise;
		} else promise = new Promise((res, rej) => {
			resolve = res;
			reject = rej;
		});
		const taskId = this.pendingTasks.add();
		afterNextNavigation(this, () => {
			queueMicrotask(() => this.pendingTasks.remove(taskId));
		});
		this.navigationTransitions.handleNavigationRequest({
			source,
			restoredState,
			currentUrlTree: this.currentUrlTree,
			currentRawUrl: this.currentUrlTree,
			rawUrl,
			extras,
			resolve,
			reject,
			promise,
			currentSnapshot: this.routerState.snapshot,
			currentRouterState: this.routerState
		});
		return promise.catch(Promise.reject.bind(Promise));
	}
	static ɵfac = function Router_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || Router)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: Router,
		factory: Router.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Router, [{ type: Service }], () => [], null);
})();
function validateCommands(commands) {
	for (let i = 0; i < commands.length; i++) {
		const cmd = commands[i];
		if (cmd == null) throw new RuntimeError(4008, (typeof ngDevMode === "undefined" || ngDevMode) && `The requested path contains ${cmd} segment at index ${i}`);
	}
}
//#endregion
//#region node_modules/@angular/router/fesm2022/_router_module-chunk.mjs
/**
* @license Angular v22.1.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
var ReactiveRouterState = class ReactiveRouterState {
	router = inject(Router);
	stateManager = inject(StateManager);
	fragment = signal("", ...ngDevMode ? [{ debugName: "fragment" }] : []);
	queryParams = signal({}, ...ngDevMode ? [{ debugName: "queryParams" }] : []);
	path = signal("", ...ngDevMode ? [{ debugName: "path" }] : []);
	serializer = inject(UrlSerializer);
	constructor() {
		this.updateState();
		this.router.events?.subscribe((e) => {
			if (e instanceof NavigationEnd) this.updateState();
		});
	}
	updateState() {
		const { fragment, root, queryParams } = this.stateManager.getCurrentUrlTree();
		this.fragment.set(fragment);
		this.queryParams.set(queryParams);
		this.path.set(this.serializer.serialize(new UrlTree(root)));
	}
	static ɵfac = function ReactiveRouterState_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || ReactiveRouterState)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: ReactiveRouterState,
		factory: ReactiveRouterState.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReactiveRouterState, [{ type: Service }], () => [], null);
})();
var RouterLink = class RouterLink {
	router;
	route;
	tabIndexAttribute;
	renderer;
	el;
	locationStrategy;
	hrefAttributeValue = inject(new HostAttributeToken("href"), { optional: true });
	reactiveHref = linkedSignal(() => {
		if (!this.isAnchorElement) return this.hrefAttributeValue;
		return this.computeHref(this._urlTree());
	}, ...ngDevMode ? [{ debugName: "reactiveHref" }] : []);
	get href() {
		return untracked(this.reactiveHref);
	}
	set href(value) {
		this.reactiveHref.set(value);
	}
	set target(value) {
		this._target.set(value);
	}
	get target() {
		return untracked(this._target);
	}
	_target = signal(void 0, ...ngDevMode ? [{ debugName: "_target" }] : []);
	set queryParams(value) {
		this._queryParams.set(value);
	}
	get queryParams() {
		return untracked(this._queryParams);
	}
	_queryParams = signal(void 0, {
		...ngDevMode ? { debugName: "_queryParams" } : {},
		equal: () => false
	});
	set fragment(value) {
		this._fragment.set(value);
	}
	get fragment() {
		return untracked(this._fragment);
	}
	_fragment = signal(void 0, ...ngDevMode ? [{ debugName: "_fragment" }] : []);
	set queryParamsHandling(value) {
		this._queryParamsHandling.set(value);
	}
	get queryParamsHandling() {
		return untracked(this._queryParamsHandling);
	}
	_queryParamsHandling = signal(void 0, ...ngDevMode ? [{ debugName: "_queryParamsHandling" }] : []);
	set state(value) {
		this._state.set(value);
	}
	get state() {
		return untracked(this._state);
	}
	_state = signal(void 0, {
		...ngDevMode ? { debugName: "_state" } : {},
		equal: () => false
	});
	set info(value) {
		this._info.set(value);
	}
	get info() {
		return untracked(this._info);
	}
	_info = signal(void 0, {
		...ngDevMode ? { debugName: "_info" } : {},
		equal: () => false
	});
	set relativeTo(value) {
		this._relativeTo.set(value);
	}
	get relativeTo() {
		return untracked(this._relativeTo);
	}
	_relativeTo = signal(void 0, ...ngDevMode ? [{ debugName: "_relativeTo" }] : []);
	set preserveFragment(value) {
		this._preserveFragment.set(value);
	}
	get preserveFragment() {
		return untracked(this._preserveFragment);
	}
	_preserveFragment = signal(false, ...ngDevMode ? [{ debugName: "_preserveFragment" }] : []);
	set skipLocationChange(value) {
		this._skipLocationChange.set(value);
	}
	get skipLocationChange() {
		return untracked(this._skipLocationChange);
	}
	_skipLocationChange = signal(false, ...ngDevMode ? [{ debugName: "_skipLocationChange" }] : []);
	set replaceUrl(value) {
		this._replaceUrl.set(value);
	}
	get replaceUrl() {
		return untracked(this._replaceUrl);
	}
	_replaceUrl = signal(false, ...ngDevMode ? [{ debugName: "_replaceUrl" }] : []);
	browserUrl = input(void 0, ...ngDevMode ? [{ debugName: "browserUrl" }] : []);
	isAnchorElement;
	onChanges = new import_cjs.Subject();
	applicationErrorHandler = inject(INTERNAL_APPLICATION_ERROR_HANDLER);
	options = inject(ROUTER_CONFIGURATION, { optional: true });
	reactiveRouterState = inject(ReactiveRouterState);
	constructor(router, route, tabIndexAttribute, renderer, el, locationStrategy) {
		this.router = router;
		this.route = route;
		this.tabIndexAttribute = tabIndexAttribute;
		this.renderer = renderer;
		this.el = el;
		this.locationStrategy = locationStrategy;
		const tagName = el.nativeElement.tagName?.toLowerCase();
		this.isAnchorElement = tagName === "a" || tagName === "area" || !!(typeof customElements === "object" && customElements.get(tagName)?.observedAttributes?.includes?.("href"));
		if (typeof ngDevMode !== "undefined" && ngDevMode) effect(() => {
			if (isUrlTree(this.routerLinkInput()) && (this._fragment() !== void 0 || this._queryParams() || this._queryParamsHandling() || this._preserveFragment() || this._relativeTo())) throw new RuntimeError(4017, "Cannot configure queryParams or fragment when using a UrlTree as the routerLink input value.");
		});
	}
	setTabIndexIfNotOnNativeEl(newTabIndex) {
		if (this.tabIndexAttribute != null || this.isAnchorElement) return;
		this.applyAttributeValue("tabindex", newTabIndex);
	}
	ngOnChanges(changes) {
		this.onChanges.next(this);
	}
	routerLinkInput = signal(null, ...ngDevMode ? [{ debugName: "routerLinkInput" }] : []);
	set routerLink(commandsOrUrlTree) {
		if (commandsOrUrlTree == null) {
			this.routerLinkInput.set(null);
			this.setTabIndexIfNotOnNativeEl(null);
		} else {
			if (isUrlTree(commandsOrUrlTree)) this.routerLinkInput.set(commandsOrUrlTree);
			else this.routerLinkInput.set(Array.isArray(commandsOrUrlTree) ? commandsOrUrlTree : [commandsOrUrlTree]);
			this.setTabIndexIfNotOnNativeEl("0");
		}
	}
	onClick(button, ctrlKey, shiftKey, altKey, metaKey) {
		const urlTree = this._urlTree();
		if (urlTree === null) return true;
		if (this.isAnchorElement) {
			if (button !== 0 || ctrlKey || shiftKey || altKey || metaKey) return true;
			if (typeof this.target === "string" && this.target != "_self") return true;
		}
		const browserUrl = this.browserUrl();
		const extras = {
			skipLocationChange: this.skipLocationChange,
			replaceUrl: this.replaceUrl,
			state: this.state,
			info: this.info,
			...browserUrl !== void 0 && { browserUrl }
		};
		this.router.navigateByUrl(urlTree, extras)?.catch((e) => {
			this.applicationErrorHandler(e);
		});
		return !this.isAnchorElement;
	}
	ngOnDestroy() {}
	applyAttributeValue(attrName, attrValue) {
		const renderer = this.renderer;
		const nativeElement = this.el.nativeElement;
		if (attrValue !== null) renderer.setAttribute(nativeElement, attrName, attrValue);
		else renderer.removeAttribute(nativeElement, attrName);
	}
	_urlTree = computed(() => {
		this.reactiveRouterState.path();
		if (this._preserveFragment()) this.reactiveRouterState.fragment();
		const shouldTrackParams = (handling) => handling === "preserve" || handling === "merge";
		if (shouldTrackParams(this._queryParamsHandling()) || shouldTrackParams(this.options?.defaultQueryParamsHandling)) this.reactiveRouterState.queryParams();
		const routerLinkInput = this.routerLinkInput();
		if (routerLinkInput === null || !this.router.createUrlTree) return null;
		else if (isUrlTree(routerLinkInput)) return routerLinkInput;
		return this.router.createUrlTree(routerLinkInput, {
			relativeTo: this._relativeTo() !== void 0 ? this._relativeTo() : this.route,
			queryParams: this._queryParams(),
			fragment: this._fragment(),
			queryParamsHandling: this._queryParamsHandling(),
			preserveFragment: this._preserveFragment()
		});
	}, {
		...ngDevMode ? { debugName: "_urlTree" } : {},
		equal: (a, b) => this.computeHref(a) === this.computeHref(b)
	});
	get urlTree() {
		return untracked(this._urlTree);
	}
	computeHref(urlTree) {
		return urlTree !== null && this.locationStrategy ? this.locationStrategy?.prepareExternalUrl(this.router.serializeUrl(urlTree)) ?? "" : null;
	}
	static ɵfac = function RouterLink_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterLink)(ɵɵdirectiveInject(Router), ɵɵdirectiveInject(ActivatedRoute), ɵɵinjectAttribute("tabindex"), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(LocationStrategy));
	};
	static ɵdir = /* @__PURE__ */ ɵɵdefineDirective({
		type: RouterLink,
		selectors: [[
			"",
			"routerLink",
			""
		]],
		hostVars: 2,
		hostBindings: function RouterLink_HostBindings(rf, ctx) {
			if (rf & 1) ɵɵlistener("click", function RouterLink_click_HostBindingHandler($event) {
				return ctx.onClick($event.button, $event.ctrlKey, $event.shiftKey, $event.altKey, $event.metaKey);
			});
			if (rf & 2) ɵɵattribute("href", ctx.reactiveHref(), ɵɵsanitizeUrlOrResourceUrl)("target", ctx._target());
		},
		inputs: {
			target: "target",
			queryParams: "queryParams",
			fragment: "fragment",
			queryParamsHandling: "queryParamsHandling",
			state: "state",
			info: "info",
			relativeTo: "relativeTo",
			preserveFragment: [
				2,
				"preserveFragment",
				"preserveFragment",
				booleanAttribute
			],
			skipLocationChange: [
				2,
				"skipLocationChange",
				"skipLocationChange",
				booleanAttribute
			],
			replaceUrl: [
				2,
				"replaceUrl",
				"replaceUrl",
				booleanAttribute
			],
			browserUrl: [1, "browserUrl"],
			routerLink: "routerLink"
		},
		features: [ɵɵNgOnChangesFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterLink, [{
		type: Directive,
		args: [{
			selector: "[routerLink]",
			host: {
				"[attr.href]": "reactiveHref()",
				"[attr.target]": "_target()"
			}
		}]
	}], () => [
		{ type: Router },
		{ type: ActivatedRoute },
		{
			type: void 0,
			decorators: [{
				type: Attribute,
				args: ["tabindex"]
			}]
		},
		{ type: Renderer2 },
		{ type: ElementRef },
		{ type: LocationStrategy }
	], {
		target: [{ type: Input }],
		queryParams: [{ type: Input }],
		fragment: [{ type: Input }],
		queryParamsHandling: [{ type: Input }],
		state: [{ type: Input }],
		info: [{ type: Input }],
		relativeTo: [{ type: Input }],
		preserveFragment: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		skipLocationChange: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		replaceUrl: [{
			type: Input,
			args: [{ transform: booleanAttribute }]
		}],
		browserUrl: [{
			type: Input,
			args: [{
				isSignal: true,
				alias: "browserUrl",
				required: false
			}]
		}],
		routerLink: [{ type: Input }],
		onClick: [{
			type: HostListener,
			args: ["click", [
				"$event.button",
				"$event.ctrlKey",
				"$event.shiftKey",
				"$event.altKey",
				"$event.metaKey"
			]]
		}]
	});
})();
var RouterLinkActive = class RouterLinkActive {
	router;
	element;
	renderer;
	cdr;
	links;
	classes = [];
	routerEventsSubscription;
	linkInputChangesSubscription;
	_isActive = false;
	get isActive() {
		return this._isActive;
	}
	routerLinkActiveOptions = { exact: false };
	ariaCurrentWhenActive;
	isActiveChange = new EventEmitter();
	link = inject(RouterLink, { optional: true });
	constructor(router, element, renderer, cdr) {
		this.router = router;
		this.element = element;
		this.renderer = renderer;
		this.cdr = cdr;
		this.routerEventsSubscription = router.events.subscribe((s) => {
			if (s instanceof NavigationEnd) this.update();
		});
	}
	ngAfterContentInit() {
		(0, import_cjs.of)(this.links.changes, (0, import_cjs.of)(null)).pipe((0, import_operators.mergeAll)()).subscribe((_) => {
			this.update();
			this.subscribeToEachLinkOnChanges();
		});
	}
	subscribeToEachLinkOnChanges() {
		this.linkInputChangesSubscription?.unsubscribe();
		const allLinkChanges = [...this.links.toArray(), this.link].filter((link) => !!link).map((link) => link.onChanges);
		this.linkInputChangesSubscription = (0, import_cjs.from)(allLinkChanges).pipe((0, import_operators.mergeAll)()).subscribe((link) => {
			if (this._isActive !== this.isLinkActive(this.router)(link)) this.update();
		});
	}
	set routerLinkActive(data) {
		if (data == null) {
			this.classes = [];
			return;
		}
		const classes = Array.isArray(data) ? data : data.split(" ");
		this.classes = classes.filter((c) => !!c);
	}
	ngOnChanges(changes) {
		this.update();
	}
	ngOnDestroy() {
		this.routerEventsSubscription.unsubscribe();
		this.linkInputChangesSubscription?.unsubscribe();
	}
	update() {
		if (!this.links || !this.router.navigated) return;
		if (this.routerLinkActiveOptions === null && !this._isActive) return;
		queueMicrotask(() => {
			const hasActiveLinks = this.hasActiveLinks();
			this.classes.forEach((c) => {
				if (hasActiveLinks) this.renderer.addClass(this.element.nativeElement, c);
				else this.renderer.removeClass(this.element.nativeElement, c);
			});
			if (hasActiveLinks && this.ariaCurrentWhenActive !== void 0) this.renderer.setAttribute(this.element.nativeElement, "aria-current", this.ariaCurrentWhenActive.toString());
			else this.renderer.removeAttribute(this.element.nativeElement, "aria-current");
			if (this._isActive !== hasActiveLinks) {
				this._isActive = hasActiveLinks;
				this.cdr.markForCheck();
				this.isActiveChange.emit(hasActiveLinks);
			}
		});
	}
	isLinkActive(router) {
		const opts = this.routerLinkActiveOptions;
		if (opts === null) return () => false;
		let options;
		if (opts === void 0) options = { ...subsetMatchOptions };
		else if (isActiveMatchOptions(opts)) options = opts;
		else if (opts.exact ?? false) options = { ...exactMatchOptions };
		else options = { ...subsetMatchOptions };
		return (link) => {
			const urlTree = link.urlTree;
			return urlTree ? untracked(isActive(urlTree, router, options)) : false;
		};
	}
	hasActiveLinks() {
		const isActiveCheckFn = this.isLinkActive(this.router);
		return this.link && isActiveCheckFn(this.link) || this.links.some(isActiveCheckFn);
	}
	static ɵfac = function RouterLinkActive_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterLinkActive)(ɵɵdirectiveInject(Router), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef));
	};
	static ɵdir = /* @__PURE__ */ ɵɵdefineDirective({
		type: RouterLinkActive,
		selectors: [[
			"",
			"routerLinkActive",
			""
		]],
		contentQueries: function RouterLinkActive_ContentQueries(rf, ctx, dirIndex) {
			if (rf & 1) ɵɵcontentQuery(dirIndex, RouterLink, 5);
			if (rf & 2) {
				let _t;
				ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.links = _t);
			}
		},
		inputs: {
			routerLinkActiveOptions: "routerLinkActiveOptions",
			ariaCurrentWhenActive: "ariaCurrentWhenActive",
			routerLinkActive: "routerLinkActive"
		},
		outputs: { isActiveChange: "isActiveChange" },
		exportAs: ["routerLinkActive"],
		features: [ɵɵNgOnChangesFeature]
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterLinkActive, [{
		type: Directive,
		args: [{
			selector: "[routerLinkActive]",
			exportAs: "routerLinkActive"
		}]
	}], () => [
		{ type: Router },
		{ type: ElementRef },
		{ type: Renderer2 },
		{ type: ChangeDetectorRef }
	], {
		links: [{
			type: ContentChildren,
			args: [RouterLink, { descendants: true }]
		}],
		routerLinkActiveOptions: [{ type: Input }],
		ariaCurrentWhenActive: [{ type: Input }],
		isActiveChange: [{ type: Output }],
		routerLinkActive: [{ type: Input }]
	});
})();
function isActiveMatchOptions(options) {
	const o = options;
	return !!(o.paths || o.matrixParams || o.queryParams || o.fragment);
}
var PreloadingStrategy = class {};
var PreloadAllModules = class PreloadAllModules {
	preload(route, fn) {
		return fn().pipe((0, import_operators.catchError)(() => (0, import_cjs.of)(null)));
	}
	static ɵfac = function PreloadAllModules_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || PreloadAllModules)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: PreloadAllModules,
		factory: PreloadAllModules.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PreloadAllModules, [{ type: Service }], null, null);
})();
var NoPreloading = class NoPreloading {
	preload(route, fn) {
		return (0, import_cjs.of)(null);
	}
	static ɵfac = function NoPreloading_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || NoPreloading)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: NoPreloading,
		factory: NoPreloading.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NoPreloading, [{ type: Service }], null, null);
})();
var RouterPreloader = class RouterPreloader {
	router;
	injector;
	preloadingStrategy;
	loader;
	subscription;
	constructor(router, injector, preloadingStrategy, loader) {
		this.router = router;
		this.injector = injector;
		this.preloadingStrategy = preloadingStrategy;
		this.loader = loader;
	}
	setUpPreloading() {
		this.subscription = this.router.events.pipe((0, import_operators.filter)((e) => e instanceof NavigationEnd), (0, import_operators.concatMap)(() => this.preload())).subscribe(() => {});
	}
	preload() {
		return this.processRoutes(this.injector, this.router.config);
	}
	ngOnDestroy() {
		this.subscription?.unsubscribe();
	}
	processRoutes(injector, routes) {
		const res = [];
		for (const route of routes) {
			if (route.providers && !route._injector) route._injector = createEnvironmentInjector(route.providers, injector, typeof ngDevMode === "undefined" || ngDevMode ? `Route: ${route.path}` : "");
			const injectorForCurrentRoute = route._injector ?? injector;
			if (route._loadedNgModuleFactory && !route._loadedInjector) route._loadedInjector = route._loadedNgModuleFactory.create(injectorForCurrentRoute).injector;
			const injectorForChildren = route._loadedInjector ?? injectorForCurrentRoute;
			if (route.loadChildren && !route._loadedRoutes && route.canLoad === void 0 || route.loadComponent && !route._loadedComponent) res.push(this.preloadConfig(injectorForCurrentRoute, route));
			if (route.children || route._loadedRoutes) res.push(this.processRoutes(injectorForChildren, route.children ?? route._loadedRoutes));
		}
		return (0, import_cjs.from)(res).pipe((0, import_operators.mergeAll)());
	}
	preloadConfig(injector, route) {
		return this.preloadingStrategy.preload(route, () => {
			if (injector.destroyed) return (0, import_cjs.of)(null);
			let loadedChildren$;
			if (route.loadChildren && route.canLoad === void 0) loadedChildren$ = (0, import_cjs.from)(this.loader.loadChildren(injector, route));
			else loadedChildren$ = (0, import_cjs.of)(null);
			const recursiveLoadChildren$ = loadedChildren$.pipe((0, import_operators.mergeMap)((config) => {
				if (config === null) return (0, import_cjs.of)(void 0);
				route._loadedRoutes = config.routes;
				route._loadedInjector = config.injector;
				route._loadedNgModuleFactory = config.factory;
				return this.processRoutes(config.injector ?? injector, config.routes);
			}));
			if (route.loadComponent && !route._loadedComponent) return (0, import_cjs.from)([recursiveLoadChildren$, this.loader.loadComponent(injector, route)]).pipe((0, import_operators.mergeAll)());
			else return recursiveLoadChildren$;
		});
	}
	static ɵfac = function RouterPreloader_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterPreloader)(ɵɵinject(Router), ɵɵinject(EnvironmentInjector), ɵɵinject(PreloadingStrategy), ɵɵinject(RouterConfigLoader));
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: RouterPreloader,
		factory: RouterPreloader.ɵfac,
		providedIn: "root"
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterPreloader, [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}], () => [
		{ type: Router },
		{ type: EnvironmentInjector },
		{ type: PreloadingStrategy },
		{ type: RouterConfigLoader }
	], null);
})();
var ROUTER_SCROLLER = new InjectionToken(typeof ngDevMode !== "undefined" && ngDevMode ? "Router Scroller" : "");
var RouterScroller = class RouterScroller {
	options;
	routerEventsSubscription;
	scrollEventsSubscription;
	lastId = 0;
	lastSource = IMPERATIVE_NAVIGATION;
	restoredId = 0;
	store = {};
	isHydrating = inject(IS_HYDRATION_DOM_REUSE_ENABLED, { optional: true }) ?? false;
	urlSerializer = inject(UrlSerializer);
	zone = inject(NgZone);
	viewportScroller = inject(ViewportScroller);
	transitions = inject(NavigationTransitions);
	constructor(options) {
		this.options = options;
		this.options.scrollPositionRestoration ||= "disabled";
		this.options.anchorScrolling ||= "disabled";
		if (this.isHydrating) inject(ApplicationRef).whenStable().then(() => {
			this.isHydrating = false;
		});
	}
	init() {
		if (this.options.scrollPositionRestoration !== "disabled") this.viewportScroller.setHistoryScrollRestoration("manual");
		this.routerEventsSubscription = this.createScrollEvents();
		this.scrollEventsSubscription = this.consumeScrollEvents();
	}
	createScrollEvents() {
		return this.transitions.events.subscribe((e) => {
			if (e instanceof NavigationStart) {
				this.store[this.lastId] = this.viewportScroller.getScrollPosition();
				this.lastSource = e.navigationTrigger;
				this.restoredId = e.restoredState ? e.restoredState.navigationId : 0;
			} else if (e instanceof NavigationEnd) {
				this.lastId = e.id;
				this.scheduleScrollEvent(e, this.urlSerializer.parse(e.urlAfterRedirects).fragment);
			} else if (e instanceof NavigationSkipped && e.code === NavigationSkippedCode.IgnoredSameUrlNavigation) {
				this.lastSource = void 0;
				this.restoredId = 0;
				this.scheduleScrollEvent(e, this.urlSerializer.parse(e.url).fragment);
			}
		});
	}
	consumeScrollEvents() {
		return this.transitions.events.subscribe((e) => {
			if (!(e instanceof Scroll) || e.scrollBehavior === "manual") return;
			const instantScroll = { behavior: "instant" };
			if (e.position) {
				if (this.options.scrollPositionRestoration === "top") this.viewportScroller.scrollToPosition([0, 0], instantScroll);
				else if (this.options.scrollPositionRestoration === "enabled") this.viewportScroller.scrollToPosition(e.position, instantScroll);
			} else if (e.anchor && this.options.anchorScrolling === "enabled") this.viewportScroller.scrollToAnchor(e.anchor);
			else if (this.options.scrollPositionRestoration !== "disabled") this.viewportScroller.scrollToPosition([0, 0]);
		});
	}
	scheduleScrollEvent(routerEvent, anchor) {
		if (this.isHydrating) return;
		const scroll = untracked(this.transitions.currentNavigation)?.extras.scroll;
		this.zone.runOutsideAngular(async () => {
			await new Promise((resolve) => {
				setTimeout(resolve);
				if (typeof requestAnimationFrame !== "undefined") requestAnimationFrame(resolve);
			});
			this.zone.run(() => {
				this.transitions.events.next(new Scroll(routerEvent, this.lastSource === "popstate" ? this.store[this.restoredId] : null, anchor, scroll));
			});
		});
	}
	ngOnDestroy() {
		this.routerEventsSubscription?.unsubscribe();
		this.scrollEventsSubscription?.unsubscribe();
	}
	static ɵfac = function RouterScroller_Factory(__ngFactoryType__) {
		ɵɵinvalidFactory();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineInjectable({
		token: RouterScroller,
		factory: RouterScroller.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterScroller, [{ type: Injectable }], () => [{ type: void 0 }], null);
})();
function getLoadedRoutes(route) {
	return route._loadedRoutes;
}
function getRouterInstance(injector) {
	return injector.get(Router, null, { optional: true });
}
function navigateByUrl(router, url) {
	if (!(router instanceof Router)) throw new Error("The provided router is not an Angular Router.");
	return router.navigateByUrl(url);
}
var NavigationStateManager = class NavigationStateManager extends StateManager {
	injector = inject(EnvironmentInjector);
	navigation = inject(PlatformNavigation);
	inMemoryScrollingEnabled = inject(ROUTER_SCROLLER, { optional: true }) !== null;
	base = new URL(inject(PlatformLocation).href).origin;
	appRootUrl = new URL(this.location.prepareExternalUrl?.("/") ?? "/", this.base);
	precommitHandlerSupported = inject(PRECOMMIT_HANDLER_SUPPORTED);
	activeHistoryEntry = this.navigation.currentEntry;
	currentNavigation = {};
	nonRouterCurrentEntryChangeSubject = new import_cjs.Subject();
	nonRouterEntryChangeListener;
	get registered() {
		return this.nonRouterEntryChangeListener !== void 0 && !this.nonRouterEntryChangeListener.closed;
	}
	constructor() {
		super();
		const navigateListener = (event) => {
			this.handleNavigate(event);
		};
		this.navigation.addEventListener("navigate", navigateListener);
		inject(DestroyRef).onDestroy(() => this.navigation.removeEventListener("navigate", navigateListener));
	}
	registerNonRouterCurrentEntryChangeListener(listener) {
		this.activeHistoryEntry = this.navigation.currentEntry;
		this.nonRouterEntryChangeListener = this.nonRouterCurrentEntryChangeSubject.subscribe(({ path, state }) => {
			listener(path, state, "popstate", !this.precommitHandlerSupported ? { replaceUrl: true } : {});
		});
		return this.nonRouterEntryChangeListener;
	}
	async handleRouterEvent(e, transition) {
		this.currentNavigation = {
			...this.currentNavigation,
			routerTransition: transition
		};
		if (e instanceof NavigationStart) {
			this.updateStateMemento();
			if (this.precommitHandlerSupported) this.maybeCreateNavigationForTransition(transition);
		} else if (e instanceof NavigationSkipped) {
			this.finishNavigation();
			this.commitTransition(transition);
		} else if (e instanceof BeforeRoutesRecognized) transition.routesRecognizeHandler.deferredHandle = new Promise(async (resolve) => {
			if (this.urlUpdateStrategy === "eager") try {
				this.maybeCreateNavigationForTransition(transition);
				await this.currentNavigation.commitUrl?.();
			} catch {
				return;
			}
			resolve();
		});
		else if (e instanceof BeforeActivateRoutes) transition.beforeActivateHandler.deferredHandle = new Promise(async (resolve) => {
			if (this.urlUpdateStrategy === "deferred") try {
				this.maybeCreateNavigationForTransition(transition);
				await this.currentNavigation.commitUrl?.();
			} catch {
				return;
			}
			this.commitTransition(transition);
			resolve();
		});
		else if (e instanceof NavigationCancel || e instanceof NavigationError) {
			if (e instanceof NavigationCancel && e.code === NavigationCancellationCode.Redirect && !!this.currentNavigation.commitUrl) return;
			this.cancel(transition, e);
		} else if (e instanceof NavigationEnd) {
			const { resolveHandler, removeAbortListener } = this.currentNavigation;
			this.currentNavigation = {};
			removeAbortListener?.();
			this.activeHistoryEntry = this.navigation.currentEntry;
			afterNextRender({ read: () => resolveHandler?.() }, { injector: this.injector });
		}
	}
	maybeCreateNavigationForTransition(transition) {
		const { navigationEvent, commitUrl } = this.currentNavigation;
		if (commitUrl || navigationEvent && navigationEvent.navigationType === "traverse" && this.eventAndRouterDestinationsMatch(navigationEvent, transition)) return;
		this.currentNavigation.removeAbortListener?.();
		const path = this.createBrowserPath(transition);
		this.navigate(path, transition);
	}
	navigate(internalPath, transition) {
		const path = transition.extras.skipLocationChange ? this.navigation.currentEntry.url : this.location.prepareExternalUrl(internalPath);
		const state = {
			...transition.extras.state,
			...this.generateNgRouterState(transition)
		};
		const info = { ɵrouterInfo: { intercept: true } };
		if (!this.navigation.transition && this.currentNavigation.navigationEvent) transition.extras.replaceUrl = false;
		const history = this.location.isCurrentPathEqualTo(path) || transition.extras.replaceUrl || transition.extras.skipLocationChange ? "replace" : "push";
		handleResultRejections(this.navigation.navigate(path, {
			state,
			history,
			info
		}));
	}
	finishNavigation() {
		this.currentNavigation.commitUrl?.();
		this.currentNavigation?.resolveHandler?.();
		this.currentNavigation = {};
	}
	async cancel(transition, cause) {
		this.currentNavigation.rejectNavigateEvent?.();
		const clearedState = {};
		this.currentNavigation = clearedState;
		if (isRedirectingEvent(cause)) return;
		const isTraversalReset = this.canceledNavigationResolution === "computed" && this.navigation.currentEntry.key !== this.activeHistoryEntry.key;
		this.resetInternalState(transition.finalUrl, isTraversalReset);
		if (this.navigation.currentEntry.id === this.activeHistoryEntry.id) return;
		if (cause instanceof NavigationCancel && cause.code === NavigationCancellationCode.Aborted) {
			await Promise.resolve();
			if (this.currentNavigation !== clearedState) return;
		}
		if (isTraversalReset) handleResultRejections(this.navigation.traverseTo(this.activeHistoryEntry.key, { info: { ɵrouterInfo: { intercept: false } } }));
		else {
			const internalPath = this.urlSerializer.serialize(this.getCurrentUrlTree());
			const pathOrUrl = this.location.prepareExternalUrl(internalPath);
			handleResultRejections(this.navigation.navigate(pathOrUrl, {
				state: this.activeHistoryEntry.getState(),
				history: "replace",
				info: { ɵrouterInfo: { intercept: false } }
			}));
		}
	}
	resetInternalState(finalUrl, traversalReset) {
		this.routerState = this.stateMemento.routerState;
		this.currentUrlTree = this.stateMemento.currentUrlTree;
		this.rawUrlTree = traversalReset ? this.stateMemento.rawUrlTree : this.urlHandlingStrategy.merge(this.currentUrlTree, finalUrl ?? this.rawUrlTree);
	}
	handleNavigate(event) {
		if (!event.canIntercept || event.navigationType === "reload") return;
		const routerInfo = event?.info?.ɵrouterInfo;
		if (routerInfo && !routerInfo.intercept) return;
		const isTriggeredByRouterTransition = !!routerInfo;
		if (!isTriggeredByRouterTransition) {
			const { pathname: destPathname, origin: destOrigin } = new URL(event.destination.url);
			const { pathname: rootPathname, origin: appOrigin } = this.appRootUrl;
			const rootPath = rootPathname.endsWith("/") ? rootPathname : rootPathname + "/";
			if (destOrigin !== appOrigin || destPathname !== rootPathname && !destPathname.startsWith(rootPath)) return;
			this.currentNavigation.routerTransition?.abort();
			if (!this.registered) {
				this.finishNavigation();
				return;
			}
		}
		this.currentNavigation = { ...this.currentNavigation };
		this.currentNavigation.navigationEvent = event;
		const abortHandler = () => {
			this.currentNavigation.routerTransition?.abort();
		};
		event.signal.addEventListener("abort", abortHandler);
		this.currentNavigation.removeAbortListener = () => event.signal.removeEventListener("abort", abortHandler);
		const interceptOptions = { scroll: this.inMemoryScrollingEnabled ? "manual" : this.currentNavigation.routerTransition?.extras.scroll ?? "after-transition" };
		const { promise: handlerPromise, resolve: resolveHandler, reject: rejectHandler } = promiseWithResolvers();
		const { promise: precommitHandlerPromise, resolve: resolvePrecommitHandler, reject: rejectPrecommitHandler } = promiseWithResolvers();
		this.currentNavigation.rejectNavigateEvent = () => {
			event.signal.removeEventListener("abort", abortHandler);
			rejectPrecommitHandler();
			rejectHandler();
		};
		this.currentNavigation.resolveHandler = () => {
			this.currentNavigation.removeAbortListener?.();
			resolveHandler();
		};
		handlerPromise.catch(() => {});
		precommitHandlerPromise.catch(() => {});
		interceptOptions.handler = () => handlerPromise;
		if (this.deferredCommitSupported(event)) {
			const redirect = new Promise((resolve) => {
				interceptOptions.precommitHandler = (controller) => {
					if (this.navigation.transition?.navigationType === "traverse") resolve(() => {});
					else resolve(controller.redirect.bind(controller));
					return precommitHandlerPromise;
				};
			});
			this.currentNavigation.commitUrl = async () => {
				this.currentNavigation.commitUrl = void 0;
				const transition = this.currentNavigation.routerTransition;
				if (transition && !transition.extras.skipLocationChange) {
					const internalPath = this.createBrowserPath(transition);
					const history = this.location.isCurrentPathEqualTo(internalPath) || !!transition.extras.replaceUrl ? "replace" : "push";
					const state = {
						...transition.extras.state,
						...this.generateNgRouterState(transition)
					};
					const pathOrUrl = this.location.prepareExternalUrl(internalPath);
					(await redirect)(pathOrUrl, {
						state,
						history
					});
				}
				resolvePrecommitHandler();
				return await this.navigation.transition?.committed;
			};
		}
		event.intercept(interceptOptions);
		if (!isTriggeredByRouterTransition) this.handleNavigateEventTriggeredOutsideRouterAPIs(event);
	}
	handleNavigateEventTriggeredOutsideRouterAPIs(event) {
		const path = event.destination.url.substring(this.appRootUrl.href.length - 1);
		const state = event.destination.getState();
		this.nonRouterCurrentEntryChangeSubject.next({
			path,
			state
		});
	}
	eventAndRouterDestinationsMatch(navigateEvent, transition) {
		const internalPath = this.createBrowserPath(transition);
		const eventDestination = new URL(navigateEvent.destination.url);
		const routerDestination = new URL(this.location.prepareExternalUrl(internalPath), eventDestination.origin);
		eventDestination.searchParams.sort();
		routerDestination.searchParams.sort();
		const { pathname: destPathname, search: destSearch, hash: hashDest } = routerDestination;
		const { pathname: eventDestPathname, search: eventDestSearch, hash: eventDestHash } = eventDestination;
		return destSearch === eventDestSearch && hashDest === eventDestHash && Location.stripTrailingSlash(destPathname) === Location.stripTrailingSlash(eventDestPathname);
	}
	generateNgRouterState(transition) {
		return {
			...this.routerUrlState(transition),
			navigationId: transition.id
		};
	}
	deferredCommitSupported(event) {
		return this.precommitHandlerSupported && event.cancelable;
	}
	static ɵfac = function NavigationStateManager_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || NavigationStateManager)();
	};
	static ɵprov = /* @__PURE__ */ ɵɵdefineService({
		token: NavigationStateManager,
		factory: NavigationStateManager.ɵfac
	});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(NavigationStateManager, [{ type: Service }], () => [], null);
})();
function handleResultRejections(result) {
	result.finished?.catch(() => {});
	result.committed?.catch(() => {});
	return result;
}
function setupActivatedRouteInjectors() {
	return (0, import_operators.tap)(({ newlyCreatedRoutes, targetRouterState }) => {
		if (!newlyCreatedRoutes || !targetRouterState) return;
		const traverse = (stateNode) => {
			const route = stateNode.value;
			if (route) processRoute(route, newlyCreatedRoutes);
			for (const childState of stateNode.children) traverse(childState);
		};
		traverse(targetRouterState._root);
	});
}
function processRoute(route, newlyCreatedRoutes) {
	if (!route?.routeConfig?.ɵUseActivatedRouteInjector) return;
	if (newlyCreatedRoutes.has(route)) setupNewActivatedRouteInjector(route._futureSnapshot, route);
}
function setupNewActivatedRouteInjector(snapshot, route) {
	if (ngDevMode && !!route._localInjector) throw new Error("invalid state: _localInjector should not exist on newly created ActivatedRoute yet");
	route._localInjector = createEnvironmentInjector([], snapshot._environmentInjector);
}
function provideRouter(routes, ...features) {
	if (typeof ngDevMode === "undefined" || ngDevMode) {
		publishNonCoreGlobalUtil("ɵgetLoadedRoutes", getLoadedRoutes);
		publishNonCoreGlobalUtil("ɵgetRouterInstance", getRouterInstance);
		publishNonCoreGlobalUtil("ɵnavigateByUrl", navigateByUrl);
	}
	return makeEnvironmentProviders([
		{
			provide: ROUTES,
			multi: true,
			useValue: routes
		},
		{
			provide: ActivatedRoute,
			useFactory: rootRoute
		},
		{
			provide: APP_BOOTSTRAP_LISTENER,
			multi: true,
			useFactory: getBootstrapListener
		},
		features.map((feature) => feature.ɵproviders)
	]);
}
function rootRoute() {
	return inject(Router).routerState.root;
}
function routerFeature(kind, providers) {
	return {
		ɵkind: kind,
		ɵproviders: providers
	};
}
function withInMemoryScrolling(options = {}) {
	return routerFeature(4, [{
		provide: ROUTER_SCROLLER,
		useFactory: () => new RouterScroller(options)
	}]);
}
function withExperimentalPlatformNavigation() {
	const devModeLocationCheck = typeof ngDevMode === "undefined" || ngDevMode ? [provideEnvironmentInitializer(() => {
		const locationInstance = inject(Location);
		if (!(locationInstance instanceof NavigationAdapterForLocation)) {
			const locationConstructorName = locationInstance.constructor.name;
			let message = `'withExperimentalPlatformNavigation' provides a 'Location' implementation that ensures navigation APIs are consistently used. An instance of ${locationConstructorName} was found instead.`;
			if (locationConstructorName === "SpyLocation") message += ` One of 'RouterTestingModule' or 'provideLocationMocks' was likely used. 'withExperimentalPlatformNavigation' does not work with these because they override the Location implementation.`;
			throw new Error(message);
		}
	})] : [];
	return routerFeature(11, [
		{
			provide: StateManager,
			useExisting: NavigationStateManager
		},
		{
			provide: Location,
			useClass: NavigationAdapterForLocation
		},
		devModeLocationCheck
	]);
}
function getBootstrapListener() {
	const injector = inject(Injector);
	return (bootstrappedComponentRef) => {
		const ref = injector.get(ApplicationRef);
		if (bootstrappedComponentRef !== ref.components[0]) return;
		const router = injector.get(Router);
		const bootstrapDone = injector.get(BOOTSTRAP_DONE);
		if (injector.get(INITIAL_NAVIGATION) === 1) router.initialNavigation();
		injector.get(ROUTER_PRELOADER, null, { optional: true })?.setUpPreloading();
		injector.get(ROUTER_SCROLLER, null, { optional: true })?.init();
		router.resetRootComponentType(ref.componentTypes[0]);
		if (!bootstrapDone.closed) {
			bootstrapDone.next();
			bootstrapDone.complete();
			bootstrapDone.unsubscribe();
		}
	};
}
var BOOTSTRAP_DONE = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "bootstrap done indicator" : "", { factory: () => {
	return new import_cjs.Subject();
} });
var INITIAL_NAVIGATION = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "initial navigation" : "", { factory: () => 1 });
function withEnabledBlockingInitialNavigation() {
	return routerFeature(2, [
		{
			provide: IS_ENABLED_BLOCKING_INITIAL_NAVIGATION,
			useValue: true
		},
		{
			provide: INITIAL_NAVIGATION,
			useValue: 0
		},
		provideAppInitializer(() => {
			const injector = inject(Injector);
			return injector.get(LOCATION_INITIALIZED, Promise.resolve()).then(() => {
				return new Promise((resolve) => {
					const router = injector.get(Router);
					const bootstrapDone = injector.get(BOOTSTRAP_DONE);
					afterNextNavigation(router, () => {
						resolve(true);
					});
					injector.get(NavigationTransitions).afterPreactivation = () => {
						resolve(true);
						return bootstrapDone.closed ? (0, import_cjs.of)(void 0) : bootstrapDone;
					};
					router.initialNavigation();
				});
			});
		})
	]);
}
function withDisabledInitialNavigation() {
	return routerFeature(3, [provideAppInitializer(() => {
		inject(Router).setUpLocationChangeListener();
	}), {
		provide: INITIAL_NAVIGATION,
		useValue: 2
	}]);
}
function withDebugTracing() {
	let providers = [];
	if (typeof ngDevMode === "undefined" || ngDevMode) providers = [{
		provide: ENVIRONMENT_INITIALIZER,
		multi: true,
		useFactory: () => {
			const router = inject(Router);
			return () => router.events.subscribe((e) => {
				console.group?.(`Router Event: ${e.constructor.name}`);
				console.log(stringifyEvent(e));
				console.log(e);
				console.groupEnd?.();
			});
		}
	}];
	else providers = [];
	return routerFeature(1, providers);
}
var ROUTER_PRELOADER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router preloader" : "");
function withPreloading(preloadingStrategy) {
	return routerFeature(0, [{
		provide: ROUTER_PRELOADER,
		useExisting: RouterPreloader
	}, {
		provide: PreloadingStrategy,
		useExisting: preloadingStrategy
	}]);
}
function withRouterConfig(options) {
	return routerFeature(5, [{
		provide: ROUTER_CONFIGURATION,
		useValue: options
	}]);
}
function withHashLocation() {
	return routerFeature(6, [{
		provide: LocationStrategy,
		useClass: HashLocationStrategy
	}]);
}
function withNavigationErrorHandler(handler) {
	return routerFeature(7, [{
		provide: NAVIGATION_ERROR_HANDLER,
		useValue: handler
	}]);
}
function withExperimentalAutoCleanupInjectors() {
	return routerFeature(10, [{
		provide: ROUTE_INJECTOR_CLEANUP,
		useValue: routeInjectorCleanup
	}]);
}
function withComponentInputBinding(options = {}) {
	return routerFeature(8, [{
		provide: INPUT_BINDER,
		useFactory: () => new RoutedComponentInputBinder(options)
	}]);
}
function withViewTransitions(options) {
	performanceMarkFeature("NgRouterViewTransitions");
	return routerFeature(9, [{
		provide: CREATE_VIEW_TRANSITION,
		useValue: createViewTransition
	}, {
		provide: VIEW_TRANSITION_OPTIONS,
		useValue: {
			skipNextTransition: !!options?.skipInitialTransition,
			...options
		}
	}]);
}
function withActivatedRouteInjectors() {
	return routerFeature(9, [{
		provide: ACTIVATED_ROUTE_INJECTOR_FEATURE,
		useValue: { operator: setupActivatedRouteInjectors }
	}]);
}
var ROUTER_DIRECTIVES = [
	RouterOutlet,
	RouterLink,
	RouterLinkActive,
	ɵEmptyOutletComponent
];
var ROUTER_FORROOT_GUARD = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "router duplicate forRoot guard" : "");
var ROUTER_PROVIDERS = [
	Location,
	{
		provide: UrlSerializer,
		useClass: DefaultUrlSerializer
	},
	Router,
	ChildrenOutletContexts,
	{
		provide: ActivatedRoute,
		useFactory: rootRoute
	},
	RouterConfigLoader
];
var RouterModule = class RouterModule {
	constructor() {
		if (typeof ngDevMode === "undefined" || ngDevMode) inject(ROUTER_FORROOT_GUARD, { optional: true });
	}
	static forRoot(routes, config) {
		return {
			ngModule: RouterModule,
			providers: [
				ROUTER_PROVIDERS,
				typeof ngDevMode === "undefined" || ngDevMode ? config?.enableTracing ? withDebugTracing().ɵproviders : [] : [],
				{
					provide: ROUTES,
					multi: true,
					useValue: routes
				},
				typeof ngDevMode === "undefined" || ngDevMode ? {
					provide: ROUTER_FORROOT_GUARD,
					useFactory: provideForRootGuard
				} : [],
				config?.errorHandler ? {
					provide: NAVIGATION_ERROR_HANDLER,
					useValue: config.errorHandler
				} : [],
				{
					provide: ROUTER_CONFIGURATION,
					useValue: config ? config : {}
				},
				config?.useHash ? provideHashLocationStrategy() : providePathLocationStrategy(),
				provideRouterScroller(),
				config?.preloadingStrategy ? withPreloading(config.preloadingStrategy).ɵproviders : [],
				config?.initialNavigation ? provideInitialNavigation(config) : [],
				config?.bindToComponentInputs ? withComponentInputBinding(typeof config.bindToComponentInputs === "object" ? config.bindToComponentInputs : {}).ɵproviders : [],
				config?.enableViewTransitions ? withViewTransitions().ɵproviders : [],
				provideRouterInitializer()
			]
		};
	}
	static forChild(routes) {
		return {
			ngModule: RouterModule,
			providers: [{
				provide: ROUTES,
				multi: true,
				useValue: routes
			}]
		};
	}
	static ɵfac = function RouterModule_Factory(__ngFactoryType__) {
		return new (__ngFactoryType__ || RouterModule)();
	};
	static ɵmod = /* @__PURE__ */ ɵɵdefineNgModule({
		type: RouterModule,
		imports: [
			RouterOutlet,
			RouterLink,
			RouterLinkActive,
			ɵEmptyOutletComponent
		],
		exports: [
			RouterOutlet,
			RouterLink,
			RouterLinkActive,
			ɵEmptyOutletComponent
		]
	});
	static ɵinj = /* @__PURE__ */ ɵɵdefineInjector({});
};
(() => {
	(typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RouterModule, [{
		type: NgModule,
		args: [{
			imports: ROUTER_DIRECTIVES,
			exports: ROUTER_DIRECTIVES
		}]
	}], () => [], null);
})();
function provideRouterScroller() {
	return {
		provide: ROUTER_SCROLLER,
		useFactory: () => {
			const viewportScroller = inject(ViewportScroller);
			const config = inject(ROUTER_CONFIGURATION);
			if (config.scrollOffset) viewportScroller.setOffset(config.scrollOffset);
			return new RouterScroller(config);
		}
	};
}
function provideHashLocationStrategy() {
	return {
		provide: LocationStrategy,
		useClass: HashLocationStrategy
	};
}
function providePathLocationStrategy() {
	return {
		provide: LocationStrategy,
		useClass: PathLocationStrategy
	};
}
function provideForRootGuard() {
	if (inject(Router, {
		optional: true,
		skipSelf: true
	})) throw new RuntimeError(4007, "The Router was provided more than once. This can happen if 'forRoot' is used outside of the root injector. Lazy loaded modules should use RouterModule.forChild() instead.");
	return "guarded";
}
function provideInitialNavigation(config) {
	return [config.initialNavigation === "disabled" ? withDisabledInitialNavigation().ɵproviders : [], config.initialNavigation === "enabledBlocking" ? withEnabledBlockingInitialNavigation().ɵproviders : []];
}
var ROUTER_INITIALIZER = new InjectionToken(typeof ngDevMode === "undefined" || ngDevMode ? "Router Initializer" : "");
function provideRouterInitializer() {
	return [{
		provide: ROUTER_INITIALIZER,
		useFactory: getBootstrapListener
	}, {
		provide: APP_BOOTSTRAP_LISTENER,
		multi: true,
		useExisting: ROUTER_INITIALIZER
	}];
}
//#endregion
//#region node_modules/@angular/router/fesm2022/router.mjs
/**
* @license Angular v22.1.1
* (c) 2010-2026 Google LLC. https://angular.dev/
* License: MIT
*/
function mapToCanMatch(providers) {
	return providers.map((provider) => (...params) => inject(provider).canMatch(...params));
}
function mapToCanActivate(providers) {
	return providers.map((provider) => (...params) => inject(provider).canActivate(...params));
}
function mapToCanActivateChild(providers) {
	return providers.map((provider) => (...params) => inject(provider).canActivateChild(...params));
}
function mapToCanDeactivate(providers) {
	return providers.map((provider) => (...params) => inject(provider).canDeactivate(...params));
}
function mapToResolve(provider) {
	return (...params) => inject(provider).resolve(...params);
}
var VERSION = /* @__PURE__ */ new Version("22.1.1");
//#endregion
export { ROUTER_OUTLET_DATA as $, ActivatedRoute as A, EventType as B, withExperimentalPlatformNavigation as C, defaultUrlMatcher as Ct, withPreloading as D, ɵEmptyOutletComponent as Dt, withNavigationErrorHandler as E, loadChildren as Et, ChildActivationEnd as F, NavigationEnd as G, GuardsCheckStart as H, ChildActivationStart as I, NavigationSkippedCode as J, NavigationError as K, ChildrenOutletContexts as L, ActivationEnd as M, ActivationStart as N, withRouterConfig as O, BaseRouteReuseStrategy as P, ROUTER_CONFIGURATION as Q, DefaultTitleStrategy as R, withExperimentalAutoCleanupInjectors as S, createUrlTreeFromSnapshot as St, withInMemoryScrolling as T, isActive as Tt, NavigationCancel as U, GuardsCheckEnd as V, NavigationCancellationCode as W, OutletContext as X, NavigationStart as Y, PRIMARY_OUTLET as Z, withActivatedRouteInjectors as _, UrlSegmentGroup as _t, mapToCanMatch as a, RouteConfigLoadStart as at, withDisabledInitialNavigation as b, afterNextNavigation as bt, PreloadAllModules as c, RouterEvent as ct, ROUTER_PROVIDERS as d, RouterStateSnapshot as dt, ROUTES as et, RouterLink as f, RoutesRecognized as ft, provideRouter as g, UrlSegment as gt, RouterPreloader as h, UrlHandlingStrategy as ht, mapToCanDeactivate as i, RouteConfigLoadEnd as it, ActivatedRouteSnapshot as j, withViewTransitions as k, PreloadingStrategy as l, RouterOutlet as lt, RouterModule as m, TitleStrategy as mt, mapToCanActivate as n, ResolveEnd as nt, mapToResolve as o, RouteReuseStrategy as ot, RouterLinkActive as p, Scroll as pt, NavigationSkipped as q, mapToCanActivateChild as r, ResolveStart as rt, NoPreloading as s, Router as st, VERSION as t, RedirectCommand as tt, ROUTER_INITIALIZER as u, RouterState as ut, withComponentInputBinding as v, UrlSerializer as vt, withHashLocation as w, destroyDetachedRouteHandle as wt, withEnabledBlockingInitialNavigation as x, convertToParamMap as xt, withDebugTracing as y, UrlTree as yt, DefaultUrlSerializer as z };
